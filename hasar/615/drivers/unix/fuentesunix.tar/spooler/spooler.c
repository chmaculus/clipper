/*

  spooler.c

  * 14/05/2001
  Se agrego un nuevo switch para Win32, Linux y Unix (-x) para 
  permitir al spooler trabajar con el protocolo nuevo y por ende 
  el uso de STATPRN.

  * 14/05/2001
  Solo en DOS no se podia hacer un 'rename; en donde el archivo 
  destino estaba en otro directorio. Se hace un copy y un unlink. 
  Esto esta hecho en la funcion 'Rename'.

  * 16/05/2001
  Funcionando como servidor de red, si el comando no se podia 
  ejecutar en el impresor, el wspooler reintentaba con 
  rMandaPaqueteFiscal hasta que el problema se solucionaba. 
  El cliente salia por error y el comando se ejecutaba con exito, 
  en el momento en que la comunicacion con el printer se reestablecia. 
  Ahora solo se hace MandaPaqueteFiscal y si la funcion da error, 
  no se responde al cliente, y luego este sale por TOUT.

  * 11/06/2001
  En modo ejecucion unica (opcion -c), se borran los archivos TMPFILE 
  y respuest.ans antes de la ejecucion del comando. Esto antes no se 
  hacia y cuando se queria renombrar el temporario como respuest.ans,
  la funcion rename no lo permitia. Esto producia que todas las 
  respuestas se grabaran en TMPFILE.
  Se elimino el mensaje "Tapa de Slip abierta", dado que el 425 imprime 
  igual y en el PR4 se para el printer dando error mecanico.

  * 14/06/2001
  Se incorporaron codigos de error devueltos por el spooler cuando 
  no puede abrir un socket o no puede realizar la conexion a traves 
  de la funcion listen.
  Cuando el impresor respondia en el status de printer cualquiera de 
  los mensajes que se describen, el spooler se quedaba en un loop hasta 
  que el tema se solucionaba. En todos estos casos, el impresor responde 
  con DC2 o DC4 (segun sea el problema) con lo que no tiene sentido 
  mirar estos bits ya que el spooler igual se para. El ultimo error 
  de tapa abierta no tiene sentido en el 425 ya que el impresor imprime
  de todas formas. En el PR4 el impresor para al controlador con Ctrl-S 
  y este manda DC2/DC4.

	"Impresora OffLine",
	"Falta Papel del Diario",
	"Falta Papel de Tickets",
	"Tapa de Slip Abierta",
 
  * 18/10/2001
  En el caso en que no se puede renombrar el TmpAns como el archivo
  final, se agrego al debugger el errno del error. 

  * 19/10/2001
  Funcionando como spooler en Unix/Linux se arregl� el tema de que 
  si los archivos a leer estaban en may�sculas, no se pod�an abrir. 


  * 15/07/2002
  Funcionando como spooler imprime el errno cuando no puede 
  abrir el archivo a enviar.

  * 12/03/2003
  Permite cambiar el directorio del archivo temporario.

  * 18/03/2003
  Si trabajo levantando archivos de un directorio retorno sin hacer exit. 
  Si no se puede abrir el archivo se reintenta en el loop principal hasta 
  que se pueda abrir.

*/

#ifdef DOS
#include "getopt.h"
#include <io.h>
#include <dos.h>
#include <share.h>
#include <conio.h>
#endif

#ifdef WIN32
#include <windows.h>
#include "winfis.h"
#endif

#include <fcntl.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdarg.h>
#include <time.h>
#include <ctype.h>
#include <signal.h>
#include <errno.h>

#include "split.h"
#include "spooler.h"
#include "tcpip.h"
#include "fiserr.h"
#include "exitcode.h"

#ifdef UNIX
#include <prototypes.h>
#endif 

#if defined (UNIX) || defined (LINUX)
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include "fisdebug.h"
#include "ttyset.h"
void dummy (int sig) {signal (SIGPIPE, dummy);}
#endif

#if !defined(WIN32) && defined (DOS)
#include "fislib.h"
#include "comm.h"
#endif

#if defined (UNIX) || defined (LINUX)
#include "unxlib.h"
char PortName [100];
#endif

#if defined (WIN32) || defined (UNIX) || defined (LINUX)
extern int SpoolerPort;
#endif

static char *GetAnswerFilename (char *Name);
static int   Send              (char *Comando);

char *FiscalErrors[16] =
{
	"Error en memoria fiscal",
	"Error en memoria de trabajo",
	NULL,
	"Comando desconocido",
	"Datos no validos en un campo",
	"Comando invalido para el estado actual",
	"Desborde de total",
	"Memoria fiscal llena",
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL
};

char *PrinterErrors[16] = 
{
	NULL,
	NULL,
	"Error Mec�nico de Impresora",
	NULL,	// "Impresora OffLine",
	NULL,	// "Falta Papel del Diario",
	NULL,	// "Falta Papel de Tickets",
	NULL,
	NULL,
	NULL,  	// "Tapa de Slip Abierta",
			// El mensaje de tapa abierta en el 425 no tiene 
			// sentido dado que el impresor imprime igual. 
			// En el PR4, cuando la tapa esta abierta se devuelve 
			// error mecanico de impresor en respuesta a un comando
			// de status. Cuando se quiere imprimir, el printer frena 
			// al controlador con Ctrl-S y este devuelve DC2 al host.
			// El 615 no da error por tapa abierta. 
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
};

#define OFFSET_FISCAL_STATUS	5
#define OFFSET_ANSWER           9

char *AnswerDirectory;
char *CommandDirectory = NULL;
char *AnswerFile;
extern char *FileLog;

int SpoolerMode = 0, ConsoleMode = 0, FileMode = 0;

#ifdef WIN32
int ModoCaracteres = MODE_ASCII;
#endif

int PortNumber = 1;
int Port;
long Speed = -1;
int Autodetect;
int NoCancel;
int LogLibrary = 0;
int SocketMode;
int UseNewProtocol;

char DirTmp[200];
char TmpFile[200];
char Respuesta[500];
char BufferFiscalStatus[20];
char BufferPrinterStatus[20];
char CommandChar;
int WriteCommandOnAnswer = 0;

int CountDC4 = 1;
int CountDC2 = 1;

char *Usage[] = 
{
"Utilitario para transmitir comandos a controladores fiscales HASAR",
" ",

#if defined (UNIX) || defined (LINUX)
"Uso: %s [-p tty] [-l] ",
"             [-v velocidad] [-t] [-d file] [-n] [-e] [-m] [-b dirtmp]", 
"             [-c comando] ",
"             [-f archivo] [-r] ",
"             [-s dircom] [-a dirresp] ",
#endif

#if defined (DOS)
"Uso: %s [-p port] [-l] ",
"             [-v velocidad] [-t] [-d file] [-n] [-e] [-m] [-b dirtmp]", 
"             [-c comando] ",
"             [-f archivo] [-r] ",
"             [-s dircom] [-a dirresp]",
#endif 

#if defined (WIN32) 
"             [-w] [-k] [-o tcpport] [-x]",
#endif

#if defined (UNIX) || defined (LINUX)
"             [-k] [-o tcpport] [-x]",
#endif

" ",
"  Opciones generales",
#if defined (DOS) || defined (WIN32)
"  -p port            COM serie en donde esta conectado el impresor",
#endif

#if defined (UNIX) || defined (LINUX)
"  -p tty             tty conectada al impresor (tty1a, tty2a, etc ...)",
#endif 

"  -l                 almacena en el archivo spooler.log informacion",
"                     explicativa del protocolo con el impresor",
"  -v velocidad       cambia la velocidad (baudios) del puerto serie.",
"  -t                 busca al controlador a todas las velocidades posibles",
"                     (auto-excluyente con la opcion [-v])",
"  -d file            cambia el nombre del archivo spooler.log",
"  -n                 guarda en la respuesta el numero de comando asociado",

#ifdef WIN32
"  -w                 modo compatibilidad caracteres Windows",
#endif

"  -e                 usado en modo -f, no cancela el comprobante en curso",
"                     antes de enviar el comando",
"  -m                 no muestra los mensajes de error en pantalla",
"  -b dirtmp          nombre del directorio donde guardar archiv. temporarios",  
" ",
"  Funcionando en modo unica ejecucion:",
"  -c comando         comando a enviar al impresor",
"  -f archivo         contiene un conjunto de comandos a enviar al impr.",
"  -r                 envia el archivo en forma repetitiva.",
"",
"  Funcionando como spooler:",
"  -s dircom          directorio en donde ir a buscar los archivos",
"  -a dirresp         directorio en donde dejar las respuestas",
"",

#if defined (WIN32) || defined (UNIX) || defined (LINUX)
"  Funcionando como servidor de red:",
"  -k                 espera los comandos en un port de TCP",
"  -o tcpport         port de TCP del servidor (default: 1600)",
"  -x                 utiliza el protocolo nuevo (uso de STATPRN)",
#endif

"",
NULL
};


void
Delete (char *File)
{
	if ( !access (File, 0) )
		unlink (File);
}

void 
Rename (char *FileIn, char *FileOut)
{
	#if !defined (WIN32) && !defined (UNIX) && !defined (LINUX)

	// Solo en DOS.
	
	char buf[300];
	int  local_drive;

	// Si las unidades de disco son distintas, el rename no anda.
	// Hago copy y unlink.
	
	local_drive = _getdrive () - 1 + 'A';

	if ( *(FileOut + 1) == ':' && local_drive != toupper (*FileOut) )
	{
		sprintf (buf, "copy %s %s>nul", FileIn, FileOut);

		if ( system (buf) )
		{
			Debug (1, "Error copiando el archivo de respuesta a %s", FileOut);
			exit (ERR_ANSWER_FILE);
		}

		if ( unlink (FileIn) )
		{
			Debug (1, "Error borrando archivo temporario");
			exit (ERR_ANSWER_FILE);
		}
	}
	
	// Dejo la opcion del rename, por si el system en algun caso
	// se queda sin memoria. En este caso, el rename del archivo
	// a otra unidad de disco queda sin efecto.

	else
	{
		if ( rename (FileIn, FileOut) )
		{
			Debug (1, "Error renombrando %s a %s", FileIn, FileOut);
			exit (ERR_ANSWER_FILE);
		}
	}

	#else

	if ( rename (FileIn, FileOut) )
	{
		Debug (1, "Error renombrando %s a %s, errno %d", 
			FileIn, FileOut, errno);
		exit (ERR_ANSWER_FILE);
	}

	#endif
}


static void
Uso(char *ProgramName)
{
	char **p = Usage;
	int i = 0;

	system ("clear");

	while (*p)
	{
		if ( strstr (*p, "%s") )
		{
			printf (*p, ProgramName);
			printf ("\n");
		}
	    else printf("%s\n", *p);

		if ( i++ > 20 )
		{
			printf ("\nPresione <enter> para continuar ... \n");
			getchar ();
			i = 0;
			system ("clear");
		}
		
		p++;
	}
	
	exit(ERR_USAGE);
}

void
ResetWaitCounters(void)
{
	CountDC4 = CountDC2 = 1;
}

int
rMandaPaqueteFiscal(int Port, char *Paquete, char *Respuesta)
{
	int FlagError = 0;

	while(ResetWaitCounters(), 
		#ifdef WIN32
		MandaPaqueteFiscal(Port, Paquete) < 0)
		#else
		MandaPaqueteFiscal(Port, Paquete, NULL, NULL, Respuesta) < 0)
		#endif
	{
		FlagError = 1;

		Debug(1, "Error de comunicaciones con la impresora");

		if (ConsoleMode)
			exit(ERR_COMM);
	}
	
	#ifdef WIN32
	UltimaRespuesta(Port, Respuesta);
	#endif

	if (FlagError)
		Debug(1, "Comunicaciones OK");

	return 0;
}

void
CancelAll(void)
{
	rMandaPaqueteFiscal (Port, CANCEL_FISCAL_RECEIPT, Respuesta);
    rMandaPaqueteFiscal (Port, CLOSE_FISCAL_RECEIPT, Respuesta);
    rMandaPaqueteFiscal (Port, CLOSE_NON_FISCAL_RECEIPT, Respuesta);
}

#if defined(DOS) && !defined (WIN32)
#pragma argsused
#endif

void
#if defined (UNIX) || defined (LINUX)
UnxFISdebug(char *Fmt, char *argptr)
#else
FISdebug(int Nivel, char *Fmt, ...)
#endif 
{
	#ifdef DOS
	va_list argptr;
	#endif 

	static char BufLog [500];

	if ( !LogLibrary )
			return;

	#ifdef DOS
	va_start(argptr, Fmt);
	#endif 

	vsprintf (BufLog, Fmt, argptr);
        
	#ifdef DOS
	va_end (argptr);
	#endif

	Debug(0, BufLog);
}

static int
Xtoi(char *num)
{
	int n, i;

	for (i=0, n=0 ; i < 4; i++,num++)
	{
		n <<= 4;
		n |= (isdigit(*num) ? *num - '0' : toupper(*num)-'A'+ 0xa);
	}
	
	return n;
}

static void
Expand(int Status, char *Buffer)
{
	int i;
        
    for (i = 0; i < 16; i++)
    	Buffer[15 - i] = (Status & (1 << i)) ? '1' : '0';
    Buffer[16] = 0;
}

// Cambia el separador por el caracter '|'
char *
ConvertSep (char *str)
{
	char *p = str;

	while (*str)
	{
		if (*str == 0x1c)
			*str = '|';
		str++;
	}

	return p;
}

static int
CheckAnswer(char *Answer)
{
	int i;
	char *FiscalStatus, *PrinterStatus;
	int   BinaryFiscalStatus, BinaryPrinterStatus;
	static int FlagError;

	FiscalStatus = Answer + OFFSET_FISCAL_STATUS;
	PrinterStatus = Answer;
        
	BinaryFiscalStatus = Xtoi(FiscalStatus);
	BinaryPrinterStatus = Xtoi(PrinterStatus);

	Expand(BinaryFiscalStatus, BufferFiscalStatus);
	Expand(BinaryPrinterStatus, BufferPrinterStatus);

	for ( i = 0; i < 15; i++ )

		if ( BufferPrinterStatus[i] == '1' && PrinterErrors[15-i] )
		{
			Debug (1, PrinterErrors[15-i]);
			FlagError = 1;
			return PRINTER_ERROR;
		}

	if ( FlagError )
	{
		// Bajo el Flag de Error y pongo un mensaje.
		FlagError = 0;
		Debug (1, "Impresor Funcionando Correctamente");
	}

	Debug(0, "Respuesta: %s", Answer);

	if (BinaryFiscalStatus & FATAL_FISCAL_FLAGS)
	{
		Debug(1, "Error no recuperable en impresion:");

		for ( i = 0; i < 15; i++ )
			if ( BufferFiscalStatus[i] == '1' && FiscalErrors[15-i] )
				Debug (1, FiscalErrors[15-i]);
		
		return FISCAL_ERROR;
	}

	return 0;
}

static int
WriteAnswer (char *Answer)
{
	char  Buffer[512];
	int fd;

	if ( (fd = sopen (TmpFile, O_RDWR, SH_DENYNO, 0666)) < 0 )

		if ((fd = sopen(TmpFile, 
				O_RDWR | O_TRUNC | O_CREAT, SH_DENYNO, 0666)) < 0)
		{
			Debug(1, "No pude abrir archivo de respuestas [%s]", TmpFile);
			exit(ERR_ANSWER_FILE);
		}

	// Me paro en el final del archivo para appendear.
	lseek (fd, 0L, SEEK_END);

	ConvertSep(Answer);
        
	if (WriteCommandOnAnswer)
		sprintf(Buffer, "%c|%s|%s%s\n", CommandChar,
			BufferPrinterStatus, BufferFiscalStatus, Answer+OFFSET_ANSWER);
	else
		sprintf(Buffer, "%s|%s%s\n", 
			BufferPrinterStatus, BufferFiscalStatus, Answer+OFFSET_ANSWER);

	write(fd, Buffer, strlen(Buffer));

	close(fd);

	return 0;
}

int
SendPrinterCommand (char *Command, int Mode)
{
	char *p;
	int  Rc;

	if ( (p = strchr(Command, '\n')) != NULL )
		*p = 0;

	if ( (p = strchr(Command, '\r')) != NULL )
		*p = 0;

	if ( Mode == RETRY_MODE )
		Rc = rMandaPaqueteFiscal (Port, Command, Respuesta);
	else
	{
		ResetWaitCounters();
		
		#ifdef WIN32
		Rc = MandaPaqueteFiscal (Port, Command);
		if ( Rc == ERR_STATPRN || !Rc )
			UltimaRespuesta (Port, Respuesta);
		#else
		Rc = MandaPaqueteFiscal (Port, Command, NULL, NULL, Respuesta);
		#endif
		
		if ( Rc < 0 )
		{
			if ( Rc == ERR_STATPRN )
		
				// Devuelvo el STATPRN para que el host vuelva 
				// a encuestar al printer, Esta opcion es valida 
				// con la opcion -x (solo en WIN32, Linux o Unix).

				strcat (Respuesta, "\x1c" "~STATPRN~");
	
			else 
			{
				Debug (1, "Error de comunicaciones con la impresora");
				return Rc;
			}
		}
	}

	CommandChar = *Command;

	Debug(0, "Comando completado: %s", ConvertSep(Command));

	return Rc;
}

static int 
Send (char *Command)
{
	int Rc = 0;

	SendPrinterCommand (Command, RETRY_MODE);

	if ((Rc = CheckAnswer (Respuesta)) == 0)
	{
		// Escribe la respuesta en el archivo de respuestas 
		// y retorna.
		WriteAnswer (Respuesta);
		return 0;
	}

	switch (Rc)
	{
		case PRINTER_ERROR:

			// Hay error de Impresor. Quedarse tirando status hasta que 
			// se elimine esta condicion.

			Debug (0, "Esperando que se solucione el error...");

			do 
			{
				rMandaPaqueteFiscal (Port, STATUS, Respuesta);
			} 
			while (CheckAnswer (Respuesta) != 0);

			// Escribe la respuesta y se va.
			WriteAnswer (Respuesta);

			break;

		case FISCAL_ERROR:

			WriteAnswer (Respuesta);

			// Cancelo todo.
			if (!ConsoleMode)
				CancelAll();

			if (!SpoolerMode)
			{
				Rename(TmpFile, AnswerFile);
				exit(ERR_FISCAL_ERROR);
			}
                        
			break;
	}       

	return 0;
}

int
SendFile(char *Filename)
{
	FILE *fp;
	char buffer[512];
	char *Campos[1];

	AnswerFile = GetAnswerFilename(Filename);

	// Borro el archivo de respuesta temporaria y el archivo de 
	// respuesta si ya existian.
	 
	Delete (TmpFile); Delete (AnswerFile);
	
	if ( !(fp = _fsopen (Filename, "r", SH_DENYNO)) )
	{
		Debug (1, "Error abriendo %s, errno %d", Filename, errno);

		// Solo si trabajo levantando archivos de un directorio
		// retorno sin hacer exit. Si no se puede abrir el archivo
		// se reintenta en el loop principal hasta que se pueda abrir
		
		if ( CommandDirectory )
			return -1;
		else exit(ERR_COMMAND_FILE);
	}

	Debug (0, "Enviando contenido de %s", Filename);

	while ( fgets (buffer, sizeof (buffer), fp) )
	{
		split (buffer, Campos, 1);

		if (!Campos[0][0])
			continue;
		
		Send (Campos[0]);
	}

	Debug(0, "Archivo %s finalizado", Filename);

	fclose (fp);

	return 0;
}

static char *
GetAnswerFilename(char *Name)
{
	static char Buffer[128];
	char *p = Buffer;
	char *JustTheName;
	char *SlashPos;

	if (!(JustTheName = strrchr(Name, SLASH)))
		JustTheName = Name;
	else
		JustTheName++;

	sprintf(Buffer, "%s%c%s", 
		AnswerDirectory ? AnswerDirectory : 
		(CommandDirectory ? CommandDirectory : "."), 
		SLASH, JustTheName);

	SlashPos = strrchr(Buffer, SLASH);

	if ((p = strrchr(Buffer, '.')) != NULL && p > SlashPos)
		strcpy(p, ANSWER_EXTENSION);
	else
		strcat(Buffer, ANSWER_EXTENSION);

	return Buffer;
}

#if defined (DOS) && !defined (WIN32)
#pragma argsused
#endif
void
My_KeepAliveHandler(int Caracter, int Port)
{
	#if defined (WIN32) || defined (UNIX) || defined (LINUX)

	char *szDC2 = "DC2";
	char *szDC4 = "DC4";

	if ( SocketMode )
		SendIPPacket (Caracter == DC4 ? szDC4 : szDC2);

	#endif
		
	if ( Caracter == DC4 && !(++CountDC4 % 10))
    	Debug (1, "Falta Papel...");

    if ( Caracter == DC2 && !(++CountDC2 % 30) )
    	Debug (1, "Impresor Ocupado...");
}

// Inicializa el puerto de comunicaciones. 

void
InitCOM (void)
{
	Debug(0, "A abrir COM%d", PortNumber);

#if defined (UNIX) || defined (LINUX)
	if ((Port = OpenCommFiscal (PortName)) < 0 )
#else
	#ifdef WIN32
	if ((Port = OpenComFiscal(PortNumber, ModoCaracteres)) < 0)
	#else
	if ((Port = OpenCommFiscal(PortNumber)) < 0)
	#endif
#endif
	{
		Debug (1, "No pude abrir COM%d", PortNumber);
		exit(ERR_PORT);
	}

	if ( Autodetect )
	{
		#ifdef WIN32
		if ( (Speed = SearchPrn (Port)) < 0 )
		#else
		if ( SearchPrn (Port, &Speed) < 0 )
		#endif
		{
			Debug (1, "No se ha detectado al controlador "
						"a ninguna velocidad posible\n");
			exit (ERR_DETECTING);
		}

		Debug (1, "Controlador detectado a %ld baudios\n", Speed);
	}

	if (Speed != -1)
		#ifdef WIN32
		CambiarVelocidad(Port, Speed);
		#else
		SetBaudRate(Port, Speed);
		#endif

	rMandaPaqueteFiscal (Port, STATUS, Respuesta);
	rMandaPaqueteFiscal (Port, STATUS, Respuesta);

	if (!ConsoleMode && !NoCancel)
		CancelAll();
}

void
SetTmpFileName (char *DirName)
{
	int len, i;
	char *p;
	int fd;

	if ( !*DirName )
	{
		strcpy (TmpFile, TMPFILE);
		return;
	}

	len = strlen (DirName);
	
	p = DirName + len - 1;

	for (i = len; i > 0 && *p == SLASH; i--)
		*p-- = 0;
	
	sprintf (TmpFile, "%s%c%s", DirName, SLASH, TMPFILE);

	fd = open (TmpFile, O_CREAT | O_RDWR | O_TRUNC, 0666);

	if ( fd < 0 )
	{
		Debug (1, "Error abriendo archivo temporario [%s]", TmpFile);
		exit(ERR_ANSWER_FILE);
	}

	close (fd);

	unlink (TmpFile);

	Debug (1, "Archivo temporario: [%s]", TmpFile);
}

int 
main (int argc, char *argv[])
{
	char *p;
	int n;
	char *PrgName = argv[0];
	char *Command = NULL;
	char *Filename = NULL;
	int done;
	int Recursive = 0;
	char FullName[128];

#ifdef DOS
	signal (SIGINT, exit);
	signal (SIGABRT, exit);
	signal (SIGTERM, exit);
#endif

#if defined (UNIX) || defined (LINUX)
	signal (SIGPIPE, dummy);
	signal (SIGQUIT, exit);		// Atrapa Abort ('Ctrl + \')
	signal (SIGINT,  exit);		// Atrapa Interrupt (Del)
	signal (SIGTERM, exit);		// Atrapa Kill (Signal 15)
	signal (SIGHUP,  exit);		// Atrapa Hangup (Signal 01). La manda el shell
	signal (SIGABRT, exit);		
#endif

	while ( (n = getopt(argc, argv, "mto:ketd:lp:c:f:s:ua:nrv:wxb:")) != EOF )
	{
		switch ( n ) 
		{
			case 'm':
				ShowDebuggers (0);
				break;
				
			case 'e':
				NoCancel   = 1;
				break;

			case 't':
				Autodetect = 1;
				break;

			case 'l':
				LogLibrary = 1;
				break;

			case 'p':
				#if defined (UNIX) || defined (LINUX)
				strcpy (PortName, optarg);
				#else
				PortNumber = atoi (optarg);
				#endif
				break;

			case 'c':
				ConsoleMode = 1;
				Command = optarg;
				break;

			case 'f':
				Filename = optarg;
				break;

			case 'd':
				FileLog = optarg;
				break;

			case 's':
				CommandDirectory = optarg;
				break;

			case 'a':
				AnswerDirectory = optarg;
				break;

			case 'n':
				WriteCommandOnAnswer = 1;
				break;

			case 'r':
				Recursive = 1;
				break;

			case 'v':
				Speed = atol(optarg);
				break;

			#ifdef WIN32
			case 'w':
				ModoCaracteres = MODE_ANSI;
				break;
			#endif

			#if defined (WIN32) || defined (UNIX) || defined (LINUX)
			case 'k':
				SocketMode = 1;
				break;
				
			case 'o':
				SpoolerPort = atoi (optarg);
				break;

			case 'x':
				UseNewProtocol = 1;
				break;
			#endif								

			case 'b':
				strcpy (DirTmp, optarg);
				break;

			default:
			case 'u':
				Uso (PrgName);
				break;
		}
	}

	if ( !Command && !Filename && !CommandDirectory && !SocketMode )
		Uso (PrgName);

	#if defined (UNIX) || defined (LINUX)

	// Esta funcion baja la mascara de creacion de archivos 
	// que tiene el proceso que esta corriendo. Si algun bit
	// de esa mascara esta en 1, implica que en la creacion del 
	// archivo, ese bit quede en cero, independientemente de lo 
	// que indique el modo de creacion del mismo.  

	umask (0);

	if ( LogLibrary )
		SetFISdebug (UnxFISdebug);

	#endif 

	Debug (0,"**START SPOOLER**");

	if ( Autodetect && Speed != -1 )
		Uso (PrgName);

	#if defined (WIN32) || defined (UNIX) || defined (LINUX)
	if ( CommandDirectory && SocketMode )
		Uso (PrgName);
	#endif
	
	// Setea el nombre del archivo temporario en TmpFile

	SetTmpFileName (DirTmp);

	SetKeepAliveHandler(My_KeepAliveHandler);

	InitCOM ();

	// Veo si es modo comando (opcion -c).

	if (Command != NULL)
	{
		AnswerFile = "respuesta.ans";

		// Borra los archivos donde se guarda la respuesta 
		// temporaria y el archivo con la respuesta definitiva.

		Delete (TmpFile); Delete (AnswerFile);

		// Envio el comando.
		Send (Command);
		
		// Renombro el temporario como el definitivo. 
		Rename(TmpFile, AnswerFile);

		return 0;
	}

	// Veo si es modo archivo (opcion -f).
	
	if (Filename != NULL)
	{
		FileMode = 1;
	
		if (Recursive)
			do
			{
				SendFile(Filename);
				puts("Presione una tecla o <ESC> para finalizar...");
			} 
			while (getch() != 0x1b);
		else
			SendFile(Filename);

		Debug(0, "Dejando %s a disposici�n del usuario", AnswerFile);
		Rename(TmpFile, AnswerFile);
		Debug(0, "Fin de la operaci�n con archivo %s", Filename);
		return 0;
	}
        
	// Veo si es modo spooler (opcion -s).
		
	if (CommandDirectory)
	{
		SpoolerMode = 1;
	
		while ( 1 )
		{
			for ( Filename = GetFirst(CommandDirectory); 
				Filename != NULL; Filename = GetNext())
			{
				sprintf(FullName, "%s%c%s", CommandDirectory, SLASH, Filename);
				if ( SendFile (FullName) < 0 )
					continue;
				unlink (FullName);
				Rename(TmpFile, AnswerFile);
			}

			#ifdef DOS
			kbhit();                        // Para ctrl+brk
			#endif

			#ifdef WIN32
			Sleep(1000);
			#else
			sleep (1);
			#endif
		}
	}

	#if defined (WIN32) || defined (UNIX) || defined (LINUX)

	// Veo si es modo servidor de red (opcion -k).

	if ( SocketMode )
	{
		if ( UseNewProtocol )
		{
			// Establece el nuevo protocolo de comunicaciones 
			// con el printer (uso de STATPRN).

			#ifdef WIN32
			ProtocolMode (1);
			#endif

			#if defined (UNIX) || defined (LINUX)
			SetNewProtocol (1);
			#endif
		}
		
		IPServer ();
	}
	#endif	
			
	// No es ninguno de los modos soportados.
	Uso(PrgName);
	
    return 0;
}

