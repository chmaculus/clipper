#include <prototypes.h>
#include <unistd.h>
#include <dirent.h>

main ()
{
	DIR *dirp;
	struct dirent *dp;

	dirp = opendir (".");
	if ( !dirp )
	{
		printf ("opendir dio error\n");
		exit (1);
	}

	while ( (dp = readdir (dirp)) != NULL )
		printf ("file = %s\n", dp->d_name);

	closedir (dirp);
}



