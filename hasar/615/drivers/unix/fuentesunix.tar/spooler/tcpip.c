/*
tcpip.c
*/

#if defined (WIN32) || defined (LINUX) || defined (UNIX)

#ifdef UNIX
#include <prototypes.h>
#endif 

#if defined (UNIX) || defined (LINUX)
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#endif

#ifdef WIN32
#include <windows.h>
#endif 

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "sock.h"
#include "spooler.h"
#include "fiserr.h"
#include "exitcode.h"

int 			sockfd = -1;			// Descriptor del socket.
char           	ClientIPAddress [20];	// IP del cliente
unsigned short 	ClientPort;				// Port del cliente

static char    	DebugBuffer[500];			
static char    	IPBuffer[500];			// Buffer de recepcion
static char *   IpAddr;

int SpoolerPort = 1600;

extern char Respuesta[];

extern char * ConvertSep (char *str);

void
SetIPPort (int Port)
{
	SpoolerPort = Port;
}

void
SendIPPacket (char *Command)
{
	if ( sockfd < 0 )
		return;

	SockSend (sockfd, Command, strlen (Command), WAITFOREVER);
}	

static void
CloseConnection (void)
{
	if ( sockfd < 0 )
		return;
	SockClose (sockfd);
}

void
IPServer (void)
{
	int    n;
	int    fd;
	INADDR RemoteAddr;
	PORT   RemotePort;
	char  *cmd;
	int    Rc;
	
	fd = SockStream ((PORT) SpoolerPort);

	if ( fd < 0 )
	{
		Debug (1, "Error abriendo el port %d", SpoolerPort);
		exit (ERR_OPEN_SOCKET);
	}

	#ifdef WIN32 
	if ( (IpAddr = GetMyIpAddress ()) != NULL )
		Debug (1, "IP Servidor = %s, Port %d", IpAddr, SpoolerPort);
	#endif 
		
	atexit (CloseConnection);

	if ( SockListen (fd) )
	{
		Debug (1, "No se puede iniciar la comunicaci�n a trav�s del LAN");
		exit (ERR_CONNECTING);
	}

	while ( 1 )
	{
		sockfd = SockAccept (fd, &RemoteAddr, &RemotePort, WAITFOREVER);
		
		strcpy (ClientIPAddress, GetIPAsc(RemoteAddr));
		
		Debug (1, "Iniciando conexi�n con %s (%u)", ClientIPAddress, 
			RemotePort);

		while ( 1 ) 
		{ 
			n = SockReceive (sockfd, IPBuffer, sizeof (IPBuffer), WAITFOREVER);

			if ( n <= 0 )
			{
				Debug (1, "Finalizando conexi�n con %s (%u)",
					ClientIPAddress, RemotePort);
				break;
			}
			
			IPBuffer[n] = 0;

			if ( IPBuffer[n - 1] == '\n' )
				IPBuffer[n - 1] = 0;
				
			cmd = IPBuffer;

			#if defined (UNIX) || defined (LINUX)
			strcpy (DebugBuffer, IPBuffer);
			cmd = ConvertSep (DebugBuffer);
			#endif

			Debug (1, "Cmd [%s]", cmd);

			Rc = SendPrinterCommand (IPBuffer, NO_RETRY_MODE);

			if ( Rc && Rc != ERR_STATPRN )
				continue;
			
			n = SockSend (sockfd, Respuesta, strlen (Respuesta), WAITFOREVER);

			if ( n < 0 )
			{
				Debug (1, "Finalizando conexi�n con %s (%u)",
					ClientIPAddress, RemotePort);
				break;
			}

			Debug (1, "Ans [%s]", ConvertSep (Respuesta));

		}

		SockClose (sockfd);
	}	

}

#endif
