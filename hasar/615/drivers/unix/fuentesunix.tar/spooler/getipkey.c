#include <mthasys.h>

/*
	Obtiene un HKEY abierto apuntando a un valor IPAddress v�lido.
	Devuelve NULL si no lo encontr�.
*/


HKEY
GetIPKey (void)
{
	char IPAddress[100];
	unsigned long SizeIP;
	static HKEY hkey;
	HKEY hRoot;
	int Index;
	char SubKey[300];
	int SubKeySize;
#define MAX_PROTOCOLS 10
	char *Root = "System\\CurrentControlSet\\Services\\Class\\NetTrans";

	if (RegOpenKeyEx(HKEY_LOCAL_MACHINE, Root, 0L, KEY_ENUMERATE_SUB_KEYS, &hRoot) != ERROR_SUCCESS)
		return NULL;
	for (Index = 0; Index < MAX_PROTOCOLS; Index++)
	{
		SubKeySize = sizeof(SubKey);
		if (RegEnumKeyEx(hRoot, Index, SubKey, &SubKeySize, NULL, NULL, NULL, NULL) != ERROR_SUCCESS)
			return NULL;

		if (RegOpenKeyEx(hRoot, SubKey, 0L, KEY_QUERY_VALUE, &hkey) != ERROR_SUCCESS)
			continue;
				
		/*
			Encontr� una direcci�n de IP v�lida, y no es "0.0.0.0", es decir,
			una direcci�n de IP obtenida de un servidor de direcciones de IP,
			como el acceso telef�nico a redes.
		*/
		
		SizeIP = sizeof(IPAddress);
		if (RegQueryValueEx (hkey,	
							"IPAddress", 
							NULL, 
							NULL, 
							IPAddress, &SizeIP) == ERROR_SUCCESS 
			&& strcmp(IPAddress, "0.0.0.0"))
			break;
		
		RegCloseKey (hkey);
	}
	if (Index == MAX_PROTOCOLS)
		return NULL;
	
	return hkey;
}
