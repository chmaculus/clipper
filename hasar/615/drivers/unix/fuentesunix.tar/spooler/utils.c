#if defined (UNIX) || defined (LINUX)
#include <dirent.h>
#endif 

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#ifdef DOS
#ifndef WIN32
#include <sys/stat.h>
#include <dir.h>
#endif
#include <io.h>
#include <fcntl.h>
#endif

#include "spooler.h"

// Salteo los .ans que son los archivos de respuestas
//#define CheckIfAnswerFile(Filename) 	{ if ( strstr (strlwr (Filename), ANSWER_EXTENSION) ) return GetNext (); }

char *strlwr (char *);

char *
CheckIfAnswerFile (char *Name)
{
	char bufname[300];

	strcpy (bufname, Name);

	if ( strstr (strlwr (bufname), ANSWER_EXTENSION) )
		return GetNext ();

	return Name;
}

#ifdef DOS


#ifdef WIN32
struct _finddata_t ffblk;
long hFile;

char *
GetFirst (char *Directory)
{
	char Buffer[128];

	sprintf (Buffer, "%s\\*.*", Directory);
	hFile = _findfirst(Buffer, &ffblk);
	if (hFile == -1)
		return NULL;

	if ( !CheckIfAnswerFile(ffblk.name) )
		return NULL;

	if (!strcmp(ffblk.name, ".") || 
		!strcmp(ffblk.name, ".."))
		return GetNext();
	return ffblk.name;
}

char *
GetNext (void)
{
	int rc = _findnext (hFile, &ffblk);

	if (rc != 0)
		return NULL;

	// Salteo los .ans que son los archivos de respuestas
	if ( !CheckIfAnswerFile(ffblk.name) )
		return NULL;

	if (!strcmp(ffblk.name, ".") || 
		!strcmp(ffblk.name, ".."))
		return GetNext();
	return ffblk.name;
}

#else

struct ffblk ffblk;
char *
GetFirst (char *Directory)
{
	char Buffer[128];
	int rc;

	sprintf (Buffer, "%s\\*.*", Directory);

	rc = findfirst (Buffer, &ffblk, 0);
	
	if (rc != 0)
		return NULL;

	// Salteo los .ans que son los archivos de respuestas
	if ( !CheckIfAnswerFile(ffblk.ff_name) )
		return NULL;

	return ffblk.ff_name;
}

char *
GetNext (void)
{
   int rc = findnext (&ffblk);

	if (rc != 0)
		return NULL;

	// Salteo los .ans que son los archivos de respuestas
	if ( !CheckIfAnswerFile(ffblk.ff_name) )
		return NULL;

	return ffblk.ff_name;
}
#endif
#endif 

#if defined (UNIX) || defined (LINUX)

DIR *dirp;
struct dirent *dp;

char *
strlwr (char *s)
{
	char *org = s;

	if ( !s )
		return NULL;

	while (*s)
	{
		*s = tolower (*s);
		s++;
	}

	return org;
}

char *
GetFirst (char *Directory)
{
	if ( dirp )
	{
		// printf ("Cierro el directorio %s\n", Directory);
		closedir (dirp);
	}

	// printf ("Abro el directorio %s\n", Directory);

	dirp = opendir (Directory);

	if ( !dirp )
		return NULL;

	// Salteo las entradas . y .. 
	dp = readdir (dirp);
	dp = readdir (dirp);

	// printf ("GetFirst: dirp %X\n", dirp);

	return GetNext();
}

char *
GetNext (void)
{
	dp = readdir (dirp);

	if ( !dp )
		return NULL;

	// printf ("GetNext: dp %X %s\n", dp, dp->d_name);

	// Salteo los .ans que son los archivos de respuestas
	if ( !CheckIfAnswerFile(dp->d_name) )
		return NULL;

	return dp->d_name;
}

#endif

