int getopt(int argc, char *argv[], char *opt);
extern int optind, opterr;
extern char *optarg;

