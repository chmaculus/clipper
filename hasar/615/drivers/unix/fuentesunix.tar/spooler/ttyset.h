/*
ttyset.h
*/

#define SH_DENYNO 0

int    getch   (void);
int    sopen   (char *file, int flags, int sflags, int mode);
FILE * _fsopen (char *file, char *flags, int sflags);

