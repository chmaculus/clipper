/*

exitcode.h

Codigos de error devueltos por el spooler a traves 
de la funcion exit. 

*/

#define ERR_USAGE       	1	// Error en uso del spooler.
#define ERR_COMM            2	// Error de comunicaciones con la impresora.
#define ERR_ANSWER_FILE     3	// Error generando el archivo de respuestas.
#define ERR_COMMAND_FILE    4	// Error abriendo el archivo de comandos.
#define ERR_PORT            5	// No se pudo abrir el puerto serie
#define ERR_FISCAL_ERROR    6	// El comando no pudo ser ejecutado por 
								// un error en el status fiscal (campo
								// invalido, comando desconocido, etc.).
#define ERR_DETECTING       7	// Error detectando el controlador.
#define ERR_OPEN_SOCKET     8	// Error abriendo el socket.
#define ERR_CONNECTING      9	// Error conectando con el cliente.

