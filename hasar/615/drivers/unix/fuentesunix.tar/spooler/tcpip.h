/*
tcpip.h
*/

void SetIPPort      (int Port);
void IPServer 		(void);
void SendIPPacket 	(char *Command);
