/*
mysocket.c
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>

#ifdef SCO
#include <unistd.h>
#include <prototypes.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/netinet/in.h>
#include <sys/select.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <time.h>
#define closesocket close 

// Prototipos
static void delay 			(long mseg);
static void WaitForSend 	(void);
#endif 

#ifdef WIN32

#include <winsock.h>    // Incluye windows.h !!

#if defined(ERROR)
#undef ERROR
#endif

// Prototipos
static int  MyTimer 		(LPDWORD lpdwParam);
static int  VerifWinSock 	(void);
static void sleep 			(int seg);
static void delay 			(int mseg);
static HKEY GetIPKey        (void);

#endif 

#include "mysocket.h"

#define TRUE     	    1
#define FALSE    	    0
#define MAX_SOCKETS     20		         // Maxima cantidad de sockets a abrir.	
#define SIN_HOSTS       1                // 1 ==> No usa el archivo HOSTS.

struct sock 
{
	int sockfd;
	struct timeval val;
};

static int nsockets;					// Cantidad de sockets abiertos
static struct sock sockvars[MAX_SOCKETS];
static char netbuff[30];
static unsigned int IdTimer;
static long timeout;
static char *env;

static int dotimeout (int sockfd, struct timeval *t);
static int get_timeout(int sockfd);

// Abre un socket deteminado por el sistema

int
OpenPort (int socket_nr)
{
	int sockfd;
	struct sockaddr_in name;
	int n, arg = TRUE;
	int lenname;
	char buffer[200];
	long ThreadId;
	char *p;

#ifdef WIN32
	if ( !nsockets )
	   if (VerifWinSock () < 0)
		   return SOCK_ENOWINSOCK;
#endif

	if ((sockfd = socket (AF_INET, SOCK_DGRAM, 0)) < 0) 
		return SOCK_EOPEN;

	// Habilita la transmision en broadcast
	setsockopt (sockfd, 
		SOL_SOCKET, SO_BROADCAST, (char *)&arg, sizeof (arg));

	// Deshabilita el KEEP ALIVE 
	arg = FALSE;
	setsockopt (sockfd, 
		SOL_SOCKET, SO_KEEPALIVE, (char *)&arg, sizeof (arg));
   			   	
	memset ((char *)&name, 0, sizeof (name));
	name.sin_family = AF_INET;
	name.sin_addr.s_addr = htonl(INADDR_ANY);

	// Si socket_nr == 0 el sistema asigna un port sin usar
	name.sin_port = htons((unsigned short) socket_nr);

	if( (n=bind (sockfd, (struct sockaddr *)&name, sizeof (name))) < 0 )
	   return SOCK_EBIND;

	// lenname = sizeof (name);
	// getsockname (sockfd, (struct sockaddr *)&name, &lenname);
	// printf ("My socket = %u\n", ntohs (name.sin_port) );

	#ifdef WIN32
	++nsockets;
	#endif 

	if ( (env = getenv ("DELAY")) == NULL )
		timeout = 5;
	else 
		timeout = atoi (env);

	return sockfd;
}

// Envia un buffer a la direccion especificada por 'sin_addr' y el port 
// 'sin_port'.

int
SendTo (int sockfd, 
	char *Address, unsigned short sin_port, char *buff, int nbytes)
{
	struct sockaddr_in name;
	int err, lenname;
	static int prevaddr;	
	struct in_addr sin_addr;

	memset ((char *) &name, 0, sizeof (name));
	name.sin_family = AF_INET;
	name.sin_port = htons (sin_port);

	name.sin_addr.s_addr = inet_addr (Address);

	// printf ("Envio a %lX, port %d\n", name.sin_addr.s_addr, sin_port);
	// printf ("nbytes %d, Resp = %s\n", nbytes, buff);

	if ((err=sendto (sockfd, buff, nbytes, 0,
		 (struct sockaddr *) &name, sizeof (name))) != nbytes) 
	{
		printf ("error sendto: %d \n", err);
		return SOCK_ESEND;
	}

	return 0;
}

// Recibe un paquete del lan. La direccion del remitente queda en 
// la variable 'from', y el port 'sin_port'.

int
RecvFrom (int sockfd, 
	char *rem_addr, unsigned short *sin_port, char *buff, int nbytes)
{
	struct sockaddr_in from;
	struct in_addr sin_addr;
	int addrlen=sizeof(struct sockaddr);
	int result,n;
	int sock_id;
	unsigned char *address;

	/* Ver si hay que ejecutar un timeout */
	if ( (sock_id=get_timeout(sockfd)) >= 0 ) 
	{
		if ( (result = dotimeout (sockfd, &sockvars[sock_id].val)) < 0 )
			return SOCK_EGETTOUT;

		if ( !result ) 
			return SOCK_ETIMEOUT;
	}

	if ( (n = recvfrom (sockfd, 
		buff, nbytes, 0, (struct sockaddr *)&from, &addrlen)) < 0) 
	{
		printf ("Error rcvfrom %d\n", WSAGetLastError ());
		return SOCK_ERECV;
	}

	address = inet_ntoa (from.sin_addr);

	if ( address == (char *) INADDR_NONE )
		return -1;

	strcpy (rem_addr, address);
	*sin_port = ntohs (from.sin_port);

	// printf ("s_addr = %lX, %s\n", htonl(from.sin_addr.s_addr), inet_ntoa (from.sin_addr));
	// printf ("port   = %d\n", from.sin_port);
			
	return n;
}

// Cierra el port abierto.

void 
ClosePort (int sockfd)
{
   closesocket (sockfd); // cierro este socket

#ifdef WIN32 
	if ( nsockets )
		--nsockets;

	if ( nsockets )
		return;
#endif 
}

// Asigna el timeout a un socket.
// Retorna -1 si no hay mas ranuras para asignar el timeout 

int
socket_tout (int sockfd, unsigned int mseg)
{
	int i;
	
	for( i=0 ; i < MAX_SOCKETS ; i++)
	{
		if( sockvars[i].sockfd == sockfd )
		{
	    	sockvars[i].val.tv_sec  = mseg / 1000;
	    	sockvars[i].val.tv_usec = (mseg % 1000) * 1000; 
			return 0;
		}
	}
	
	for( i=0 ; i < MAX_SOCKETS ; i++)
	{
		if( sockvars[i].sockfd == 0 )
		{
			sockvars[i].val.tv_sec  = mseg / 1000;
	    	sockvars[i].val.tv_usec = (mseg % 1000) * 1000; 
			sockvars[i].sockfd = sockfd;
			return 0;
		}
	}
	
	return SOCK_ENOSOCK;
}

// ****** Rutinas de uso general *******

static int 
dotimeout (int sockfd, struct timeval *t)
{
   fd_set readfds;

   FD_ZERO (&readfds);
   FD_SET  (sockfd, &readfds);

   /*
    * select retorna: -1 si hubo error.
    *                  0 si hubo timeout.
    *                  != 0 si no hubo error.
    */

   return select (sockfd + 1, &readfds, NULL, NULL, t);
}

//  Retorna el indice al array donde se encuentra el timeout del socket.
//  Retorna -1 si el socket no tiene timeout 

static int 
get_timeout(int sockfd)
{
	static int last_id=-1;
	static int last_sockfd=-1;
	int i;
	
	if( sockfd == last_sockfd )
		return last_id;

	for(i=0 ; i < MAX_SOCKETS ; i++)	
		if( sockfd == sockvars[i].sockfd )
		{
			last_id = i;
			last_sockfd = sockfd;
			return i;
		}

	return -1;
}

#ifdef WIN32
// ------------- Windows  ------------

// Obtiene un HKEY abierto apuntando a un valor IPAddress v�lido.
// Devuelve NULL si no lo encontr�.

static HKEY
GetIPKey (void)
{
	char IPAddress[100];
	unsigned long SizeIP;
	static HKEY hkey;
	HKEY hRoot;
	int Index;
	char SubKey[300];
	int SubKeySize;

#define MAX_PROTOCOLS 10

	char *Root = "System\\CurrentControlSet\\Services\\Class\\NetTrans";

	if (RegOpenKeyEx(HKEY_LOCAL_MACHINE, Root, 0L, KEY_ENUMERATE_SUB_KEYS, &hRoot) != ERROR_SUCCESS)
		return NULL;

	for (Index = 0; Index < MAX_PROTOCOLS; Index++)
	{
		SubKeySize = sizeof(SubKey);

		if (RegEnumKeyEx(hRoot, Index, SubKey, &SubKeySize, NULL, NULL, NULL, NULL) != ERROR_SUCCESS)
			return NULL;

		if (RegOpenKeyEx(hRoot, 
			SubKey, 0L, KEY_QUERY_VALUE, &hkey) != ERROR_SUCCESS)
			continue;
				
		/*
		Encontr� una direcci�n de IP v�lida, y no es "0.0.0.0", es decir,
		una direcci�n de IP obtenida de un servidor de direcciones de IP,
		como el acceso telef�nico a redes.
		*/
		
		SizeIP = sizeof(IPAddress);
	
		if (RegQueryValueEx (hkey,	
							"IPAddress", 
							NULL, 
							NULL, 
							IPAddress, &SizeIP) == ERROR_SUCCESS 
			&& strcmp(IPAddress, "0.0.0.0"))
			break;
		
		RegCloseKey (hkey);
	}
	
	if (Index == MAX_PROTOCOLS)
		return NULL;
	
	return hkey;
}

/* Retorna la Direccion de IP de la maquina donde corre el programa */
static int  
gethostid(INADDR *ipaddr,long *mask)
{
	char IPAddress[100], Mask[100];
	unsigned long SizeIP, SizeMask;
	HKEY hkey;
	static INADDR ip;
	static long ipmask;

	if( ip ){
		*ipaddr = ip;
		*mask = ipmask;
		return 0;
	}

	if (!(hkey = GetIPKey()))
		return -1;

	SizeIP = sizeof(IPAddress);
	RegQueryValueEx (hkey, "IPAddress", NULL, NULL, IPAddress, &SizeIP);

	SizeMask = sizeof(Mask);
	RegQueryValueEx (hkey, "IPMask", NULL, NULL, Mask, &SizeMask);

	ip = *ipaddr = htonl(inet_addr(IPAddress));
	ipmask = *mask = htonl(inet_addr(Mask));
	RegCloseKey (hkey);
	return 0;
}

// Obtiene la direccion de IP de la PC.

char *
GetMyIpAddress (void)
{
	struct in_addr in;
	long   Mask;
	
	if ( gethostid (&in.s_addr, &Mask) )
		return NULL;

	in.s_addr = ntohl (in.s_addr);
	
	return inet_ntoa (in);
}

// Verifica que este cargado el WINSOCK.DLL version 1.1 o mayor.
static int
VerifWinSock (void)
{
	WORD wVersionRequested;
	WSADATA wsaData;
	int err;
    char bufmsg [512];

	wVersionRequested = 0x0101;

	err = WSAStartup(wVersionRequested, &wsaData);

	if (err != 0)
        /* Tell the user that we couldn't find a useable */
		/* winsock.dll.     */
        return -1;

    /* Confirm that the Windows Sockets DLL supports 1.1.*/
    /* Note that if the DLL supports versions greater */
    /* than 1.1 in addition to 1.1, it will still return */
    /* 1.1 in wVersion since that is the version we */
    /* requested. */

    if ( LOBYTE( wsaData.wVersion ) != 1 ||
            HIBYTE( wsaData.wVersion ) != 1 ) {
      /* Tell the user that we couldn't find a useable */
      /* winsock.dll. */
      WSACleanup();
      return -1; 
    }

	return 0;
}

// Hace un sleep en segundos (borland compatible)
static void
sleep (int seg)
{
   Sleep (seg * 1000);
}

// Hace un delay en milisegundos
static void
delay (int mseg)
{
   Sleep (mseg);
}

#endif

#ifdef SCO
// ------------- Unix SCO OpenServer  ------------
static void 
WaitForSend (void)
{
	static long count1, count2;
	static int first;
	long difftime;

	if ( !first ) 
	{
		count1 = clock ();
		first ++;
		nap (timeout);
		return;
	}	

	// clock retorna un valor en microsegundos
	count2 = clock ();

	if (count1 == count2) 
	{ 
		nap (timeout);
		count1 = count2;
		return;
	}

	if (count2 > count1) 
		difftime = count2 - count1;

	else if (count2 < count1)
		// Hizo wrap around
		difftime = 0x7fffffff - count1 + count2;

	if ( difftime < timeout ) 
	  	nap (difftime);

	count1 = count2;
	
	return;
}

void
delay (long mseg)
{
	nap (mseg);
}

#endif
