/*
ttyset.c
*/

#if defined (LINUX) || defined (UNIX)

#ifdef LINUX
#include <termios.h>
#endif

#ifdef UNIX
#include <prototypes.h>
#include <sys/termio.h>
#endif 

#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define O_BINARY  0
#define SH_DENYNO 0

#ifdef UNIX

static struct termio termio, orig_termio;

static void
restore_tty (void)
{
	ioctl (fileno(stdin), TCSETA, &orig_termio);
}

static void
set_tty(void)
{
	/* recordar condiciones originales de la tty */
	ioctl (fileno (stdin), TCGETA, &orig_termio);

	/* establecer condiciones */
	termio = orig_termio;
	termio.c_iflag = 0;
	termio.c_lflag = 0;
	termio.c_cc[VMIN] = 1;
	ioctl (fileno(stdin), TCSETA, &termio);

	atexit (restore_tty);
}

#endif 

#ifdef LINUX

struct termios Termios, OldTermios;

static void
restore_tty (void)
{
	tcsetattr (fileno(stdin), TCSANOW, &Termios);
}

static void
set_tty(void)
{
	tcgetattr (fileno(stdin), &OldTermios);
	memcpy (&OldTermios, &Termios, sizeof (OldTermios));
	cfmakeraw (&Termios);
	tcsetattr (fileno(stdin), TCSANOW, &Termios);
	atexit (restore_tty);
}

#endif 

int 
getch (void)
{
	char c;
	static int first_time = 1;

	if ( first_time ) 
	{
		set_tty ();
		first_time = 0;
	}

	read (fileno(stdin), &c, sizeof (c));

	return c;
}

int 
sopen (char *file, int flags, int sflags, int mode)
{
	return open (file, flags, mode);
}

FILE *
_fsopen (char *file, char *flags, int sflags)
{
    return fopen (file, flags);
}

#endif

