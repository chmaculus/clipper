/*
mysocket.h

Prototipos de las funciones de sockets mas amigables
*/

typedef unsigned long INADDR;

#define NEW_SOCK         0

#define SOCK_EOPEN   	-100  // Error al abrir el socket
#define SOCK_EBIND		-101	// Error en el bind
#define SOCK_ENHOST		-102	// Host no encontrado
#define SOCK_ESEND		-103  // Error de transmision 
#define SOCK_EGETTOUT	-104	// Error al ejecutar el timeout	
#define SOCK_ETIMEOUT	-105	// TIMEOUT
#define SOCK_ERECV      -106	// Error de recepcion
#define SOCK_ENOSOCK    -107	// No hay socket disponible
#define SOCK_ENOWINSOCK -108  // No se cargo el WINSOCK.DLL Ver 1.1

int RecvFrom (int sockfd, 
	char *rem_addr, unsigned short *sin_port, char *buff, int nbytes);
	
int SendTo (int sockfd, 
	char *Address, unsigned short sin_port, char *buff, int nbytes);

int  OpenPort  (int port);
void ClosePort (int sockfd);
	
// Setea timeout de recepcion.
int
socket_tout (
    int sockfd,             // fd de socket
    unsigned int mseg       // milisegundos
    );

int
set_socket(                 // Hace un bind con una direccion y numero de socket
    int sockfd,             // fd de socket
    int address,            // Direccion 
    int socket_nr           // Numero de socket
    );

#ifdef WIN32
void sleep (int seg);       // sleep en segundos (borland compatible)
void delay (int mseg);
char * GetMyIpAddress (void);
#endif

