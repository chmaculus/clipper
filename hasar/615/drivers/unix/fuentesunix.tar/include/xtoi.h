/*
xtoi.h
*/

unsigned short xtoi(char *num);
