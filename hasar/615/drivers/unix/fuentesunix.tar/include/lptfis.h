/*
    lptfis.h
*/

struct x {
	unsigned short bp, di, si, ds, es;
	unsigned short dx, cx, bx, ax;
	unsigned short ip, cs, flags;
};

struct h {
	unsigned short bp, di, si, ds, es;
	unsigned char dl, dh, cl, ch, bl, bh, al, ah;
	unsigned short ip, cs, flags;
};

typedef union  {
    struct x x;
    struct h h;
} INTERRUPT_REGS;
 
typedef unsigned short WORD;
typedef unsigned char BYTE;

typedef struct tagPSP
{
	WORD progexit;	    /* program exit point (INT 20h instruction) */
	WORD memsize;	    /* memory size in paragraphs */
	BYTE dummy1;	    /* unused */
	BYTE CPMent[5];	    /* CP/M entry point (FAR jump to 000C0h)
					    BUG: (DOS 2+) PSPs created by INT 21/AH=4Bh point
					    at 000BEh */
	void far *termaddr;	/* terminate address (old INT 22h) */
	void far *brkaddr;	/* break address (old INT 23h) */
	void far *criterr;	/* critical error handler (old INT 24h) */
	WORD parent;	    /* parent PSP segment */
	BYTE ftab[20];	    /* DOS 2+ open file table, FFh = unused */
	WORD envseg;	    /* DOS 2+ environment segment */
	void far *retaddr;	/* DOS 2+ process's SS:SP on entry to last INT 21 call */
	WORD maxfiles;	    /* DOS 3+ max open files */
	void far *ftabaddr;	/* DOS 3+ open file table address */
	void far *prevptr;	/* DOS 3+ pointer to previous PSP (default FFFFFFFFh in
					    3.x) used by SHARE in DOS 3.3 */
	BYTE dummy2[20];    /* unused by DOS versions <= 4.01 */
	BYTE fdisp[3];	    /* DOS function dispatcher (FAR routine)--CDh 21h CBh */
	BYTE dummy3[9];	    /* unused */
	BYTE fcb1[16];	    /* FCB1 filled in from first commandline argument
					    (when opened, overwrites following FCB) */
	BYTE fcb2[20];	    /* FCB2 filled in from first commandline argument
					    (when opened, overwrites command tail) */
	BYTE ctail[128];    /* 128 BYTEs command tail / default DTA buffer;
					    command tail is BYTE for length of tail, N BYTEs for the
					    tail, followed by a BYTE containing 0Dh */
}
PSP;

