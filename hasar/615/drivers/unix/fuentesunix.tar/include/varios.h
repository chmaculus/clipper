/* funciones varias */

/* funciones de DOS que faltan en Unix */

#if defined (X386)

/* myexit.c */
typedef void (*EXITFUNC)(void);

int atexit(EXITFUNC f);
void myexit(int status);
#ifndef MYEXIT
#define exit myexit
#endif

/* funcion delay */
#ifdef X386
#define delay(ms) nap((long) ms)
#endif

#endif

