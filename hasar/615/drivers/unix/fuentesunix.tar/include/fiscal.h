/*
fiscal.h
*/

// Estructura de respuesta fiscal.

struct resp_fiscal 
{
	char 			Stx;					// Comienzo del paquete.
	unsigned char 	Paquete;				// Numero del paquete.
	char 			Comando;                // Commando 
	char			field_sep;              // 0x1c 
	char 			printer_status[4];      // Status de printer.En hexa ascii 
	char 			field_sep1;             // 0x1c 
	char 			fiscal_status[4];      	// Status fiscal.En hexa ascii 
	char 			operandos;  			// Operandos adicionales. 
											// Depende del codigo de operacion 
};

// Estrucura utilizada para el protocolo nuevo, en donde
// se envia un ESC antes del codigo de operacion del comando

struct resp_fiscal_new
{
	char 			Stx;					// Comienzo del paquete. 
	unsigned char 	Paquete;				// Numero de paquete.
	char 			Escape;					// Caracter ESC.
	char 			Comando;                // Commando 
	char 			field_sep;              // 0x1c 
	char 			printer_status[4];      // Status de printer.En hexa ascii 
	char 			field_sep1;             // 0x1c 
	char 			fiscal_status[4];       // Status fiscal.En hexa ascii 
	char 			operandos;              // Operandos adicionales.
											// Depende del codigo de operacion
};


// Defines       
#define OK      			0
#define ERROR 				-1
#define TIMEOUT 			-2
#define TRUE 				1
#define FALSE 				0

#define MX_FISCAL 			500
#define START_PACKET 		0x20
#define END_PACKET 			0x7f
#define MAX_THRASH 			500 	// Caracteres de basura en comunicaciones 

#define ACK_RETRY       	2
#define ANS_RETRY       	3

#define TIMEOUT_FISCAL  	40      // 40 Ticks de Timeout ( 2 seg ).
#define TIMEOUT_FISCAL_MS	2000	// 2 segundos (2000 ms)

#define MAX_FISCAL_PORTS 	4


