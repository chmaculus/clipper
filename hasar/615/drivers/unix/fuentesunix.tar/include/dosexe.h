#ifndef DOSEXE_H
#define DOSEXE_H

typedef struct tagDOSEXEHDR
{
	WORD magic;		/* 4Dh, 5Ah signature (sometimes 5Ah, 4Dh) */
	WORD remainder;	/* image size remainder (program size mod 512, not 
  						including header) */
	WORD pages;		/* number of 512-byte pages needed to hold .EXE file
						(incl header) */
	WORD relitems;	/* number of relocation items */
	WORD hdrsize;	/* header size in paragraphs */
	WORD minpars;	/* minimum extra paragraphs needed */
	WORD maxpars;	/* maximum extra paragraphs needed */
	WORD SS;		/* stack segment */
	WORD SP;		/* stack offset */
	WORD checksum;	/* word checksum of entire file */
	WORD IP;		/* initial IP */
	WORD CS;		/* initial CS */
	WORD reltab;	/* offset of relocation table */
	WORD overlay;	/* overlay number */
}
DOSEXEHDR;

typedef struct tagPSP
{
	WORD progexit;	/* program exit point (INT 20h instruction) */
	WORD memsize;	/* memory size in paragraphs */
	BYTE dummy1;	/* unused */
	BYTE CPMent[5];	/* CP/M entry point (FAR jump to 000C0h)
					BUG: (DOS 2+) PSPs created by INT 21/AH=4Bh point
					at 000BEh */
	void far *termaddr;	/* terminate address (old INT 22h) */
	void far *brkaddr;	/* break address (old INT 23h) */
	void far *criterr;	/* critical error handler (old INT 24h) */
	WORD parent;	/* parent PSP segment */
	BYTE ftab[20];	/* DOS 2+ open file table, FFh = unused */
	WORD envseg;	/* DOS 2+ environment segment */
	void far *retaddr;	/* DOS 2+ process's SS:SP on entry to last INT 21 call */
	WORD maxfiles;	/* DOS 3+ max open files */
	void far *ftabaddr;	/* DOS 3+ open file table address */
	void far *prevptr;	/* DOS 3+ pointer to previous PSP (default FFFFFFFFh in
					3.x) used by SHARE in DOS 3.3 */
	BYTE dummy2[20];/* unused by DOS versions <= 4.01 */
	BYTE fdisp[3];	/* DOS function dispatcher (FAR routine)--CDh 21h CBh */
	BYTE dummy3[9];	/* unused */
	BYTE fcb1[16];	/* FCB1 filled in from first commandline argument
					(when opened, overwrites following FCB) */
	BYTE fcb2[20];	/* FCB2 filled in from first commandline argument
					(when opened, overwrites command tail) */
	BYTE ctail[128];/* 128 BYTEs command tail / default DTA buffer;
					command tail is BYTE for length of tail, N BYTEs for the
					tail, followed by a BYTE containing 0Dh */
}
PSP;

/* EXEC function:

 INT 21 - DOS 2+
     AH = 4Bh
     AL = subfunction
         00h load and execute program
         01h load but do not execute (internal)
		 03h load overlay (does not create PSP)
     DS:DX -> ASCIZ filename
     ES:BX -> parameter block (see below)

 Return: CF set on error
         AX = error code (01h,02h,05h,08h,0Ah,0Bh) (see AH=59h)
         CF clear if successful
         if subfunction 01h, process ID set to new program's PSP; get with
         INT 21/AH=62h
*/

/* Format of EXEC parameter block for AL=00h,01h: */

typedef struct tagEXEC_RUN
{
	WORD  envseg;	/* segment of environment (0 = use current) (see AH=26h) */
	void far *comline;	/* pointer to command line */
	void far *fcb1;		/* pointer to first FCB (see AH=0Fh) */
	void far *fcb2;		/* pointer to second FCB (see AH=0Fh) */
}
EXEC_RUN;

typedef struct tagEXEC_LOAD
{
	EXEC_RUN in;		/* input arguments */
	struct
	{
		void far *stkptr;	/* will hold initial SS:SP on return */
		void far *entry;	/* will hold entry point (CS:IP) on return */
	}
			out;		/* output arguments */
}
EXEC_LOAD;

#endif
