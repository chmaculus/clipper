/*
	winfis.h:
	
	Declaraciones de prototipos exportables de la DLL.
	
*/

#ifdef WIN32
	#define _export
#endif

int UltimaRespuesta (int Handler, char *Buffer);
int InitFiscal (int Handler);

#define MODE_ASCII	0
#define MODE_ANSI	1

