/*
unxcomm.h
*/

typedef struct
{
	int 			fdtty;
	#if 0
	struct termio 	Termio;
	struct termio 	OldTermio;
	#endif 
	char 			Buffer_Respuesta [MX_FISCAL];
	char 			Buffer_Transmision [MX_FISCAL];
	unsigned char   PacketNumber;
	char 			PortName[50];
	char 			Used;
}
PORTS;

// Maxima cantidad de ports a manejar
#define MAX_PORTS 	10

int  start_comm     (char *PortName);
void end_comm       (PORTS *Port);
int  SendByte       (PORTS *Port, char Byte);
int  SendCommand    (PORTS *Port, char *Com);
int  BufferEmpty 	(PORTS *Port);
int  GetByte        (PORTS *Port, unsigned char *Byte);
int  GetByteTimed   (PORTS *Port, unsigned char *Byte);
