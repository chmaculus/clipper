/*
	fisdebug.h
*/

void FISdebug (char *fmt,...);

void (* SetFISdebug (void (*NewDebugFunction)()) ) ();

void set_debug_options (int debug, int save, char *debfile);

