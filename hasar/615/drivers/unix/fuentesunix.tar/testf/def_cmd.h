/*****************************************************************************
**	modulo: 	   	def_cmd.h												**
**																			**
**	autor:			Pascual Di Candia										**
**																			**
**	descripcion:   	Definiciones de comandos.								***
**																			**
*****************************************************************************/

#ifndef _DEF_CMD
#define _DEF_CMD

/*--------------------------------------------------------------------------*/
/*	Tipos de comando
/*--------------------------------------------------------------------------*/
typedef enum {                  		/* Tipo de comando					*/
	TYP_INIDOC,							/* Inicio de un documento			*/
	TYP_ENDDOC,							/* Fin de un documento				*/
	TYP_ZDOC,							/* Cierre Z							*/
	TYP_CRDOC,							/* Cambio de responsabilidad iva	*/
	TYP_INGBRDOC,					    /* Cambio de Ingresos Brutos	    */
	TYP_DOC,							/* Comando de documento				*/
	TYP_SET_DATE,						/* Comando de cambio de fecha-hora	*/
	TYP_INIT_FM,						/* Comando de inicializacion		*/
	TYP_KILL_FM,						/* Comando de baja de mem fiscal	*/
	TYP_SETBAUD,						/* Comando de cambio de velocidad	*/
	TYP_LOGO,							/* Comando de carga de logo			*/
	TYP_OTHER							/* Otro...							*/
}	CMDTYPE;

/*--------------------------------------------------------------------------*/
/*	Tipos de salvado
/*--------------------------------------------------------------------------*/
typedef enum {
	SV_SAVE,
	SV_NOT_SAVE,
	SV_CON_SAVE
}	SAVE;

/*--------------------------------------------------------------------------*/
/*	Comandos fiscales de control atrapados por la tarea INPUT
/*--------------------------------------------------------------------------*/
#define	CMD_SETBAUD					0xa0	/* Cambio de velocidad 			*/
#define	CMD_STATPRN			  		0xa1	/* Status del printer  			*/

/*--------------------------------------------------------------------------*/
/*	Comandos de documentos fiscales
/*--------------------------------------------------------------------------*/
#define	CMD_OPEN_DF					0x40	/* Apertura de un doc fiscal	*/
#define CMD_PRINT_FISCAL_TEXT		0x41	/* Linea de desc. item adic.	*/
#define	CMD_PRINT_LINE_ITEM			0x42	/* Venta de un item				*/
#define CMD_LAST_ITEM_DISCOUNT		0x55	/* Descuento sobre ultimo item	*/
#define CMD_GENERAL_DISCOUNT		0x54	/* Descuento general			*/
#define CMD_PERCEPTIONS				0x60	/* Percepciones sobre el IVA	*/
#define CMD_CHARGE_NON_REG_TAX		0x61	/* Carga monto iva no inscripto	*/
#define CMD_RETURN_RECHARGE			0x6d	/* Bonificacion, recargo, dev	*/
#define CMD_SUBTOTAL				0x43	/* Subtotal						*/
#define CMD_TOTAL_TENDER			0x44	/* Total - Pago					*/
#define CMD_CLOSE_DF				0x45	/* Cierre de un doc fiscal		*/

/*--------------------------------------------------------------------------*/
/*	Comandos de documentos de auditoria
/*--------------------------------------------------------------------------*/
#define CMD_DAILY_CLOSE				0x39	/* Cierre de jornada fiscal	Z/X	*/
#define CMD_DAILY_CLOSE_BY_DATE		0x3a	/* Reporte de audit. por fecha	*/
#define CMD_DAILY_CLOSE_BY_Z_NUM	0x3b	/* Reporte de audit. por Z		*/
#define CMD_GET_DAILY_REPORT		0x3c	/* Reporte cierre Z individual	*/
#define CMD_HISTORY_CAPACITY		0x37	/* Reporte estado cierres z rem.*/

/*--------------------------------------------------------------------------*/
/*	Comandos de documentos no fiscales
/*--------------------------------------------------------------------------*/
#define CMD_OPEN_DNF_SLIP			0x47	/* Apertura de DNF en   Slip	*/
#define CMD_OPEN_DNF_TICKET			0x48	/* Apertura de DNF en Ticket	*/
#define CMD_PRINT_NON_FISCAL_TEXT	0x49	/* Imprimir texto no-fiscal		*/
#define CMD_CLOSE_DNF				0x4a	/* Cierre de un doc no fiscal	*/

/*--------------------------------------------------------------------------*/
/*	Comandos de documentos no fiscales homologados
/*--------------------------------------------------------------------------*/
#define CMD_OPEN_DNFH				0x80	/* Apertura de un dnf homologado*/
#define CMD_ITEM_REMIT				0x82	/* Item Remito / Orden salida	*/
#define CMD_ITEM_SUMARY				0x83	/* Item resumen cuenta			*/
#define CMD_ITEM_QUOTATION			0x84	/* Cotizacion					*/
#define CMD_CLOSE_DNFH				0x81	/* Cierre de un dnfh			*/
#define CMD_SET_VOUCH_DATA_1        0x6a	/* Carga Inicial Datos Voucher  */
#define CMD_SET_VOUCH_DATA_2	    0x6b	/* Carga Final   Datos Voucher  */
#define CMD_PRINT_VOUCH		        0x6c	/* Impresi�n de Voucher			*/

/*--------------------------------------------------------------------------*/
/*	Comandos de documentos de fabrica
/*--------------------------------------------------------------------------*/
#define CMD_GET_INIT_DATA			0x73	/* Reporte datos inicializacion	*/
#define CMD_KILL_EPROM				0xb1	/* Dar de baja el controlador	*/

/*--------------------------------------------------------------------------*/
/*	Comandos de configuracion
/*--------------------------------------------------------------------------*/
#define CMD_SET_LOGO_CUSTOM			0x90	/* Cargar el logo del cliente	*/
#define CMD_RES_LOGO_CUSTOM			0x91	/* Borrar el logo del cliente	*/
#define CMD_SET_CUSTOMER_DATA		0x62	/* Setear datos del cliente		*/
#define CMD_SET_FANTASY_NAME		0x5f	/* Setear nombre de fantasia 	*/
#define CMD_GET_FANTASY_NAME		0x92	/* Obtener nombre de fantasia	*/
#define CMD_SET_HEADER_TRAILER		0x5d	/* Setear encabezamiento y cola	*/
#define CMD_GET_HEADER_TRAILER		0x5e	/* Obtener lineas de hdr o tlr	*/
#define CMD_SET_REMIT_NUM_LINE		0x93	/* Carga numero de remito		*/
#define CMD_GET_REMIT_NUM_LINE		0x94	/* Obtener numero de remito		*/
#define	CMD_SET_BAR_CODE			0x5a	/* Setear codigo de barras		*/
#define CMD_CONFIG_CF_BY_BLOCK		0x65	/* Setear la configuraicon gral	*/
#define CMD_GET_CONFIG_DATA			0x66	/* Obtener la conf. general		*/
#define CMD_SET_CONFIG_FULL			0x95	/* Setear la conf. completa		*/
#define CMD_GET_CONFIG_FULL			0x96	/* Obtener la conf. completa	*/
#define CMD_CONFIG_CF_BY_ONE		0x64	/* Setear conf. individual		*/
#define CMD_SET_DATE_TIME			0x58	/* Setear fecha y hora			*/
#define CMD_GET_DATE_TIME			0x59	/* Obtener la conf. de hora		*/
#define CMD_CHANGE_IVA_RESP			0x63	/* Cambio de responsabilidad IVA*/
#define CMD_CHANGE_INGBR			0x6e	/* Cambio de Ingresos Brutos    */

/*--------------------------------------------------------------------------*/
/*	Comandos adicionales
/*--------------------------------------------------------------------------*/
#define CMD_SET_RECEIPT_INFO		0x97	/* Setea lineas de text en reci.*/
#define	CMD_STATUS_REQUEST	  		0x2a	/* Status fiscal del printer	*/
#define CMD_GET_CF_VERSION          0x7f	/* Obtener la version del pr	*/
#define	CMD_GET_WORKING_MEMORY		0x67	/* Obtener status de mem de tra.*/
#define CMD_SEND_FIRST_IVA_INFO		0x70	/* Obtener Inicio info IVA		*/
#define CMD_SEND_NEXT_IVA_INFO		0x71	/* Obtener resto de la info IVA	*/
#define CMD_CANCEL					0x98	/* Cancelar un documento		*/
#define CMD_COPIES					0x99	/* Copiar ultimo documento		*/

/*--------------------------------------------------------------------------*/
/*	Macros
/*--------------------------------------------------------------------------*/
#define IS_OPEN_CMD( cmd )	(	(	(cmd) == CMD_OPEN_DF 	        )	||	\
								(	(cmd) == CMD_OPEN_DNF_SLIP	    )	||	\
								(	(cmd) == CMD_OPEN_DNF_TICKET    )	||	\
								(	(cmd) == CMD_OPEN_DNFH 	        )		)

#define IS_RESET_COPIES( cmd )(	( 	!IsDocState()                   )	&&	\
							  (	(	(cmd) == CMD_KILL_EPROM			)	||	\
								(	IS_OPEN_CMD( cmd )				)	||	\
								(	(cmd) == CMD_DAILY_CLOSE		)	||	\
								(	(cmd) == CMD_DAILY_CLOSE_BY_DATE)	||	\
								(	(cmd) == CMD_DAILY_CLOSE_BY_Z_NUM)	||	\
							  	(	(cmd) == CMD_SET_LOGO_CUSTOM	)	||	\
								(	(cmd) == CMD_RES_LOGO_CUSTOM	)	||	\
								(	(cmd) == CMD_SET_CUSTOMER_DATA	)	||	\
								(	(cmd) == CMD_SET_FANTASY_NAME 	)	||	\
								(	(cmd) == CMD_SET_HEADER_TRAILER	)	||	\
								(	(cmd) == CMD_SET_REMIT_NUM_LINE	)	||	\
								(	(cmd) == CMD_SET_BAR_CODE		)	||	\
								(	(cmd) == CMD_SET_DATE_TIME		)	||	\
								(	(cmd) == CMD_CHANGE_IVA_RESP	)	||	\
								(	(cmd) == CMD_CHANGE_INGBR	    )	||	\
								(	(cmd) == CMD_SET_CONFIG_FULL	)	||	\
								(	(cmd) == CMD_CONFIG_CF_BY_BLOCK	)	||	\
								(	(cmd) == CMD_CONFIG_CF_BY_ONE	)	||	\
								(	(cmd) == CMD_SET_RECEIPT_INFO	)	||	\
								(	(cmd) == CMD_PRINT_VOUCH	    )	)	)

/*--------------------------------------------------------------------------*/
/*	Definiciones de parametros
/*--------------------------------------------------------------------------*/
#define	MAXPARAMS					20		/* Cantidad maxima de parametros*/

#define PARAM_00					0		/* Parametro numero 00			*/
#define PARAM_01					1		/* Parametro numero 01			*/
#define PARAM_02					2		/* Parametro numero 02			*/
#define PARAM_03					3		/* Parametro numero 03			*/
#define PARAM_04					4		/* Parametro numero 04			*/
#define PARAM_05					5		/* Parametro numero 05			*/
#define PARAM_06					6		/* Parametro numero 06			*/
#define PARAM_07					7		/* Parametro numero 07			*/
#define PARAM_08					8		/* Parametro numero 08			*/
#define PARAM_09					9		/* Parametro numero 09			*/
#define PARAM_10					10		/* Parametro numero 10			*/
#define PARAM_11					11		/* Parametro numero 11			*/
#define PARAM_12					12		/* Parametro numero 12			*/
#define PARAM_13					13		/* Parametro numero 13			*/
#define PARAM_14					14		/* Parametro numero 14			*/
#define PARAM_15					15		/* Parametro numero 15			*/
#define PARAM_16					16		/* Parametro numero 16			*/
#define PARAM_17					17		/* Parametro numero 17			*/
#define PARAM_18					18		/* Parametro numero 18			*/
#define PARAM_19					19		/* Parametro numero 19			*/

/*--------------------------------------------------------------------------*/
/*	Definiciones de valores de parametros de los comandos fiscales
/*--------------------------------------------------------------------------*/
#define DOUBLE_CHAR         0xf4			/* Flag Impresion Doble Ancho 	*/
#define CLR_LINE_CHAR		0x7f        	/* Flag Borrado Linea Programada*/

#define FIRSTLINE           1           	/* Primer Linea Programada		*/
#define LAST_TRAILER_LINE   20          	/* Ultima Linea de Trailer		*/

// Codigos de Identificacion de Alicuotas IVA ...
#define INSCRIPTO           'I'
#define NO_INSCRIPTO        'N'
#define EXENTO              'E'
#define NO_RESPONSABLE      'A'
#define MONOTRIBUTO         'M'
#define CONSUMIDOR          'C'
#define BIENESDEUSO         'B'
#define NO_CATEGORIZADO     'T'
#define NO_IVA              0xFF

// Codigos de Identificacion de Tipo de Documento del Cliente ...
#define CUITQUALIFIER       'C'
#define LEQUALIFIER         '0'
#define LCQUALIFIER         '1'
#define DNIQUALIFIER        '2'
#define PASQUALIFIER        '3'
#define CIQUALIFIER         '4'
#define NDQUALIFIER         ' '

// Opcion de configuracion general de comandos que generan impresion ...
#define CFG_PRINT_ON        'P'				/* Modo Impresion    Habilitada	*/
#define CFG_PRINT_OFF       'N'				/* Modo Impresion Deshabilitada	*/

// Valores de parametros del comando "CMD_CONFIG_CF_BY_ONE"
#define CFG_CHANGE_0    	'4'
#define CFG_LOPTIONS        '5'
#define CFG_CUTPAPER        '6'
#define CFG_PRINTMAR        '7'
#define CFG_RE_PRINT        '8'
#define CFG_NUMCOPIES       '9'
#define CFG_PAGOSALDO       ':'
#define CFG_SONIDO    	    ';'
#define CFG_ALTOHOJA    	'<'
#define CFG_ANCHOHOJA    	'='
#define CFG_ESTACIONREPXZ   '>'
#define CFG_MODOIMPRESION  	'?'

// Opciones posibles de Tipo de Corte de Papel ...
#define FUL_CUT				'F'
#define	PAR_CUT				'P'
#define NOT_CUT				'N'

// Opciones posibles de Tipo de Copia de Documentos ...
#define COPIES_0            '0'
#define COPIES_1            '1'
#define COPIES_2            '2'
#define COPIES_3            '3'
#define COPIES_4            '4'

// Opciones posibles de Altura de Hoja ...
#define ALTO_HOJA_MINI      'M'
#define ALTO_HOJA_CARTA     'C'
#define ALTO_HOJA_A4        'A'
#define ALTO_HOJA_OFICIO    'O'

// Opciones posibles de Anchura de Hoja ...
#define ANCHO_HOJA_MINI     'M'
#define ANCHO_HOJA_NORMAL   'N'

// Opciones posibles de Estaci�n de Impresi�n ...
#define TICKET_STATION	    'T'				/* Estaciones Receipt/Journal	*/
#define SLIP_STATION		'S'				/* Estaciones Slip/Tractor	    */

// Opciones posibles de Modo de Impresi�n ...
#define MODO_MIXTO          'M'
#define MODO_320_PURO       'A'

// Tipos de documentos ...
#define FACTURA_A			'A'				/* Factura de tipo A			*/
#define FACTURA_BC			'B'				/* Factura de tipo B o C		*/
#define RECIBO_A			'a'				/* Recibo tipo A				*/
#define RECIBO_BC			'b'				/* Recibo tipo B o C			*/
#define NOTA_DEBITO_A		'D'				/* Nota de debito tipo A		*/
#define NOTA_DEBITO_BC		'E'				/* Nota de debito tipo B o C	*/
#define NOTA_CREDITO_A		'R'				/* Nota de credito tipo A		*/
#define NOTA_CREDITO_BC		'S'				/* Nota de credito tipo B o C	*/
#define TIQUE_BC			'T'				/* Tique Factura de tipo B o C  */

// Valores del parametro de display ...
#define DSP_NO_MODIF		'0'				/* No modifica 					*/
#define DSP_ESCRIBE			'1'				/* Escribe en el display		*/
#define DSP_INC_CNT_REP		'2'				/* Incrementa cnt. repeticiones	*/

// Valores del parametro de suma-resta ...
#define SUMA_MONTO			'M'				/* Suma monto					*/
#define RESTA_MONTO			'm'				/* Resta monto					*/

// Pago o cancelacion ...
#define CANCELAR			'C'				/* Cancelar venta total			*/
#define VUELTO				'T'				/* Vuelto						*/

// Tipos de cierre ...
#define CLOSE_X				'X'				/* Cierre parcial X				*/
#define CLOSE_Z				'Z'				/* Cierre diario Z				*/

// Reportes de auditoria ...
#define GLOBAL_REPORT		'T'				/* Reporte global				*/
#define Z_DISCRIM_REPORT	'Z'				/* Reporte discriminado por Z	*/

// Operaciones de carga de logo ...
#define	COMIENZO_CARGA_LOGO	'I'				/* Inicio de carga de logotipo	*/
#define	CARGA_LOGO_EN_CURSO	'C'				/* Carga en transcurso			*/
#define	FIN_CARGA_LOGO		'F'				/* Ultimo paquete del logotipo	*/

// Carga de codigo de barras ...
#define IMPRIME_NUMEROS		'N'				/* Imprime numeros en el codbar	*/
#define IMPRIME_CODBAR		'P'				/* Imprime codigo de barras		*/
#define PROGRAMA_CODBAR		'G'				/* Programa codigo de barras	*/

// Definiciones vinculadas al documento Voucher ...
// Tipo de Operaci�n ...
#define COMPRA              'C'         // Compra ...
#define VOIDCOMPRA          'V'         // Anulaci�n de Compra ...
#define DEVOLUCION          'D'         // Devoluci�n ...
#define VOIDDEVOLUCION      'A'         // Anulaci�n de Devoluci�n ...
// Tipo de Tarjeta ...
#define DEBITO              'D'         // Tarjeta de  Debito ...
#define CREDITO             'C'         // Tarjeta de Credito ...
// Tipo de Operaci�n ...
#define ONLINE              'N'         // Operaci�n On  Line ...
#define OFFLINE             'F'         // Operaci�n Off Line ...
// Tipo de Carga de Datos ...
#define MANUAL              '*'         // Carga     Manual ...
#define AUTOMATICA          ' '         // Carga Autom�tica ...

/*--------------------------------------------------------------------------*/
/*	Definiciones de valores de configuracion por defecto
/*--------------------------------------------------------------------------*/
#define DEF_FANTASY_FLAG			FALSE

#define DEF_EPROM_FLAG				FALSE
#define DEF_EPROM_NUMBER			""
#define DEF_EPROM_NAME				""
#define DEF_EPROM_SERIAL			""
#define DEF_EPROM_DATE				""
#define DEF_EPROM_POS				""
#define DEF_EPROM_ACTIVITY			""
#define DEF_EPROM_ING_BRUTOS		""
#define DEF_EPROM_IVA_RESP			'I'

#define DEF_HDR_FLAG				FALSE

#define DEF_CLIENTE_FLAG			FALSE

#define DEF_REMITO_FLAG				FALSE

#define DEF_TR_FLAG					FALSE

#define DEF_CFG_IVA_RESP			DEF_EPROM_IVA_RESP
#define DEF_CFG_LIMIT_CONS_FINAL	1000.00
#define DEF_CFG_LIMIT_TICK_FACT		5000.00
#define DEF_CFG_PORCENT_IVA_NO_INS	50.00
#define DEF_CFG_COPIAS_DOC			COPIA_DUP
#define DEF_CFG_CAMBIO_CERO_FLAG	TRUE
#define DEF_CFG_LINEAS_OPC_FLAG		TRUE
#define DEF_CFG_TIPO_CORTE_PAPEL	'F'
#define DEF_CFG_MARCO_FLAG			FALSE
#define DEF_CFG_RE_IMPRESION_FLAG	TRUE
#define DEF_CFG_DESC_PAGO_SALDO	    "Cuenta Corriente"
#define DEF_CFG_SONIDO_FLAG	        TRUE
#define DEF_CFG_ALTO_HOJA	        ALTO_HOJA_MINI
#define DEF_CFG_ANCHO_HOJA	        ANCHO_HOJA_NORMAL
#define DEF_CFG_ESTACION_REP_XZ	    TICKET_STATION
#define DEF_CFG_MODO_IMPRESION	    MODO_MIXTO


// *****
// ACA VAN LOS VALORES DEFAULT DE LA ESTRUCTURA VOUCHER ...
// *****


#define DEF_ITEM_DESC_FLAG			FALSE

#define DEF_MEDIO_PAGO_FLAG			FALSE

#define DEF_RECIBO_TXT_FLAG			FALSE

#define DEF_RECIBO_CON_TXT_FLAG		FALSE

#define DEF_PERCEPTION_FLAG			FALSE

#define DEF_PERC_DESCRIPT_FLAG		FALSE

#define DEF_CODE_BAR_FLAG			FALSE

#define DEF_ALIC_IVA				NO_IVA_LOAD
#define DEF_MONTO_IVA				0
#define DEF_MONTO_IIVAR				0
#define DEF_MONTO_IIFIX				0
#define DEF_MONTO_BI				0
#define DEF_MONTO_PERCEP			0
#define DEF_MONTO_IVA_NO_I			0

#define DEF_Z_NUMBER				0
#define DEF_X_NUMBER				0
#define DEF_FIRST_DOC_NUM			0
#define DEF_FIRST_DNFH_NUM			0
#define DEF_DOC_GEN_CNT				0
#define DEF_DOC_TMP_CNT				0
#define DEF_DOC_GEN_CANCEL_CNT		0
#define DEF_DOC_TMP_CANCEL_CNT		0
#define DEF_DOC_NUM_CNT				0
#define DEF_BLOCK_GEN_CNT			0
#define DEF_BLOCK_TMP_CNT			0
#define DEF_DOC_BC_NUM_CNT			0
#define DEF_DOC_A_NUM_CNT			0
#define DEF_ALIC_IVA_CNT			0
#define DEF_PFT_LINES_CNT			0
#define DEF_MEDIOS_PAGO_CNT			0
#define DEF_SEND_IVA_TAB_INDEX		0
#define DEF_SEND_IVA_TAB_ID			-1

#define DEF_M_VENTA_DIA				0
#define DEF_M_IVA_DIA				0
#define DEF_M_II_DIA				0
#define DEF_M_IVA_NO_I_DIA			0
#define DEF_M_PERC_GEN_DIA			0
#define DEF_M_VENTA_REPX			0
#define DEF_M_IVA_REPX				0
#define DEF_M_II_REPX				0
#define DEF_M_PERC_REPX				0
#define DEF_M_IVA_NO_I_REPX			0
#define DEF_M_VENTA_DOC_V			0
#define DEF_M_VENTA_DOC_N			0
#define DEF_M_SUBTOTAL_DOC			0
#define DEF_M_REDONDEO_T			0
#define DEF_M_REDONDEO_BI			0
#define DEF_ITEM_QTTY_CNT			0

#define DEF_CF_STATE				0
#define DEF_CF_NEXT_STATE			0
#define DEF_CF_BLOQ_CAUSE			NO_BLOQ

#define DEF_PRINTER_STATUS			0xC080
#define DEF_FISCAL_STATUS			0x0000
#define DEF_DGI_ACTIVE				FALSE
#define DEF_IVA_NO_I_LOAD			FALSE
#define DEF_STOPSALE_FLAG			FALSE
#define DEF_DOCUMENT_TYPE			0
#define DEF_DOCUMENT_STATION		TICKET_STATION

#define DEF_DOC_A_GEN_FLAG		    FALSE

#define DEF_WAIT_IDLE				TRUE
#define DEF_WAIT_SET_DATE			TRUE
#define DEF_WAIT_CHG_IVA			TRUE
#define DEF_WAIT_CHG_INGBR			TRUE

#define DEF_RECORDZ_WRITE_FLAG		FALSE
#define DEF_Z_ADDRESS				FISCALRECORDORG
#define DEF_EPROM_CRC				0
#define DEF_W_MEM_CRC				0

#define DEF_LOGO_FILE_SIZE			0
#define DEF_LOGO_STATE				LOGO_DISABLED	

#define DEF_PRINT_CMD				0

#define DEF_COPY_CNT				0
#define DEF_DO_COPY					FALSE

#define DEF_CMDLIST_TYPE			COPY 
#define DEF_CMDLIST_OFFSET			0 

#endif /* _DEF_CMD */
