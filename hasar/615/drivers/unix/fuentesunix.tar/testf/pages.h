/*
pages.h
*/

#define PAGINA_1 1
#define PAGINA_2 2
#define PAGINA_3 3

#define MAX_PAGES 3
