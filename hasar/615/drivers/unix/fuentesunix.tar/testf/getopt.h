int getopt(int argc,char **argv,char *opts);
extern int optind, opterr;
extern char *optarg;

