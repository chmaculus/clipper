#include <stdio.h>
#include <stdlib.h>
#include <string.h>

extern void EpromInit (void);
extern void EpromReadByte (unsigned char *dataptr, unsigned long address);

void 
main (void)
{
	long N;
	long size = 512 * 1024L;
	char c;
	FILE *fp;
	
	if ( !(fp = fopen ("epr.dat", "wb")) )
	{
		printf ("Error abriendo epr.dat\n");
		exit (1);
	}
	
	EpromInit ();
	
	for ( N = 0; N < size; N ++ )
	{
		EpromReadByte (&c, N);
		putc (c, fp);
		if ( !(N % 10000) )
			printf ("%ld.", N);
	}
	
	printf ("\n");
}
