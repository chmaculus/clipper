/*
chile.h
*/

#define CMDCH_KILL_EPROM   	'B'
#define CMDCH_STATUS		'S'
#define CMDCH_ABRIR_DF     	'F'
#define CMDCH_CERRAR_DF    	'G'
#define CMDCH_ABRIR_DNF    	'N'
#define CMDCH_CERRAR_DNF   	'M'
#define CMDCH_IMPRIMIR     	'P'
#define CMDCH_CORTAR        'C'
#define CMDCH_AVANZAR       'A'
#define CMDCH_ABRIR_CAJON   'D'
#define CMDCH_X             'X'
#define CMDCH_Z             'Z'
#define CMDCH_INTERLINEADO  'T'

// *********************************************************************
// ********************* Formato de los comandos   *********************
// *********************************************************************

Formatos KillEprom_Ch [] =
{
	"N�mero de caja  (XXXX) : ", 	 		NULL, NULL,
	"N�mero de serie (SSSSSSSS) : ", 		NULL, NULL,
	NULL, 							 		NULL, NULL
};

Formatos CerrarDf_Ch [] = 
{
	"Total de la boleta (XXXXXXXXXX) : ",   NULL, NULL,	
	NULL, 							 		NULL, NULL
};

Formatos AbrirDnf_Ch [] = 
{
	"Estaci�n de impresi�n\n"
	
	"'T' .... Ticket\n"
	"'S' .... Slip : ",                     NULL, NULL,
	
	NULL, 							 		NULL, NULL
};

Formatos Imprimir_Ch [] =
{
	"Texto (88 caracteres) : ",				NULL, NULL,
	
	"\nModo de Impresi�n\n"
	"'S' .... Simple ancho\n"
	"'D' .... Doble ancho : ",              NULL, NULL,
	
	"\nEstaci�n \n"
	"'T' .... Ticket\n"
	"'A' .... Auditor�a\n"
	"'M' .... Ambas\n"
	"'S' .... Slip : ",                     NULL, NULL,
	
	NULL,                                   NULL, NULL
};

Formatos Avanzar_Ch [] = 
{
	"Cantidad de l�neas (XX) : ",           NULL, NULL,

	"\nEstaci�n \n"
	"'T' .... Ticket\n"
	"'A' .... Auditor�a\n"
	"'M' .... Ambas\n"
	"'S' .... Slip : ",                     NULL, NULL,

	NULL,                                   NULL, NULL
};

Formatos Interlineado_Ch [] =
{
	"Interlineado (1 - 255) : ",            NULL, NULL,
	NULL,                                   NULL, NULL
};

// *********************************************************************
// ********************* Respuestas a los comandos *********************
// *********************************************************************

char *Respuesta_Ch [] = 
{
	"N�mero de �ltima boleta", 
	"Estado auxiliar del controlador fiscal", 
	"N�mero de zeta", 
	"Total del d�a",
	"Gran total",
	"N�mero de caja", 
	"N�mero de serie"
};

// *********************************************************************
// ********************* Set de comandos           *********************
// *********************************************************************


COMMANDSET CommandSet_Chile[] =
{
	{ '1', 
	CMDCH_STATUS, "Status Fiscal", NULL, NULL, Respuesta_Ch },

	{ '2', 
	CMDCH_ABRIR_DF,	"Abrir Documento Fiscal", NULL, NULL, Respuesta_Ch },

	{ '3', 
	CMDCH_IMPRIMIR, "Imprimir", Imprimir_Ch, NULL, Respuesta_Ch },

	{ '4', 
	CMDCH_CERRAR_DF, "Cerrar Documento Fiscal", CerrarDf_Ch, NULL, Respuesta_Ch },

	{ '5', 
	CMDCH_ABRIR_DNF, "Abrir Documento No Fiscal", AbrirDnf_Ch, NULL, Respuesta_Ch },

	{ '6', 
	CMDCH_CERRAR_DNF, "Cerrar Documento No Fiscal", NULL, NULL, Respuesta_Ch },

	{ '7', 
	CMDCH_X, "Cierre Diario X", NULL, NULL, Respuesta_Ch },

	{ '8', 
	CMDCH_Z, "Cierre Diario Z", NULL, NULL, Respuesta_Ch },

	{ 'a', 
	CMDCH_KILL_EPROM, "Baja de controlador fiscal", KillEprom_Ch, NULL, Respuesta_Ch },
	
	{ 'b', 
	CMDCH_CORTAR, "Cortar Papel", NULL, NULL, Respuesta_Ch },

	{ 'c', 
	CMDCH_AVANZAR, "Avanzar Papel", Avanzar_Ch, NULL, Respuesta_Ch },

	{ 'd', 
	CMDCH_ABRIR_CAJON, "Abrir Caj�n", NULL, NULL, Respuesta_Ch },

	{ 'e',
	CMDCH_INTERLINEADO, "Fijar interlineado de slip", Interlineado_Ch, NULL, Respuesta_Ch },
	

	{ ANY, 0, "", NULL, NULL, NULL }
};


STATAUX_LOW StAuxChile[] = 
{
	'U',  "Impresor no inicializado",
	'B',  "Impresor dado de baja",
	'I',  "Inicio de jornada fiscal",
	'J',  "Impresor en jornada fiscal",
	'F',  "Impresor en documento fiscal",
	'N',  "Impresor en documento no fiscal",
	'S',  "Impresor bloqueado",
	-1,   NULL
};
