/* modulo split.c */
int split( char *buf, char **field, int nfields );
char *setfs( char *newfs );

/* modulo fsplit.c */
int fsplit( char *buf, char **field, int nfields );
char *fsetfs( char *newfs );

/* modulo nfsplit.c */
int nfsplit(char *buf, char **field, int nfields);
char *nfsetfs(char *newfs);
