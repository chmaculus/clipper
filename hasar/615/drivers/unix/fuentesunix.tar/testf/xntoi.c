#include <ctype.h>

/* Convierte un numero hexa ascii de 4 bytes en su equivalente entero */

int 
xntoi (char *num, int len)
{
	int n, i;
	
	for (i = 0, n = 0 ; i < len ; i++, num++)
	{
		n <<= 4;
		n |= (isdigit(*num) ? *num - '0' : toupper(*num)-'A'+ 0xa);
	}
	
	return n;
}
