/*
cmds.c
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#if defined (UNIX) || defined (LINUX)
#include <unistd.h>
#include <curses.h>
#endif 

#ifdef UNIX 
#include <prototypes.h>
#endif

#ifdef DOS
#include <dos.h>
#include <conio.h>
#endif

#include "testf.h"
#include "ascii.h"
#include "split.h"

#ifdef DOS
#include "fislib.h"
#include "comm.h"
#endif 

#ifndef DOS
#include "unxlib.h"
#endif

#ifdef LINUX

#undef delay

#include <sys/time.h>

void
delay (long msec)
{
	struct timeval tv;

	tv.tv_sec = 0;
	tv.tv_usec = msec * 1000;

	select (0, NULL, NULL, NULL, &tv);
}

#endif 

long Baudios [] =
{
	9600, 19200, 38400, 

	#if !defined (UNIX) && !defined (LINUX)
	57600, 115200, 	// No soportado en Unix OpernServer 5.0
					// Tampoco anduvo en Linux. 
	#endif

	4800, 2400, 1200 
};

#define MAX_BAUDS  (sizeof (Baudios) / sizeof (long))

static int FlagNewProtocol;

extern int 				CommHandler;
extern int 				Version;
extern unsigned short 	FiscalStatus;
extern unsigned short 	PrinterStatus;
extern char    			FiscalAnswer[500];
extern long    			BaudRate;

extern int SendByte (int PortNumber, int Byte);

void
ChangeBauds (void)
{
	int len;
	char *NewBaud;

	CommandHeader ("Cambio de Velocidad", CMD_SETBAUD);
	
	NewBaud = Ask ("Nueva Velocidad : ", &len, TRUE);

	if ( len != 0 )
		SetNewBaud (atol (NewBaud));
	
	WaitKey ("\nPresione una tecla para continuar...\n");
}

void
KillEprom (void)
{
	int c;
	
	ShowLine ("\n\n\n\n\n");
	ShowLine ("###############################\n");
	ShowLine ("#   P R E C A U C I O N !!!   #\n");
	ShowLine ("###############################\n");
	ShowLine ("\n\n\n");

	ShowLine ("Est� seguro de dar de baja el Controlador Fiscal ? (s/n)... ");

	while (1)
	{
		c = tolower (Getch());

		if ( c == 's' )
		{
			MakeCommand (CMD_KILL_EPROM, NULL, NULL, NULL);
			break;
		}
		
		if ( c == 'n' )
			break;
	}
}

void 
SendACK (void)
{
	SendByte (CommHandler, ACK);
}

void 
NewProtocol (void)
{
	FlagNewProtocol ^= 0xFF;
	SetNewProtocol (FlagNewProtocol);
}

int 
SetNewBaud (long NewBaud)
{
	int i;
	int Result;
	char Buffer[10];
	
	for ( i = 0; i < MAX_BAUDS; i ++ )
		if ( NewBaud == Baudios[i] )
			break;
				
	if ( i == MAX_BAUDS )
	{
		ShowLine ("\nIntenta fijar una velocidad incorrecta !\n");

		ShowLine ("\nVelocidades posibles: \n");

		for ( i = 0; i < MAX_BAUDS; i ++ )
			ShowLine ("%ld ", Baudios[i]);

		ShowLine ("\n");

		return -1;
	}
	
	ShowLine ("Inicializando a %ld baudios \n", NewBaud);

	sprintf (Buffer, "%c%c%ld", CMD_SETBAUD, SEP, NewBaud);

	MandaPaqueteFiscal (CommHandler, 
		Buffer, &FiscalStatus, &PrinterStatus, FiscalAnswer);

	delay (50);
		
	if ( !(Result = SetBaudRate (CommHandler, NewBaud)) )
		BaudRate = NewBaud;

	return Result;		
}


int 
CheckController (void)
{
	char Command [10];
	int i, Error = 0;
	int OldRet;
	struct version *version;
	
	int  nFields;
	char *Fields[50];
	char *NewFs = {"\x1c" "\n"};
	char *OldFs;

	ShowLine ("Buscando Controlador Fiscal ");

	OldRet = SetCommandRetries (1);
		
	// Manda un comando de status a las distintas velocidades 
	// hasta que el printer responde.
		
	for (i = 0; i < MAX_BAUDS; i ++ )
	{
		ShowLine (".");
		
		if ( kbhit () && Getch () == ESC )
			exit (1);
		
		SetBaudRate (CommHandler, Baudios[i]);
			
		sprintf (Command, "%c", CMD_STATUS_REQUEST);

		if ( !MandaPaqueteFiscal (CommHandler, 
			Command, &FiscalStatus, &PrinterStatus, FiscalAnswer) )
			break;
	}
	
	if ( i == MAX_BAUDS )
	{
		ShowLine ("\nEl controlador fiscal NO fue encontrado !\n");
		exit (1);
	}

	BaudRate = Baudios[i];
	
	ShowLine ("\nControlador fiscal detectado a %ld baudios\n", Baudios[i]);
		
	OldFs = setfs (NewFs);
	nFields = split (FiscalAnswer, Fields, 50);
	setfs (OldFs);


	// Manda el comando de version para determinar de que 
	// printer se trate.
		
	sprintf (Command, "%c", CMD_GET_CF_VERSION);

	version = (struct version *) &FiscalAnswer;

	delay (500);
	
	if ( !MandaPaqueteFiscal (CommHandler, Command, &FiscalStatus, 
		&PrinterStatus, FiscalAnswer) )
	{
		// Veo si es comando invalido.
		if ( FiscalStatus & 0x0008 )
		{
			// Puede ser un 614 o un 615, dado que esta serie de
			// impresores NO reconocen este comando.
			// Si la respuesta al status son 3 campos, se trata de un 614, en 
			// donde el ultimo campo es el ultimo ticket generado. 

			if ( nFields == 3 ) 
			{
				ShowLine ("Version : Serie de Impresores %s\n", PRN_614);
				Version = VER_PRN_614_950_262;
			}
			else 
			{
				ShowLine ("Version : Serie de Impresores %s\n", PRN_615);
				Version = VER_PRN_615_951_PR4;
			}
		}

		else if ( strstr (version->Version,	PRN_PJ20) )
		{
			ShowLine ("Version : %s\n", version->Version);
			NewProtocol ();
			Version = VER_ARTJET;
		}

		else if ( strstr (version->Version,	PRN_320) )
		{
			ShowLine ("Version : %s\n", version->Version);
			NewProtocol ();
			Version = VER_PRN320;
		}

		else if ( strstr (version->Version,	PRN_321) )
		{
			ShowLine ("Version : %s\n", version->Version);
			NewProtocol ();
			Version = VER_PRN321;
		}

		else if ( strstr (version->Version, PRN_NCR) )
		{
			ShowLine ("Version : %s\n", version->Version);
			NewProtocol ();
			Version = VER_NCR;
		}

		else if ( strstr (version->Version, PRN_CHILE) )
		{
			ShowLine ("Version : %s\n", version->Version);
			Version = VER_CHILE;
		}

		else if ( strstr (version->Version, PRN_425) )
		{
			ShowLine ("Version : %s\n", version->Version);
			NewProtocol ();
			Version = VER_PRN425;
		}

		else if ( strstr (version->Version, PRN_PL8F) )
		{
			ShowLine ("Version : %s\n", version->Version);
			NewProtocol ();
			Version = VER_OKIPAGE;
		}
		
		else 
		{
			ShowLine ("Impresor \"%s\" NO reconocido\n", version->Version);
			exit (1);
		}

		sleep (2);
	}
	
	else
	{ 
		ShowLine ("No hay comunicaci�n con el controlador\n");
		exit (1);
	}

	SetCommandRetries (OldRet);

	return Error;
}

