#include <stdio.h>
#include <stdarg.h>
#include <string.h>
#include <stdlib.h>
#include <fcntl.h>
#include <io.h>

#include "getopt.h"
#include "rtcom.h"

char Uso [] = "Uso: %s file\n";

#define BUFFER_SIZE 1000

#define MAX_BAUDS 7

long Baudios [MAX_BAUDS] =
{
	2400,
	4800,
	9600,
	19200,
	38400,
	57600,
	115200,
};

static int  Port 	 	= 1;
static long BaudRate 	= 9600L;
static int  Parity	 	= PARITY_NONE; 
static int  StopBits	= 1;
static int  WordLength	= 8;

int SndFile (char *file);

void 
Fatal (char *format, ... )
{
    va_list argptr;

    va_start (argptr, format);
	vprintf (format, argptr);
    va_end (argptr);

	exit (1);
}

int 
main (int argc, char *argv[])
{
	int n, i;
	char *PrgName = argv[0];
	int rc;
	char *file;
	
	while ( (n = getopt(argc, argv, "p:b:")) != EOF )

		switch (n) 
		{	
			case 'p':

				Port = atoi (optarg);

				if ( Port < 1 || Port > 4 )
					Fatal ("El COM serie debe estar entre 1 y 4\n");

				break;
			
			case 'b':
			
				BaudRate = atol (optarg);
			
				for ( i = 0; i < MAX_BAUDS; i ++ )
					if ( BaudRate == Baudios[i] )
						break;
					
				if ( i == MAX_BAUDS )
					Fatal ("Seteo de velocidad inv�lido : %ld\n", BaudRate);
			
				break;
			
			default:

				Fatal (Uso, PrgName);			
				break;
		}

	argc -= optind;
	argv += optind;
	
	if ( argc == 0 )
		Fatal (Uso, PrgName);

	file = argv[0];

	Port -= 1;
	
	rc = InitPort (Port, BaudRate, Parity, StopBits, WordLength);

	if (rc < 0)
	{
		printf ("InitPort fall� (rc %d)", rc);
		return -1;
	}

	if ((rc = EnableCOMInterrupt (Port, BUFFER_SIZE)) < 0)
	{
		printf ("EnableCOMInterrupt fall� (rc %d)", rc);
		return -1;
	}

	return SndFile (file);
}

int 
SndFile (char *file)
{
	int Result;
	char c;
	long SizeFile, N;
	char buf[20];
	int i, len;
	int fd = open (file, O_BINARY | O_RDONLY);
	
	if ( fd < 0 )
		Fatal ("Error abriendo %s\n", file);
		
	SizeFile = lseek (fd, 0L, SEEK_END);
	
	lseek (fd, 0L, SEEK_SET);	

	sprintf (buf, "%07ld\r\n", SizeFile);
	
	len = strlen (buf);
	
	// Mando el tama�o del archivo
	for (i = 0; i < len; i ++ )
		if ( (Result = WriteChar (Port, buf[i])) < 0 )
			Fatal ("WriteChar Error : %d\n", Result);
		
	// Mando el archivo
	for ( N = 0; N < SizeFile; N ++ )
	{
		if ( read (fd, &c, 1) < 0 )
			Fatal ("Error leyendo de %s\n", file);
		if ( (Result = WriteChar (Port, c)) < 0 )
			Fatal ("WriteChar Error : %d\n", Result);
		delay (3);
		if ( !(N % 20) )
			printf ("Transmitiendo %ld de %ld\r", N, SizeFile);
	}

	printf ("Transmitiendo %ld de %ld\n", N, SizeFile);
	
	return 0;
}
