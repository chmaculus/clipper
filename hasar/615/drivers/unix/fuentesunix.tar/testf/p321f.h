/*

p321f.h


Este archivo define ciertos comandos que fueron modificados a
la version de controlador 320F. El resto de los comandos, que 
no estan en este archivo, coinciden con aquellos que utiliza 
el 320. 

*/

Formatos Set_Config_Full_321 [] = 
{
	"Calif. de Impresi�n de Reporte:\n"
	"'P' .... Imprime\n"
	"Otros .. No Imprime : ", 									NULL, NULL,
	
	"Calif. de Carga Default en Par�metros Ausentes:\n"
	"'P' .... Carga\n"
	"Otros .. NO Carga : ", 							        NULL, NULL,
	
	"L�mite para Consumidor Final sin Documentaci�n (XXXXXXXXX.XX) : ", NULL, NULL,
	"L�mite para Ticket Factura A (XXXXXXXXX.XX) : ", 			NULL, NULL,
	"Porcentaje de IVA NO inscripto (XX.XX) : ", 				NULL, NULL,
	
	"N�mero de Copias de DF:\n"									  
	"'0' .... No Copias \n"
	"'1' .... Original \n"
	"'2' .... Duplicado \n"
	"'3' .... Triplicado \n"
	"'4' .... Cuadruplicado : ", 								NULL, NULL,
	
	"Calif. de impresi�n de CAMBIO $0.00: \n"						  
	"'P' .... Imprime\n"
	"Otros .. NO Imprime : ", 						            NULL, NULL,
	
	"Calif. de impresi�n de leyendas opcionales: \n"
	"'P' .... Imprime\n"
	"Otros .. NO Imprime : ", 						            NULL, NULL,
	
	"Calif. de impresi�n de tipo de corte de papel:\n"
	"'F' .... Total\n"
	"'P' .... Parcial\n"
	"'N' .... NO Corta : ", 				                    NULL, NULL,
	
	"Calif. de impresi�n de marco:\n"
	"'P' .... Imprime\n"
	"Otros .. NO Imprime : ", 						            NULL, NULL, 
	
	"Calif. de Re-Impresi�n de documentos cancelados\n"
	"por corte de energ�a: \n"
	"'P' .... Re-Imprime\n"
	"Otros .. NO Re-Imprime : ", 				                NULL, NULL,
	
	"Descripci�n del Medio de Pago para Saldo: \n"
	"(80 caracteres) : ",										NULL, NULL,
	
	"Sonido:\n"
	"'P' .... Habilita\n"
	"Otros .. NO Habilita : ",                                  NULL, NULL,

	"Alto de la hoja:\n"
	"'M' .... Reducido\n"
	"'A' .... A4 : ",                                           NULL, NULL,
	
	NULL, 														NULL, NULL
};																	  

Formatos Print_Line_Item_321 [] = 
{
   	"Descripci�n : ", 					NULL, NULL,
	"Cantidad :\n"
	"[+/-][0...8 enteros].[0...10 decimales] : ",   NULL, NULL,

	"Monto (XXXXXX.XXXX) : ", 			NULL, NULL,
	"Tasa de IVA (XX.XX) : ",			NULL, NULL,

	"Operaci�n \n"
	"'m' ..... Negativa\n"
	"'M' ..... Positiva : ", 			NULL, NULL,

	"Coeficiente de Impuestos Internos :\n"
	"0.nnnnnnnn .......... (ej: 0.12345) Coef. 'K' para imp. internos porcent.\n"
	"[+]0.nnnnnnnn ....... (ej: +0.4563) Coef. 'K' para imp. internos fijos\n"
	"[$]nnnnnn.nnnnnnnn .. (ej: $3.4567) Imp. internos fijos\n"
	"[%]nnnnnn.nnnnnnnn .. (ej: %2.456)  Imp. internos porcentuales : ",	NULL, NULL,

	"Identificador de Display : ",	NULL, NULL,

	"Monto \n"
	"'T' ..... Total\n"
	"Otro: Base Imponible : ", 			NULL, NULL,

	NULL, 								NULL, NULL
};

Formatos Item_Remito_321 [] = 
{
	"Descripci�n de Item (108 caracteres) : ",			NULL, NULL,
			
	"Cantidad :\n"
	"[+/-][0...8 enteros].[0...10 decimales] : ",   	NULL, NULL,
																	  
	"Calificador de Campo de Display ... \n"
	"'0' .... No Modifica (default)\n"
	"'1' .... Escribe en display \n"
	"'2' .... Incrementa cantidad de repeticiones : ",	NULL, NULL,
																	  
	NULL, 												NULL, NULL
};

// Descripcion de los campos de respuestas a los comandos 

char *Resp_GetConfigFull_321 [] = 
{
	"L�mite para consumidor final sin document.",
	"L�mite para ticket factura A",
	"Porcentaje de IVA No Inscripto",
	"N�mero de copias de documentos",
	"Calificador de impresi�n de 'CAMBIO $0.00",
	"Calificador de impresi�n de leyendas opcionales",
	"Calificador de tipo de corte de papel",
	"Calificador de impresi�n de marco",
	"Calif. de re-impresi�n por corte de energ�a",
	"Descripci�n del Medio de Pago para Saldo",
	"Sonido",
	"Alto de la hoja"
};
