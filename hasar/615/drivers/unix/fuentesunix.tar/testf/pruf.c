/*********************************************************************
*                                                                    *
*     Modulo :                                            TESTF.C    *
*                                                                    *
*     Descripcion:   Programa de Prueba de Controladores Fiscales    *
*                                                                    *
*     Fecha:         25 de Setiembre de 1998                         *
*     Version:       3.00                                            *
*                                                                    *
*     Autor:         Jorge G. GONZALEZ 								 *
*					 Marcelo Emilio Bartolome    					 *
*    				 Eduardo Sabaj	(9/9/99)						 *
*																	 *
*     Departamento:  Software de Base                                *
*                                                                    *
*********************************************************************/

#ifdef TARGET_TESTF
#define VER_FULL
#endif

#ifdef UNIX 
#include <prototypes.h>
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>

#if defined (UNIX) || defined (LINUX)
#include <unistd.h>
#include <curses.h>
#endif 

#ifdef DOS

#include <conio.h>
#include <bios.h>
#include <io.h>
#include <dos.h>

#include "getopt.h"
#include "fiserr.h"

#endif


#include <stdarg.h>
#include <ctype.h>
#include <signal.h>
#include <setjmp.h>
#include <fcntl.h>

#include "ascii.h"
#include "testf.h"
#include "pages.h"
#include "split.h"
#include "xntoi.h"
#include "p320f.h"
#include "pr4.h"
#include "chile.h"
#include "pd425.h"
#include "p321f.h"

#ifdef DOS
#include "fislib.h"
#else
#include "unxlib.h"
#endif

// *** Prototipos *** 

int 	xtoi 				(char *num);

unsigned char Intercept 	(COMMANDSET *Command);

int    	SendFiscalCommand	(char *CommandPtr, char **Respuestas);
void 	SendLastCommand 	(void);
void    VerRespuesta 		(unsigned char ComandoEnviado, 
							char *FiscalAnswer, char **Respuestas);

void 	NewLevel			(char *linetxt);

static COMMANDSET * GetCommandSet (int Version);

// *** Variables Estaticas ***

static int   Programming;
static int   Playing;
static int   Input;
static FILE  *fh, *fg;
static int   KeepAliveCounter;

static  char   LogFile[100];
static  int    LogFileEnabled;
static  int    Verbose;

static char    CommandBuff [512];
static char *  UltimoComando;
static char ** UltimoFormatoRespuestas;
static char *  UltimaDescripcion;
static int     KeepAliveEnabled = 1;

static unsigned char UltimoCodOper;

int CursesInitialized;

static int  SaveCommands;
static char CommandsFile[100];


// *** Variables Publicas *** 

int 			CommHandler = -1;
int     		Version;
jmp_buf 		jumper;
unsigned short 	FiscalStatus;
unsigned short 	PrinterStatus;
char    		FiscalAnswer[500];
long    		BaudRate;

#undef PGUP
#undef ESC
#undef PGDWN

#define MAX_LINES  25
#define ESC        0x1b

#define MAXLEVEL   12      // Cantidad de anidamientos adimitidos

#if defined (UNIX) || defined (LINUX) // *********** UNIX **************

static int wAlto  = MAX_LINES;
static int wAncho = 80;
static int wX     = 0;
static int wY     = 0;

WINDOW *W;

#define ctrl(x) ((x) & 0x1f)

#define IS_PAGE_DOWN(c) (c == ctrl('f') || c == KEY_NPAGE )
#define IS_PAGE_UP(c)   (c == ctrl('b') || c == KEY_PPAGE )

#define IS_VALID_CHAR(c) ( c != KEY_END && c != KEY_HOME && c != KEY_F(c) )

char Usage [] = 
"\nUso : %s -p port [-m modelo] [-b bauds] [-v] [-l log] [-s archivo]\n\n"
"   -p tty    ..... donde tty es la tty a utilizar (tty1a, tty2a, ..)\n"
"   -m modelo ..... donde modelo puede ser cualquiera de los siguientes\n"
"                   strings : 950, 951, 614, 615, 262, pr4, pj20, 320, \n"
"                   321, 425, pl8f o 2008\n"
"   -b bauds  ..... donde bauds es la velocidad de la comunicaci�n\n"
"   -v        ..... imprime informaci�n de debug\n"
"   -l log    ..... loguea en un archivo la informaci�n de debug\n"
"   -s archivo..... almacena en un archivo los comandos ejecutados\n\n";


// En utils.c
extern int stricmp (char *s1, char *s2);

#else     // ************* DOS **************

#define PGDWN 'Q'
#define PGUP  'I'

#define IS_PAGE_DOWN(c) (c == PGDWN)
#define IS_PAGE_UP(c)   (c == PGUP)

char Usage [] = 
"\nUso : %s -p port [-m modelo] [-b bauds] [-v] [-l log] [-s archivo]\n\n"
"   -p port   ..... donde port es el COM serie a utilizar\n"
"   -m modelo ..... donde modelo puede ser cualquiera de los siguientes\n"
"                   strings : 950, 951, 614, 615, 262, pr4, pj20, 320, \n"
"                   321, 425, pl8f o 2008\n"
"   -b bauds  ..... donde bauds es la velocidad de la comunicaci�n\n"
"   -v        ..... imprime informaci�n de debug\n"
"   -l log    ..... loguea en un archivo la informaci�n de debug\n"
"   -s archivo..... almacena en un archivo los comandos ejecutados\n\n";

#endif    // *********************************

// Esta macro indica si el controlador esta basado 
// en una PC (cf386.exe)

#define CF386_Based(Version) \
	(Version == VER_ARTJET  || Version == VER_PRN320 || \
	 Version == VER_NCR     || Version == VER_PRN425 || \
 	 Version == VER_OKIPAGE || Version == VER_PRN321)

extern int errno;

#ifdef DOS
#pragma argsused
void 
FISdebug (int level, char *fmt, ...)
#else
FISdebug (char *fmt, ...)
#endif 
{
	va_list argptr;
	static char BufLog [500];
	static int fd = -1;

	va_start(argptr, fmt);
	vsprintf (BufLog, fmt, argptr);

	if ( LogFileEnabled )
	{
		if ( fd == -1 )
			fd = open (LogFile, O_BINARY | O_WRONLY | O_CREAT | O_APPEND, 0666);

		if ( fd > 0 )
		{
			write (fd, BufLog, strlen(BufLog));
			write (fd, "\r\n", 2);
		}
	}
	
	if ( Verbose )
	{
		#if defined (UNIX) || defined (LINUX)

		ShowLine ("DEBUG : [%s] \n", BufLog);

		#else

		cputs (BufLog);
		putch ('\n');
		putch ('\r');

		#endif
	}
	
	va_end (argptr);
}

void
usage (char *Program)
{
	if ( CursesInitialized )
		ShowLine (Usage, Program);
	else printf (Usage, Program);

    exit(1);
}

void
done (void)
{
	if ( CommHandler != -1 )
		CloseCommFiscal (CommHandler);
	
	#if defined (UNIX) || defined (LINUX)
	endwin ();
	#endif
}

// Callback de la libreria que es llamado cuando el controlador 
// envia DC2 o DC4.

#ifdef DOS
#pragma argsused
#endif 

void
KeepAlive (int Caracter, int Port)
{
	if ( !KeepAliveEnabled )
		return;
		
	if ( kbhit () && Getch () == ESC )
		longjmp (jumper, 1);

	if ( Caracter == DC4 )
		ShowLine ("DC4 ");

	if ( Caracter == DC2 )
		ShowLine ("DC2 ");

	KeepAliveCounter ++;
}

void 
CommandHeader (char *Descripcion, unsigned char CodOper)
{
	ClearScreen ();
	ShowLine ("Comando : %s\n", Descripcion);
	ShowLine ("CodOper : %02Xh (ASCII - '%c') \n", CodOper, CodOper);
}

int
main(int argc, char *argv[])
{
	int i, n;
	char *Program = argv[0];
	int ComPort = 0;
	int c = 0;
	COMMANDSET *Command;
	COMMANDSET *CommandSet;
	long NewBaud = -1L;
	int Value;
    int NPages;
    int Page   = PAGINA_1;
	int CommandFound = 0;
	char Buffer [10];
	static char Modelo [100];

	#if defined (UNIX) || defined (LINUX)
	static char PortName [50];
	#endif

	while ( (n = getopt(argc, argv, "vup:b:l:m:s:")) != EOF )
		
		switch (n)
		{
			case 'p':

				#if defined (UNIX) || defined (LINUX)
				strcpy (PortName, optarg);
				#else
            	ComPort = atoi (optarg);
				#endif

				break;
			case 'b':
				NewBaud = atol (optarg);
				break;
			case 'm':
				strcpy (Modelo, optarg);
				break;
			case 'v':
				Verbose = 1;
				break;
			case 'l':
				LogFileEnabled = 1;
				strcpy (LogFile, optarg);
				break;
			case 's':
				SaveCommands = 1;
				strcpy (CommandsFile, optarg);
				break;
			default:
				usage (Program);
				break;
		}

	#if defined (UNIX) || defined (LINUX)

		if ( strlen (PortName) == 0 )
			usage (Program);

		CommHandler = OpenCommFiscal (PortName);

		// Inicializa la sesion de curses.
		initscr (); noecho (); raw (); 

		setscrreg (0, MAX_LINES);

		W = newwin (wAlto, wAncho, wX, wY);

		scrollok (W, TRUE); keypad (W, TRUE);

		CursesInitialized = 1;

	#else

		if ( ComPort == 0 )
			usage (Program);

		if (ComPort < 1 || ComPort > 4)
		{
			ShowLine ("No puede abrir COM %d\n", ComPort );
			exit (1);
		}

		CommHandler = OpenCommFiscal (ComPort);

	#endif

	if ( CommHandler < 0 )
	{
		#if defined (UNIX) || defined (LINUX)
		printf ("Error abriendo /dev/%s, errno %d\n", PortName, errno);
		#else
		printf ("Error abriendo COM%d\n", ComPort);
		#endif
		exit (1);
	}

	SetKeepAliveHandler (KeepAlive);

	signal (SIGINT,   exit);
	signal (SIGTERM,  exit);
	signal (SIGABRT,  exit);

	atexit (done);

	Programming  = FALSE;
	Playing 	 = FALSE;

	// Si el modelo no esta dado en la linea de comando llama a la 
	// funcion CheckController que verifica la existencia del 
	// controlador fiscal.

	if ( strlen (Modelo) )
	{
		// Baudrate default de 9600.
		BaudRate = 9600;

		if ( !stricmp (Modelo, "pj20") )
		{
			NewProtocol ();
			Version = VER_ARTJET;		
		}
		
		else if ( !stricmp (Modelo, "320") )
		{
			NewProtocol ();
			Version = VER_PRN320;
		}

		else if ( !stricmp (Modelo, "321") )
		{
			NewProtocol ();
			Version = VER_PRN321;
		}
		
		else if ( !stricmp (Modelo, "2008") )
		{
			NewProtocol ();
			Version = VER_NCR;
		}

		else if ( !stricmp (Modelo, "425") ) 
		{
			NewProtocol ();
			Version = VER_PRN425;
		}
					
		else if ( !stricmp (Modelo, "pl8f") )
		{
			NewProtocol ();
			Version = VER_OKIPAGE;
		}
		
		else if ( !stricmp (Modelo, "pr4") || 
			!stricmp (Modelo, "615") || !stricmp (Modelo, "951") )
			Version = VER_PRN_615_951_PR4;

		else if ( !stricmp (Modelo, "262") || 
			!stricmp (Modelo, "614") || !stricmp (Modelo, "950") )
			Version = VER_PRN_614_950_262;
		
		else if ( !stricmp (Modelo, "chile") )
			Version = VER_CHILE;

		else 
		{
			ShowLine ("Modelo \"%s\" NO reconocido\n", Modelo);
			exit (1);
		}
	}	
	
	else CheckController ();

	// Veo si hay que inicializar el printer a una determinada 
	// velocidad. 
	
	if ( NewBaud != -1L && SetNewBaud (NewBaud) < 0 )
		exit (1);

	setjmp (jumper);

    Playing = FALSE;

	NPages = GetNPages ();

	CommandSet = GetCommandSet (Version);
		
	// Pongo la primer pantalla del menu
	PrintMenu (Page, NPages);

	while ( (c = Getch ()) != ESC )
	{

	#if defined (UNIX) || defined (LINUX)

		if ( !IS_VALID_CHAR(c) )
			continue;

		if ( IS_PAGE_DOWN(c) || IS_PAGE_UP(c) )
		{
	#else
		if ( !c )
		{
			c = Getch ();
	#endif
			switch (Page)
			{
				case PAGINA_1:

					if ( IS_PAGE_DOWN(c) )
					{
						Page = PAGINA_2;
						PrintMenu (Page, NPages);
					}

					break;

				case PAGINA_2:

					if ( IS_PAGE_UP(c) )
					{
						Page = PAGINA_1;
						PrintMenu (Page, NPages);
					}
					
					else if ( IS_PAGE_DOWN(c) )
					{
						Page = PAGINA_3;
						PrintMenu (Page, NPages);
					}

					break;
					
				case PAGINA_3:
					
					if ( IS_PAGE_UP(c) )
					{
						Page = PAGINA_2;
						PrintMenu (Page, NPages);
					}
					
					break;
			}
			
			continue;
		}

		CommandFound = 0;
		
		// Comandos Genericos que NO dependen del tipo de controlador.
		// Si es alguno de estos no busco en la tabla de comandos.		

		switch (c)
		{
		
		#ifdef VER_FULL
			case '!':
				ClearScreen ();
				ShowLine ("Dar de baja Controlador Fiscal\n");
				KillEprom ();
				CommandFound = 1;
				break;
		#endif

			case '#':
				ClearScreen ();
				PrintCommandSet ();
				CommandFound = 1;
				break;

			case '$':
				ClearScreen ();
				SendLastCommand ();
				CommandFound = 1;
				break;

			case 'R':
				ClearScreen ();
				ShowLine ("Programaci�n de Secuencia\n");
				ProgramSequence ();
				CommandFound = 1;
				break;

			case 'S':
				ClearScreen ();
				ShowLine ("Reproducir Secuencia\n");
				PlaySequence ();
				CommandFound = 1;
				break;

			case 'T':
				ShowLine ("Enviar ACK al controlador\n");
				SendACK ();
				CommandFound = 1;
				break;
		}
		
		// Veo si es algun comando generico valido solo para ARTJET,
		// OKIDATA, NCR, PD425 u OKIPAGE.
		
		if ( CF386_Based (Version) ) 
		{
			switch (c)
			{
				case '/':
					ShowLine ("Cambio de velocidad\n");
					ChangeBauds ();
					CommandFound = 1;
					break;
					
				case 'U':
					ShowLine ("Nuevo Protocolo\n");
					NewProtocol ();
					CommandFound = 1;
					break;
			}
		}

		// Busco el comando en la tabla de comandos.

		if ( !CommandFound )
		{
			KeepAliveCounter = 0;

			for ( Command = CommandSet; Command->Opcion != ANY; Command++)
			{
				if ( Command->Opcion == (char) c )
				{
					// Intercepta el comando antes de ser ejecutado.
					// Hay casos en que es necesario cambiar el codigo 
					// de operacion en aquellos comandos que se asemejan
					// en el formato 
										
					UltimoCodOper = Intercept (Command);

					if ( !UltimoCodOper )
					{
						WaitKey ("Presione una tecla para continuar...\n");
						break;
					}
											
					UltimaDescripcion = Command->Descripcion;

					// Imprime el header o titulo al comando que se va 
					// a ejecutar.
					
					CommandHeader (Command->Descripcion, UltimoCodOper);

					// Ejecuta el comando, pidiendo previamente al 
					// usuario que entre los campos necesarios para 
					// su ejecucion.
										
					MakeCommand (UltimoCodOper, 
						 Command->Form, 
						 Command->BufAux,
						 Command->Respuestas);

					break;
				}
			}
		}

		PrintMenu (Page, NPages);
	}
	
	return 0;
}

// **************************************************************
// ***** RUTINAS DE USO GENERAL *********************************
// **************************************************************

void
ProgramSequence (void)
{
	char *Filename;
	char TmpBuff[100];
	char c;
	int  len;

	Filename = Ask ("Nombre del archivo a grabar : ", &len, TRUE);

	if( access(Filename, 00) == 0 ) 
	{
		ShowLine("El Archivo %s ya existe, desea sobre-escribirlo ? (s/n) ", 
			Filename);

		c = tolower(Getch());

		if ( c == 's' ) 
			unlink (Filename);
			
		else return;
	}

	ClearScreen ();

	if( (fh = fopen(Filename, "wt")) == NULL )
	{
		ShowLine ("No se puede Abrir el Archivo \"%s\"\n", Filename);
		WaitKey ("Presione una tecla para continuar...\n");
    	return;
	}

	Programming = TRUE;

	return;
}

static int RecurseLevel;

void
PlaySequence (void)
{
	char  TempBuff[512];
	int   len;
	int   times = 0;
	char  Filename[300];
	char  *ptr;
	char  c;
	char  *Fields[1];

	RecurseLevel = 1;
	
	if ( Programming ) 
	{
		fclose(fh);
		Programming = FALSE;   
		ShowLine ("\nSecuencia programada. "
			   "Presione una tecla para continuar...\n");
		Getch();
		return;
	}

	// ***** Ejecuci�n del Archivo *****

	ptr = Ask ("Nombre del archivo a reproducir : ", &len, FALSE);

	strcpy (Filename, ptr);

	if ( access(Filename, 0) != 0 ) 
	{
		ShowLine("\n\nNo existe el archivo %s. "
			   "Presione una tecla para continuar...\n", Filename);
		Getch();
		return;
	}

	ptr = Ask ("\nIngrese Numero de repeticiones o presione <enter> \n"
			   "para ejecutar 1 vez : ", &len, FALSE);

	if ( strlen (ptr) != 0 )
		times = atoi (ptr);
	else times = 1;

	Playing = TRUE;

	if( (fh = fopen(Filename, "rt")) == NULL )
	{
		ShowLine("No se puede Abrir el Archivo <%s>. \n"
			   "Presione una tecla para continuar...\n", Filename);
		Getch();
		return;
	}

	while ( times-- ) 
	{
		fseek (fh, 0L, SEEK_SET);
		
		while ( fgets (TempBuff, sizeof (TempBuff), fh) )
		{
			len = strlen( TempBuff );
			TempBuff [len - 1] = 0;
			KeepAliveCounter   = 0;

			split (TempBuff, Fields, 1);
		
			if ( !strlen (TempBuff) )
				continue;

            if ( TempBuff[0] == '/' && TempBuff[1] == '/' )
                continue;

			// *** Verificando la existencia de inclusi�n de otros ***
			// *** archivos con comandos ( ..include  filecmd ).    ***
			// *** ------------------------------------------------***

			if ( TempBuff[0] == '.' && TempBuff[1] == '.' )
			{
				NewLevel (TempBuff);
				continue;
			}

			if ( SendFiscalCommand(TempBuff, NULL) < 0 )
				goto EndPlaying;
		}
	}

EndPlaying:

	fclose(fh);

	ShowLine("\nSecuencia ejecutada.\n");
	WaitKey ("Presione una tecla para continuar...\n");

	Playing = FALSE;

	return;
}

void
NewLevel (char *linetxt)
{
	FILE *fd;
	char otherfile[300];
	int  lenbuf;
	char  *Fields[2];
	char bufftemp[200];

	if ( RecurseLevel + 1 >= MAXLEVEL )
	{
		ShowLine("\nExcede de %d niveles de anidamiento !!\n", MAXLEVEL);
		WaitKey ("Presione una tecla para continuar...\n");
		return;
	}

	if ( split ( linetxt, Fields, 2) != 2 )
		return;

	strcpy( otherfile, Fields[1]);

	if (( fd= fopen ( otherfile, "rt")) == NULL )
	{
		ShowLine("\nNo se puede abrir el archivo:  \n", otherfile );
		WaitKey ("Presione una tecla para continuar...\n");
		return;
	}

	RecurseLevel++;

	fseek( fd, 0L, SEEK_SET );
	
	while( fgets ( bufftemp, sizeof ( bufftemp ), fd ) )
	{
		lenbuf = strlen( bufftemp );
		bufftemp[lenbuf - 1] = 0;
		split ( bufftemp, Fields, 1);
		
		if ( !strlen (bufftemp) )
			continue;

        if ( bufftemp[0] == '/' && bufftemp[1] == '/' )
            continue;

        // ****  Entro en recursividad  ******
		if ( bufftemp[0] == '.' && bufftemp[1] == '.' )
		{
			NewLevel (bufftemp);
			continue;
		}

		if ( SendFiscalCommand( bufftemp, NULL ) < 0 )
			break;
	}

	RecurseLevel --;
	fclose (fd);
	return;
}

// Intercepta los comandos antes de ser ejecutados.

unsigned char
Intercept (COMMANDSET *Command) 
{
	char *Ans;
	int len;
	unsigned char CodOper = Command->CodOper;

	switch (CodOper)
	{
		case CMD_OPEN_DNF_TICKET:

			if ( !CF386_Based (Version) )	
				break;
		
			ClearScreen ();
			
			Ans = Ask ("Desea abrir el documento en SLIP? (s/n) :", 
				&len, TRUE);

			if ( *Ans == 's' )
				CodOper = CMD_OPEN_DNF_SLIP;

			break;

		case CMD_SET_CONFIG_FULL:
			
			if ( Version != VER_PRN321 )
				break;

			Command->Form = Set_Config_Full_321;

			break;

		case CMD_GET_CONFIG_FULL:

			if ( Version != VER_PRN321 )
				break;

			Command->Respuestas = Resp_GetConfigFull_321;

			break;
			
		case CMD_ITEM_REMIT:

			if ( Version != VER_PRN321 )
				break;

			Command->Form = Item_Remito_321;

			break;
									
		case CMD_PRINT_LINE_ITEM:

			if ( Version != VER_PRN321 )
				break;

			Command->Form = Print_Line_Item_321;

			break;

		case CMD_CHANGE_INGBR:
			
			if ( Version == VER_PRN320 )
			{
				ClearScreen ();
				ShowLine ("Comando no disponible para �ste impresor !\n\n");
				CodOper = 0;
			}
			
			break;
			
		default:
			break;
	}

	return CodOper;
}

void 
MakeCommand (char Oper, Formatos *Form, char *ExtraInfo, char **Respuestas)
{
	int Len, i;
	char *AuxPtr = CommandBuff;

	memset (CommandBuff, 0, sizeof (CommandBuff));

	*AuxPtr++ = Oper;

	// Veo si no hay informacion a imprimir, en cuyo caso si hay
	// info adicional la agrego, y sino mando directamente el 
	// codigo de operacion.
	
	if ( !Form )
	{
		if ( ExtraInfo )
			strcat (AuxPtr, ExtraInfo);
		else *AuxPtr = 0;
	}

	else 
	{
		*AuxPtr++ = (char) SEP;

		while ( Form->Msg )
		{
			// Si hay rutina de acci�n para este campo la ejecuta
			
			if ( Form->Action )
				AuxPtr += Form->Action (AuxPtr);

			// Si hay un campo a llenar imprime la info del campo 
			// y pide el ingreso de datos formateando el dato 
			// ingresado si es necesario.
			
			if ( strlen (Form->Msg) )
				AuxPtr += sprintf (AuxPtr, 
					Form->Format ? Form->Format : "%s", 
					Ask (Form->Msg, &Len, TRUE));
			
			// Si hay un proximo campo, agrega el separador
			
			if ( (++Form)->Msg )
				*AuxPtr++ = (char) SEP;
		}

		*AuxPtr = 0;
		
		// Agrega info adicional al final del comando
		if ( ExtraInfo )
			strcat (AuxPtr, ExtraInfo);
	}

	// Guardo el ultimo comando y formato de la respuesta para 
	// poder repetir el mismo N veces.
	
	UltimoComando 			= CommandBuff;
	UltimoFormatoRespuestas = Respuestas;

	// Manda el comando al impresor. 
	SendFiscalCommand(CommandBuff, Respuestas);
}

void 
VerRespuesta (unsigned char ComandoEnviado, char *FiscalAnswer, 
	char **Respuestas)
{
	int i, nFields;
	char *Fields[50];
	char *NewFs = {"\x1c" "\n"};
	char *OldFs;

	int DocCanceled;
	int DocState;
	int MsgFound;
	int StLow;
	int StHigh;
	
	STATAUX_LOW  *p;
	STATAUX_HIGH *q;
	STDOC 		 *r;
	
	ClearScreen ();

	OldFs = setfs (NewFs);
	nFields = split (FiscalAnswer, Fields, 50);
	setfs (OldFs);
	
	for (i = 2; i < nFields; i ++ )
		ShowLine ("\n%45.45s = %s", Respuestas[i-2], Fields[i]);

	if ( ComandoEnviado != CMD_STATUS_REQUEST )
	{
	   	WaitKey ("\n\nPresione una tecla para continuar...");
		return;
	}
	
	// Si es un 614, la cantidad de campos es 3.
	// Fields[2] indica el ultimo ticket emitido. No tiene 
	// status auxiliar.
		
	if ( Version == VER_PRN_614_950_262	)
	{
	   	WaitKey ("\n\nPresione una tecla para continuar...");
		return;
	}
	
	if ( Version == VER_CHILE )
	{
		ShowLine ("\n\nSignificado del estado auxiliar: \n\n");
		
		p = StAuxChile;
		
		while (p->Valor != -1)
		{
			if ( p->Valor == Fields[3][0] )
			{
				ShowLine ("%s.\n", p->Mensaje);
				break;
			}
				
			p++;
		}

	   	WaitKey ("\n\nPresione una tecla para continuar...");
		return;
	}

	// Veo el status auxiliar y el estado del documento. Este 
	// ultimo es solo para ARTJET, OKIDATA o NCR.
	
	StLow  = xntoi (Fields[3] + 2, 2);
	StHigh = xtoi (Fields[3]);

	ShowLine ("\n\nSignificado del estado auxiliar: \n\n");
	ShowLine ("Byte Inferior [%02X]: \n", StLow);

	if ( CF386_Based (Version) )
	{
		p = StAuxLow_320;
		q = StAuxHigh_320;
	}
	else 
	{
		p = StAuxLow;
		q = StAuxHigh;
	}
		
	for ( MsgFound = 0; p->Valor != -1; p ++ )

		if ( p->Valor == StLow )
		{
			MsgFound = 1;
			ShowLine ("%s.\n", p->Mensaje);
			break;
		}

	if ( !MsgFound )
		ShowLine ("<No hay mensaje disponible para �ste estado>\n");

	ShowLine ("\nByte Superior [%c%c] : \n", Fields[3][0], Fields[3][1]);

	for ( MsgFound = 0; q->Mascara; q ++ )

		if ( q->Mascara & StHigh )
		{
			MsgFound = 1;
			ShowLine ("%s.\n", q->Mensaje);
		}

	if ( !MsgFound )
		ShowLine ("<No hay mensaje disponible para �ste estado>\n");

	// El tipo de documento abierto solo viene en los 
	// impresores artjet y okidatta
		
	if ( CF386_Based (Version) )
	{
		DocState = xtoi (Fields[5]);

		ShowLine ("\nEstado del documento: \n");
		
		if ( DocState & 0xff00 )
		{
			// Hay un documento abierto
			DocState = (DocState & 0xff00) >> 8;
			
			for ( r = StDoc; r->Valor; r ++ )

				if ( DocState == r->Valor )
				{
					ShowLine ("Documento Actual: %s\n", r->Mensaje);
					break;
				}
		}

		else 
		{
			if ( DocState == 0x0001 )
				ShowLine ("<El documento anterior fue cancelado>\n");
					
			ShowLine ("Acualmente no hay un documento abierto\n");
		}
	}

   	WaitKey ("\n\nPresione una tecla para continuar...");
}

void
SaveCmd (char *Cmd)
{
	static int fd = -1;
	
	if ( fd < 0 )
	{
		fd = open (CommandsFile, O_WRONLY | O_CREAT | O_TRUNC, 0666);
		
		if ( fd < 0 )
			return;
	}

	lseek (fd, 0L, SEEK_END);
	
	write (fd, Cmd, strlen (Cmd));
	write (fd, "\n", 1);
}

static char StatPrnMsg [] = "\n\n"
	"El impresor no puede continuar con el documento dado que el mismo\n"
	"est� en condici�n de error. Por favor, corrija el problema, y presione\n"
	"una tecla para enviar STATUS de impresor y ver la respuesta al comando\n"
	"original ... ";

int
SendFiscalCommand(char *Command, char **Respuestas)
{
	int Result;
	int Enviado, Recibido;
	int CmdRecibido;
	unsigned char ComandoEnviado = *Command;

	// Veo si grabo los comandos en un archivo
	if (SaveCommands)
		SaveCmd (Command);

	if ( Programming ) 
	{
    	ShowLine("Programming Sequence\n");

    	while(*Command)
        	fputc(*Command++, fh);

    	fputc('\n', fh);

    	return 0;
    }
	
	ShowLine ("\nComando  : [%s]\n", Command);
	
	Result = MandaPaqueteFiscal (CommHandler, 
		Command, &FiscalStatus, &PrinterStatus, FiscalAnswer);

	ObtenerNumeroDePaquetes (&Enviado, &Recibido, &CmdRecibido);
	
	if ( Result != 0 )
	{

		if ( Result != ERR_STATPRN ) 
		{
			if ( KeepAliveCounter ) 
				ShowLine ("\n");
			ShowLine ("Error de comunicaci�n con el impresor !\n");
	    	WaitKey ("\nPresione una tecla para continuar...");
			return Result;
		}

		// Si el comando enviado es distinto a un statprn, me 
		// quedo en un loop hasta que el problema del printer se 
		// solucione, o presionen ESC para salir.

		if ( ComandoEnviado != CMD_STATPRN )
		{
			do 
			{
				ShowLine ("\nRespuesta: [%c%c%s]\n\n", CmdRecibido, 
					SEP, FiscalAnswer);

				ShowLine ("Nro. de Paquete Enviado:  %02Xh\n", 
					(unsigned int) Enviado);

				ShowLine ("Nro. de Paquete Recibido: %02Xh\n\n", 
					(unsigned int) Recibido);
	
				CheckFiscalStatus  (FiscalStatus,  Version);
				CheckPrinterStatus (PrinterStatus, Version);

				ShowLine (StatPrnMsg);

				if ( Getch () == ESC )
					return Result;

				ShowLine ("\n");

				Result = ObtenerStatusImpresor (CommHandler,  
					&FiscalStatus, &PrinterStatus, FiscalAnswer);
				
				ClearScreen ();

				ObtenerNumeroDePaquetes (&Enviado, &Recibido, &CmdRecibido);

				ShowLine ("\n\nComando  : [%c]", CMD_STATPRN);

					
			} while ( Result == ERR_STATPRN );

			ShowLine ("\n");
				
			if ( !Playing )
			{
				ClearScreen ();
				ShowLine ("\n\nComando  : [%c]", CMD_STATPRN);
			}
		}

	}

	if ( KeepAliveCounter ) 
		ShowLine ("\n");

	ShowLine ("Respuesta: [%c%c%s]\n\n", CmdRecibido, SEP, FiscalAnswer);

	if ( Playing )
		return Result;

	ShowLine ("Nro. de Paquete Enviado:  %02Xh\n",   (unsigned int) Enviado);
	ShowLine ("Nro. de Paquete Recibido: %02Xh\n\n", (unsigned int) Recibido);

	CheckFiscalStatus  (FiscalStatus, Version);
	CheckPrinterStatus (PrinterStatus, Version);

	if ( !Respuestas )
	{
		WaitKey ("\nPresione una tecla para continuar...");
		return Result;
	}

	ShowLine("\nPresione 'D' para ver el detalle de las respuestas."
		   "\nOtra tecla para continuar...");

	if ( tolower (WaitKey (NULL)) == 'd' )
		VerRespuesta (ComandoEnviado, FiscalAnswer, Respuestas);

	return Result;

}

void 
SendLastCommand (void)
{
	char *ptr;
	int len, times;
	int i;

	if ( !UltimoComando )
		return;

	CommandHeader (UltimaDescripcion, UltimoCodOper);

	ShowLine ("Ultimo Comando : [%s]\n", UltimoComando);
	
	ptr = Ask ("\nIngrese Numero de repeticiones o presione <enter> \n"
			   "para ejecutar 1 vez : ", &len, TRUE);

	if ( strlen (ptr) != 0 )
		times = atoi (ptr);
	else times = 1;

	CommandHeader (UltimaDescripcion, UltimoCodOper);

	if ( times > 1 )
		Playing = 1;
		
	for (i = 1; i <= times; i ++ )
		if ( SendFiscalCommand (UltimoComando, UltimoFormatoRespuestas) < 0 )
			break;
	
	if ( times > 1 )
	{
		Playing = 0;
		WaitKey ("\nPresione una tecla para continuar...");
	}
}

int 
fcmp (const void *A, const void *B)
{
	return ((COMMANDSET *) A)->CodOper - ((COMMANDSET *) B)->CodOper;
}

void
PrintCommandSet (void)
{
	COMMANDSET *Set;
	int nCommands;
	int i, Pagina;
	char *Printer;
		
	switch ( Version )
	{
		case VER_CHILE:
			Set = CommandSet_Chile;
			Printer = PRN_CHILE;
			break;
			
		case VER_NCR:
		    Set = CommandSet_ArtJet;
			Printer = PRN_NCR;
			break;
			
		case VER_PRN320:
			Set = CommandSet_ArtJet;
			Printer = PRN_320;
			break;

		case VER_PRN321:
			Set = CommandSet_ArtJet;
			Printer = PRN_321;
			break;
			
		case VER_ARTJET:
			Set = CommandSet_ArtJet;
			Printer = PRN_PJ20;
			break;
			
		case VER_PRN_615_951_PR4 :
			Set = CommandSet_PR4;
			Printer = PRN_615;
			break;
			
		case VER_PRN_614_950_262:
			Set = CommandSet_PR4;
			Printer = PRN_614;
			break;

		case VER_PRN425:
			Set = CommandSet_PD425;
			Printer = PRN_425;
			break;

		case VER_OKIPAGE:
			Set = CommandSet_ArtJet;
			Printer = PRN_PL8F;
			break;

		default:
			return;
	}

	ShowLine ("Set de Comandos del impresor : %s\n\n", Printer);

	for ( i = 0, Pagina = 1; Set->Opcion != ANY; i ++, Set++)
	{
		if ( !Set->CodOper )
			continue;

		Pagina++;
		
		ShowLine ("%02Xh ('%c') :   %s\n", 
			Set->CodOper, Set->CodOper, Set->Descripcion);
	
		if ( !(Pagina % 17) )
		{
			WaitKey ("\nPresione una tecla para continuar...\n");
			ClearScreen ();
			ShowLine ("Set de Comandos del impresor : %s\n\n", Printer); 
			Pagina = 1;
		}
	}

	WaitKey ("\nPresione una tecla para continuar...\n");
}

static COMMANDSET *
GetCommandSet (int Version)
{
	COMMANDSET *CommandSet;
	
	switch (Version)
	{
		case VER_PRN425:
			CommandSet = CommandSet_PD425;
			break;
			
		case VER_ARTJET:
		case VER_PRN320:
		case VER_PRN321:
		case VER_NCR:
		case VER_OKIPAGE:
			CommandSet = CommandSet_ArtJet;
			break;
		
		case VER_PRN_615_951_PR4:
		case VER_PRN_614_950_262:
			CommandSet = CommandSet_PR4;
			break;
			
		case VER_CHILE:
			CommandSet = CommandSet_Chile;
			break;
	}

	return CommandSet;	
}
