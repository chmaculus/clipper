/*********************************************************************
*                                                                    *
*     Modulo :                                            TESTF.H    *
*                                                                    *
*     Descripcion:   Incluye definiciones y  declaraciones utiles    *
*                    para el modulo 'testf.c'.                       *
*                                                                    *
*********************************************************************/

#include "def_cmd.h"

#ifndef TRUE
#define TRUE  1
#endif 

#ifndef FALSE 
#define FALSE 0
#endif 

#if defined (UNIX) || defined (LINUX) 
#define O_BINARY 0
#define delay nap
#endif 

#ifdef OK
#undef OK
#endif 

#define OK          0x00
#define ERROR       -1
#define ANY         0xFF
#define SEP			0x1C
#define szSEP		"\x1C"

#define PRN_614    "614/950/262"			// Impresor 614/950/262
#define PRN_615    "615/951/PR4"		   	// Impresor 615/951/PR4
#define PRN_PJ20   "OLIVETTI Artjet 20-F"	// Artjet PJ-20
#define PRN_320    "SMH/P-320F"				// Okidata 320
#define PRN_321    "HASAR SMH/P-321F"       // Okidata 321
#define PRN_NCR    "2008"					// NCR 2008
#define PRN_CHILE  "chile"					// Impresor para chile
#define PRN_425    "HASAR SMH/P-425F"		// Impresor OKI PD425
#define PRN_PL8F   "HASAR SMH/PL-8F" 		// Impresor Okipage 8p

#define VER_PRN_614_950_262  	1
#define VER_PRN_615_951_PR4  	2
#define VER_ARTJET  			3
#define VER_PRN320  			4
#define VER_PRN321  			5
#define VER_NCR     			6
#define VER_CHILE   			7
#define VER_PRN425  			8
#define VER_OKIPAGE 			9

#define COD_DOBLE_ANCHO  0xf4
#define COD_BORRAR_LINEA 0x7f

typedef struct 
{
	char *Msg;				// Mensaje a imprimir con la info del campo
	char *Format;			// Formato a dar al campo ingresado (ejmpl %20s)
	int  (*Action)(char *); // Rutina a ejecutar antes de ingresar datos
}
Formatos;

typedef struct CommandSet
{
   unsigned char Opcion;
   unsigned char CodOper;
   char *Descripcion;
   Formatos *Form;
   char *BufAux;
   char **Respuestas;
}
COMMANDSET;

typedef struct 
{
	unsigned int Mascara;
	char *Mensaje;
}
STATAUX_HIGH;

typedef struct 
{
	char Valor;
	char *Mensaje;
} 
STATAUX_LOW;

struct version
{
	char FiscalStatus[4];
	unsigned char Sep1;
	char PrinterStatus[4];
	unsigned char Sep2;
	char Version[50];
};	

typedef struct 
{
	char Valor;
	char *Mensaje;
}
STDOC;

// ***** Declaracion de Funciones *****

// testf.c
void	ProgramSequence		(void);
void	PlaySequence		(void);
void	ExitTestf			(void);
void   	MakeCommand 		(char Oper, Formatos *Form, char *ExtraInfo, 
							char **Respuestas);
// utils.c
void	ClearScreen 		(void);
void 	ShowLine 			(char *fmt, ... );
int 	Getch 				(void);
char * 	Ask 				(char *msg, int *Len, int NL);
int 	WaitKey				(char *s);

// cmds.c
void 	CommandHeader 		(char *Descripcion, unsigned char CodOper);
int 	SetNewBaud 			(long NewBaud);
void    ChangeBauds			(void);
void	SendACK				(void);
void	KillEprom			(void);
void	NewProtocol			(void);
void 	PrintCommandSet 	(void);
int 	CheckController 	(void);

// actions.c
int     ActionText          (char *Buffer);
int     ActionProgText      (char *Buffer);
int		ActionConfigIndiv 	(char *Buffer);
int		ActionConfigIndiv_PD425 (char *Buffer);

#if defined (UNIX) || defined (LINUX)
int 	kbhit 				(void);
#endif 

// chkerr.c
void	CheckPrinterStatus 	(int status, int Version);
void	CheckFiscalStatus 	(int status, int Version);

// menu.c
void    PrintMenu 			(int Page, int NPages);
int 	GetNPages 			(void);
