void NewLevel( char *linetxt, int lev );

#define  MAXLEVEL  12      // Cantidad de anidamientos adimitidos

void
PlaySequence (void)
{
	char  TempBuff[255];
	int   len;
	int   times = 0;
	char  Filename[300];
	char  TmpBuff[100], *ptr;
	char  c;
	char  *Fields[1];
int level = 1;           // nivel en el que me encuentro


	if ( Programming ) 
	{
		fclose(fh);
		Programming = FALSE;   
		ShowLine ("\n\n\nSecuencia programada. "
			   "Presione una tecla para continuar...\n");
		Getch();
		return;
	}

	// ***** Ejecuci�n del Archivo *****

	ptr = Ask ("Nombre del archivo a reproducir : ", &len, TRUE);

	strcpy (Filename, ptr);

	if ( access(Filename, 0) != 0 ) 
	{
		ShowLine("\n\nNo existe el archivo <%s>. "
			   "Presione una tecla para continuar...\n", Filename);
		Getch();
		return;
	}

	ptr = Ask ("\nIngrese Numero de repeticiones o presione <enter> \n"
			   "para ejecutar 1 vez : ", &len, TRUE);

	if ( strlen (ptr) != 0 )
		times = atoi (ptr);
	else times = 1;

	Playing = TRUE;

	if( (fh = fopen(Filename, "rt")) == NULL )
	{
		ShowLine("No se puede Abrir el Archivo <%s>. \n"
			   "Presione una tecla para continuar...\n", Filename);
		Getch();
		return;
	}

	while ( times-- ) 
	{
		fseek (fh, 0L, SEEK_SET);
		
		while ( fgets (TempBuff, sizeof (TempBuff), fh) )
		{
			len = strlen( TempBuff );
			TempBuff [len - 1] = 0;
			KeepAliveCounter   = 0;

			split (TempBuff, Fields, 1);
		
			if ( !strlen (TempBuff) )
				continue;

            if ( TempBuff[0] == '/' && TempBuff[1] == '/' )
                continue;

// *** Verificando la existencia de inclusi�n de otros ***
// *** archivos con comandos ( #include  filecmd ).    ***
// *** ------------------------------------------------***
if ( TempBuff[0] == '.' && TempBuff[1] == '.' )
{
	NewLevel( TempBuff, level );
	continue;
}


			if ( SendFiscalCommand(TempBuff, NULL) < 0 )
				goto EndPlaying;
		}
	}

EndPlaying:

	fclose(fh);

	ShowLine("\nSecuencia ejecutada.\n");
	WaitKey ("Presione una tecla para continuar...\n");

	Playing = FALSE;

	return;
}


// ********************************************************************

void
NewLevel( char *linetxt, int lev )
{
	FILE *fd;
	char otherfile[300];
	int nfield, lenbuf;
	char  *Fields[1];
	char bufftemp[100];
	
	if ( lev >= MAXLEVEL )
	{
		ShowLine("\nExcede de %d niveles de anidamiento !!\n", MAXLEVEL);
		WaitKey ("Presione una tecla para continuar...\n");
		return;
	}
	
	if (( nfield = split ( linetxt, Fields, 2)) != 2 )
		return;
	
	strcpy( otherfile, Fields[1]);
	
	if (( fd= fopen ( otherfile, "rt")) == NULL )
	{
		ShowLine("\nNo se puede arbri el archivo:  \n", otherfile );
		WaitKey ("Presione una tecla para continuar...\n");
		return;
	}
	
	fseek( fd, 0L, SEEK_SET );
	
	while( fgets ( bufftemp, sizeof ( bufftemp ), fd )
	{
		lenbuf = strlen( bufftemp );
		bufftemp[len - 1] = 0;
		split ( bufftemp, Fields, 2);
		
		if ( !strlen (bufftemp) )
			continue;

        if ( bufftemp[0] == '/' && bufftemp[1] == '/' )
            continue;

        // ****  Entro en recursividad  ******
		if ( bufftemp[0] == '.' && bufftemp[1] == '.' )
		{
			NewLevel( bufftemp, lev+1 );
			continue;
		}

		if ( SendFiscalCommand( bufftemp, NULL ) < 0 )
		{
			Close( fd);
			return;
		}
	}
}
