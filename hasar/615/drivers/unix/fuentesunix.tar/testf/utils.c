/*
utils.c
*/

#if defined (UNIX) || defined (LINUX)
#include <unistd.h>
#include <curses.h>
#endif 

#ifdef UNIX 
#include <prototypes.h>
#endif

#ifdef DOS
#include <conio.h>
#endif 

#include <ctype.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <setjmp.h>

#include "ascii.h"
#include "testf.h"

extern jmp_buf jumper;

#if defined (UNIX) || defined (LINUX)
extern WINDOW *W;
#endif 

void
ClearScreen (void)
{
#if defined (UNIX) || defined (LINUX)
	wclear (W);
	wmove (W, 0, 0);
#else
	clrscr ();
#endif
}

void 
ShowLine (char *fmt, ... )
{
	static char BufShow [500];
	va_list argptr;

	va_start(argptr, fmt);
	vsprintf (BufShow, fmt, argptr);
	va_end (argptr);

#if defined (UNIX) || defined (LINUX)
	wprintw (W, "%s", BufShow);
	wrefresh (W);
#else
	printf ("%s", BufShow);
#endif
}

int 
Getch (void)
{
#if defined (UNIX) || defined (LINUX)
	return wgetch (W);
#else
	return getch ();
#endif
}

char *
Ask (char *msg, int *Len, int NL)
{
	static char Buffer[300];
	int c, i = 0;
	
	ShowLine ("%s%s", NL ? "\n" : "", msg);

	while ( 1 )
	{
		if ( (c = Getch ()) == ESC )
			longjmp (jumper, 1);

		if ( c == '\b' )
		{
			if ( i > 0 )
			{
				Buffer[i--] = 0;
				ShowLine ("\b \b");
			}
			continue;
		}
		
		if ( c == '\r' || c == '\n' )
			break;

		#if defined (UNIX) || defined (LINUX)
		waddch (W, (char)c);
		#else
		putch (c);
		#endif
		
		Buffer[i++]  = c;
	}

	ShowLine ("\n");
		
	Buffer[i] = 0;

	*Len = strlen (Buffer);
		
	return Buffer;
}

int
WaitKey (char *s)
{
	int c;
	if ( s ) 
		ShowLine ("%s", s);
    while ( !(c = Getch()) );
	return c;
}

#if defined (UNIX) || defined (LINUX)

int 
kbhit (void) 
{ 
	return rdchk (0); 
}

int 
stricmp (char *s1, char *s2)
{
	int len1;
	int len2;

	if ( !s1 || !s2 )
		return -1;

	len1 = strlen (s1); 
	len2 = strlen (s2);

	if ( len1 != len2 )
		return len1 - len2;

	while (*s1) 
		if ( tolower (*s1) != *s2 ) 
			break;
		else { s1++; s2++; }

	if ( !*s1 && !*s2 )
		return 0;

	return -1;
}
#endif
