#ifdef MT
#include <mthasys.h>
#endif

#include <stdio.h>
#include <string.h>

#include "split.h"

static char *empty = "";
static char fsdefault[] = " \t\r\n\f\032";
static char *curfs = fsdefault;
static int isfs(register int c);

static int
isfs(c)
register int c;
{
	register char *p = curfs;

	while ( *p )
		if ( c == *p++ )
			return 1;
	return 0;
}

char *
setfs(fs)
char *fs;
{
	char *p;

	if ( fs == NULL )
		fs = fsdefault;
	p = curfs;
	curfs = fs;
	return p;
}

int
split(s, field, nfields)
char *s;
char **field;
int nfields;
{
	register char *p;
	int n, i;
	register int state;

	for ( p = s + strlen(s) - 1 ; p >= s && isfs(*p) ; )
		*p-- = 0;

	for ( p = s, i = 0, state = 0 ; *p && i < nfields ; ++p )
	{
		switch ( state )
		{
			case 0:
				if ( isfs(*p) )
					break;
				field[i++] = p;
				state = 1;
				break;

			case 1:
				if ( !isfs(*p) )
					break;
				*p = 0;
				state = 0;
				break;
		}
	}
	n = i;
	while ( i < nfields )
		field[i++] = "";
	return n;
}

