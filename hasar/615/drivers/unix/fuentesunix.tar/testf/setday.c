/*********************************************************************
*                                                                    *
*     Modulo :                                           SETDAY.C    *
*                                                                    *
*     Descripcion:   Programa para setear fecha y hora solamente     *
*                                                                    *
*     Fecha:         25 de Setiembre de 1998                         *
*     Version:       3.00                                            *
*                                                                    *
*     Autores:       Jorge G. Gonzalez 								 *
*					 Marcelo Emilio Bartolome    					 *
*    				 Eduardo Sabaj	(09/09/1999)     				 *
*                    Ricardo D. Cardenes ( 21/02/2001 )              *
*																	 *
*     Departamento:  Software de Base                                *
*                                                                    *
*********************************************************************/

#ifdef UNIX 
#include <prototypes.h>
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>

#if defined (UNIX) || defined (LINUX)
#include <unistd.h>
#include <curses.h>
#endif 

#ifdef DOS

#include <conio.h>
#include <bios.h>
#include <io.h>
#include <dos.h>

#include "getopt.h"
#include "fiserr.h"

#endif

#include <stdarg.h>
#include <ctype.h>
#include <signal.h>
#include <setjmp.h>
#include <fcntl.h>
#include <time.h> 

#include "ascii.h"
#include "testf.h"
#include "menu.h"
#include "split.h"
#include "xntoi.h"
#include "p320f.h"
#include "pr4.h"
#include "chile.h"

#ifdef DOS
#include "fislib.h"
#else
#include "unxlib.h"
#endif

// *** Prototipos *** 
int SendFiscalCommand	(char *CommandPtr, char **Respuestas);

// *** Variables Estaticas ***
static int     KeepAliveCounter;
static char    CommandBuff [512];
static int     KeepAliveEnabled = 1;

// *** Variables Publicas *** 
int 			CommHandler = -1;
int     		Version;
jmp_buf 		jumper;
unsigned short 	FiscalStatus;
unsigned short 	PrinterStatus;
char    		FiscalAnswer[500];
long    		BaudRate;

int CursesInitialized;

#define MAX_LINES  25

#if defined (UNIX) || defined (LINUX) // *********** UNIX **************

char Usage [] = 
"\nUso : %s -p tty [-m modelo] [-d fecha] [-t hora] \n\n"
"   -p tty    ..... donde tty es la tty a utilizar (tty1a, tty2a, ..)\n"
"   -m modelo ..... donde modelo puede ser cualquiera de los siguientes \n"
"                   strings : 950, 951, 614, 615, 262, pr4, pj20, 320, \n"
"                   321, 425, pl8f o 2008\n"
"   -d fecha  ..... en el formato AAMMDD (si se omite se toma de la PC)\n"
"   -t hora   ..... en el formato HHMMSS (si se omite se toma de la PC)\n"
"\n"
"Nota : Se requiere CIERRE Z previo\n\n";

static int wAlto  = MAX_LINES;
static int wAncho = 80;
static int wX     = 0;
static int wY     = 0;

WINDOW *W;

#define ctrl(x) ((x) & 0x1f)

// En utils.c
extern int stricmp (char *s1, char *s2);

#else     // ************* DOS **************

char Usage [] = 
"\nUso : %s -p port [-m modelo] [-d fecha] [-t hora] \n\n"
"   -p port   ..... donde port es el COM serie a utilizar\n"
"   -m modelo ..... donde modelo puede ser cualquiera de los siguientes \n"
"                   strings : 950, 951, 614, 615, 262, pr4, pj20, 320, \n"
"                   321, 425, pl8f o 2008\n"
"   -d fecha  ..... en el formato AAMMDD (si se omite se toma de la PC)\n"
"   -t hora   ..... en el formato HHMMSS (si se omite se toma de la PC)\n"
"\n"
"Nota : Se requiere CIERRE Z Previo\n\n";

#endif    // *********************************

extern int errno;

void 
CGetTime (int *hour, int *minute, int *second, int * sec100)
{
	time_t mytime;
	struct tm *t;

	time (&mytime);
	t = localtime (&mytime);

	*hour   = t->tm_hour;
	*minute = t->tm_min;
	*second = t->tm_sec;
	*sec100 = 0;
}

void 
CGetDate( int *anio, int *mes, int *dia )
{
	time_t mytime;
	struct tm *t;

	time (&mytime);
	t = localtime (&mytime);

	*anio = t->tm_year >= 100 ? t->tm_year - 100 : t->tm_year;
	*mes  = t->tm_mon + 1;
	*dia  = t->tm_mday;
}

#ifdef DOS
#pragma argsused
void 
FISdebug (int level, char *fmt, ...)
#else
FISdebug (char *fmt, ...)
#endif 
{
}

void
usage (char *Program)
{
	if ( CursesInitialized )
		ShowLine (Usage, Program);
	else printf (Usage, Program);

    exit(1);
}

void
done (void)
{
	if ( CommHandler != -1 )
		CloseCommFiscal (CommHandler);

	#if defined (UNIX) || defined (LINUX)
	endwin ();
	#endif
}

// Callback de la libreria que es llamado cuando el controlador 
// envia DC2 o DC4.

#ifdef DOS
#pragma argsused
#endif 

void
KeepAlive (int Caracter, int Port)
{
	if ( !KeepAliveEnabled )
		return;
		
	if ( kbhit () && Getch () == ESC )
		longjmp (jumper, 1);

	if ( Caracter == DC4 )
		ShowLine ("DC4 ");

	if ( Caracter == DC2 )
		ShowLine ("DC2 ");

	KeepAliveCounter ++;
}

void 
CommandHeader (char *Descripcion, unsigned char CodOper)
{
	ShowLine ("Comando : %s\n", Descripcion);
	ShowLine ("CodOper : %02Xh (ASCII - '%c') \n\n", CodOper, CodOper);
}

int
main(int argc, char *argv[])
{
	int i, n;
	char *Program = argv[0];
	int ComPort = 0;
	long NewBaud = -1L;
	static char Modelo [100];
	static char fechafiscal [30];
	static char horafiscal [30];
	char *PtrAux = CommandBuff;
	char **Respuest;
	int hora,minutos,segundos,milesimas;
	int elanio,elmes,eldia;

	#if defined (UNIX) || defined (LINUX)
	static char PortName [50];
	#endif
	
	fechafiscal[0] = '\0';
	horafiscal[0] = '\0';

	while ( (n = getopt(argc, argv, "m:p:d:t:")) != EOF )
		
		switch (n)
		{
			case 'p':

				#if defined (UNIX) || defined (LINUX)
				strcpy (PortName, optarg);
				#else
            	ComPort = atoi (optarg);
				#endif

				break;

			case 'd':
				strcpy (fechafiscal, optarg);
				break;
				
			case 't':
				strcpy (horafiscal, optarg);
				break;

			case 'm':
				strcpy (Modelo, optarg);
				break;
				
			default:
				usage (Program);
				break;
		}

	#if defined (UNIX) || defined (LINUX)

		if ( strlen (PortName) == 0 )
			usage (Program);

		CommHandler = OpenCommFiscal (PortName);

		// Inicializa la sesion de curses.
		initscr (); noecho (); raw (); 

		setscrreg (0, MAX_LINES);

		W = newwin (wAlto, wAncho, wX, wY);

		scrollok (W, TRUE); keypad (W, TRUE);

		CursesInitialized = 1;

	#else

		if ( ComPort == 0 )
			usage (Program);

		if (ComPort < 1 || ComPort > 4)
		{
			ShowLine ("No puede abrir COM %d\n", ComPort );
			exit (1);
		}

		CommHandler = OpenCommFiscal (ComPort);

	#endif

	if ( CommHandler < 0 )
	{
		#if defined (UNIX) || defined (LINUX)
		printf ("Error abriendo /dev/%s, errno %d\n", PortName, errno);
		#else
		printf ("Error abriendo COM%d\n", ComPort);
		#endif
		exit (1);
	}

	ClearScreen( );

	SetKeepAliveHandler (KeepAlive);

	signal (SIGINT,   exit);
	signal (SIGTERM,  exit);
	signal (SIGABRT,  exit);

	atexit (done);

	// CheckController verifica la existencia del 
	// controlador fiscal.

	if ( strlen (Modelo) )
	{
		// Baudrate default de 9600.
		BaudRate = 9600;

		if ( !stricmp (Modelo, "pj20") )
		{
			NewProtocol ();
			Version = VER_ARTJET;		
		}
		
		else if ( !stricmp (Modelo, "320") )
		{
			NewProtocol ();
			Version = VER_PRN320;
		}

		else if ( !stricmp (Modelo, "321") )
		{
			NewProtocol ();
			Version = VER_PRN321;
		}
		
		else if ( !stricmp (Modelo, "2008") )
		{
			NewProtocol ();
			Version = VER_NCR;
		}

		else if ( !stricmp (Modelo, "425") ) 
		{
			NewProtocol ();
			Version = VER_PRN425;
		}
					
		else if ( !stricmp (Modelo, "pl8f") )
		{
			NewProtocol ();
			Version = VER_OKIPAGE;
		}
		
		else if ( !stricmp (Modelo, "pr4") || 
			!stricmp (Modelo, "615") || !stricmp (Modelo, "951") )
			Version = VER_PRN_615_951_PR4;

		else if ( !stricmp (Modelo, "262") || 
			!stricmp (Modelo, "614") || !stricmp (Modelo, "950") )
			Version = VER_PRN_614_950_262;
		
		else if ( !stricmp (Modelo, "chile") )
			Version = VER_CHILE;

		else 
		{
			ShowLine ("Modelo \"%s\" NO reconocido\n", Modelo);
			exit (1);
		}
	}	
	
	else CheckController ();

	// Veo si hay que inicializar el printer a una determinada 
	// velocidad. 
	
	if ( NewBaud != -1L && SetNewBaud (NewBaud) < 0 )
		exit (1);

	setjmp (jumper);

	KeepAliveCounter = 0;
	
	if (!(strlen(fechafiscal))){
		ShowLine("\n#################################\n");
		ShowLine("##  Pidiendo la FECHA a la PC  ##\n");
		ShowLine("#################################\n");
		CGetDate( &elanio, &elmes, &eldia );
		// elanio = ( elanio < 2000 ) ? ( elanio - 1900 ) : ( elanio - 2000 );
		sprintf( fechafiscal,"%02d%02d%02d", elanio, elmes, eldia );
	}
		
	if (!(strlen(horafiscal))){
		ShowLine("\n################################\n");
		ShowLine("##  Pidiendo la HORA a la PC  ##\n");
		ShowLine("################################\n");
		CGetTime( &hora, &minutos, &segundos, &milesimas );
		sprintf( horafiscal,"%02d%02d%02d", hora, minutos, segundos );
	}

	sprintf( PtrAux,"X\x1c%s\x1c%s",fechafiscal,horafiscal );
	SendFiscalCommand ( PtrAux, Respuest );
	
	return 0;
}

// **************************************************************
// ***** RUTINAS DE USO GENERAL *********************************
// **************************************************************

static char StatPrnMsg [] = "\n\n"
	"El impresor no puede continuar con el documento dado que el mismo\n"
	"est� en condici�n de error. Por favor, corrija el problema, y presione\n"
	"una tecla para enviar STATUS de impresor y ver la respuesta al comando\n"
	"original ... ";

#ifdef DOS
#pragma argsused
#endif 

int
SendFiscalCommand(char *Command, char **Respuestas)
{
	int Result;
	int Enviado, Recibido;
	int CmdRecibido;
	unsigned char ComandoEnviado = *Command;

	ShowLine ("\nComando  : [%s]\n", Command);
	
	Result = MandaPaqueteFiscal (CommHandler, 
		Command, &FiscalStatus, &PrinterStatus, FiscalAnswer);

	ObtenerNumeroDePaquetes (&Enviado, &Recibido, &CmdRecibido);
	
	if ( Result != 0 )
	{
		if ( Result != ERR_STATPRN ) 
		{
			if ( KeepAliveCounter ) 
				ShowLine ("\n");
			ShowLine ("Error de comunicaci�n con el impresor !\n");
	    	//WaitKey ("\nPresione una tecla para continuar...");
			return Result;
		}

		// Si el comando enviado es distinto a un statprn, me 
		// quedo en un loop hasta que el problema del printer se 
		// solucione, o presionen ESC para salir.

		if ( ComandoEnviado != CMD_STATPRN )
		{
			do 
			{
				ShowLine ("\nRespuesta: [%c%c%s]\n\n", CmdRecibido, 
					SEP, FiscalAnswer);

				CheckFiscalStatus  (FiscalStatus,  Version);
				CheckPrinterStatus (PrinterStatus, Version);

				ShowLine (StatPrnMsg);

				if ( Getch () == ESC )
					return Result;

				ClearScreen ();

				Result = ObtenerStatusImpresor (CommHandler,  
					&FiscalStatus, &PrinterStatus, FiscalAnswer);

				ObtenerNumeroDePaquetes (&Enviado, &Recibido, &CmdRecibido);

				ShowLine ("\n\nComando  : [%c]", CMD_STATPRN);

					
			} while ( Result == ERR_STATPRN );

			ShowLine ("\n");
				
			ClearScreen ();
			ShowLine ("\n\nComando  : [%c]", CMD_STATPRN);
		}

	}

	if ( KeepAliveCounter ) 
		ShowLine ("\n");

	ShowLine ("Respuesta: [%c%c%s]\n\n", CmdRecibido, SEP, FiscalAnswer);

	CheckFiscalStatus  (FiscalStatus, Version);
	CheckPrinterStatus (PrinterStatus, Version);

	return Result;
}

// Para que no de error, dado que CMDS.C la llama.
//------------------------------------------------
#ifdef DOS
#pragma argsused
#endif 
void 
MakeCommand (char Oper, Formatos *Form, char *ExtraInfo, char **Respuestas)
{
}
