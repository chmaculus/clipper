/*
pd425.h
*/

// *********************************************************************
// ********************* Campos de los Comandos  ***********************
// *********************************************************************

Formatos Open_Df_PD425 [] =
{
	"Tipo de documento a abrir : \n"
	"'A' ..... Factura A\n"
	"'B' ..... Factura B/C\n"
	"'a' ..... Recibo A\n"
	"'b' ..... Recibo B/C\n"
	"'D' ..... Nota de D�bito A\n"
	"'E' ..... Nota de D�bito B/C\n"
	"'T' ..... Ticket : ", 	            NULL, NULL,

	"Estaci�n de Impresi�n :\n"
	"'T' ..... Ticket/Factura\n"
	"'S' ..... Slip : ", 	  			NULL, NULL,

	NULL, 								NULL, NULL
};

Formatos Close_Df_PD425 [] =
{
	"Cantidad de copias : ",            NULL, NULL,
	NULL, 								NULL, NULL
};

Formatos Print_Fiscal_Text_PD425 [] = 
{
	"Texto Fiscal : ", 					NULL, ActionText,
	"Identificador de Display : ", 		NULL, NULL,
	NULL, 								NULL, NULL
};

Formatos Print_Line_Item_PD425 [] = 
{
   	"Descripci�n : ", 					NULL, NULL,
	"Cantidad :\n"
	"[+/-][0...8 enteros].[0...10 decimales] : ",   NULL, NULL,

	"Monto (XXXXXX.XXXX) : ", 		NULL, NULL,
	"Tasa de IVA (XX.XX) : ",			NULL, NULL,

	"Operaci�n \n"
	"'m' ..... Negativa\n"
	"'M' ..... Positiva : ", 			NULL, NULL,

	"Coeficiente de Impuestos Internos :\n"
	"0.nnnnnnnn .......... (ej: 0.12345) Coef. 'K' para imp. internos porcent.\n"
	"[+]0.nnnnnnnn ....... (ej: +0.4563) Coef. 'K' para imp. internos fijos\n"
	"[$]nnnnnn.nnnnnnnn .. (ej: $3.4567) Imp. internos fijos\n"
	"[%]nnnnnn.nnnnnnnn .. (ej: %2.456)  Imp. internos porcentuales : ",	NULL, NULL,

	"Identificador de Display : ",	NULL, NULL,

	"Monto \n"
	"'T' ..... Total\n"
	"Otro: Base Imponible : ", 			NULL, NULL,
	NULL, 								NULL, NULL
};

Formatos General_Discount_PD425 [] =
{
	"Descripci�n : ", 									NULL, NULL,
	"Monto (XXXXXXXXX.XX) : ", 							NULL, NULL,

	"Calificador :\n"
	"'M' .... Recargo\n"
	"'m' .... Descuento : ", 	                        NULL, NULL,

	"Identificador de Display : ", 						NULL, NULL,

	"Monto :\n"
	"'T' .... Total\n"
	"Otros .. Base Imponible : ", 		                NULL, NULL,

	NULL, 												NULL, NULL
};

Formatos Last_Item_Discount_PD425 [] = 
{
	"Descripci�n : ", 									NULL, NULL,
	"Monto (XXXXXXXXX.XX) : ", 							NULL, NULL,

	"Calificador :\n"
	"'M' .... Recargo\n"
	"'m' .... Descuento : ", 	                        NULL, NULL,

	"Identificador de Display : ", 						NULL, NULL,

	"Monto :\n"
	"'T' .... Total\n"
	"Otros .. Base Imponible : ", 		                NULL, NULL,

	NULL, 												NULL,  NULL
};

Formatos Return_Recharge_PD425 [] = 
{
	"Descripci�n : ", 									NULL, NULL,
	"Monto (XXXXXXXXX.XX) : ", 							NULL, NULL,
	"Tasa de IVA (XX.XX) : ", 							NULL, NULL,

	"Calificador :\n"
	"'M' .... Recargo\n"
	"'m' .... Descuento : ", 	                        NULL, NULL,

	"Coeficiente de Impuestos Internos :\n"
	"0.nnnnnnnn .......... (ej: 0.12345) Coef. 'K' para imp. internos porcent.\n"
	"[+]0.nnnnnnnn ....... (ej: +0.4563) Coef. 'K' para imp. internos fijos\n"
	"[$]nnnnnn.nnnnnnnn .. (ej: $3.4567) Imp. internos fijos\n"
	"[%]nnnnnn.nnnnnnnn .. (ej: %2.456)  Imp. internos porcentuales : ",	NULL, NULL,

	"Identificador de Display : ", 							NULL, NULL,

	"Monto :\n"
	"'T' .... Total\n"
	"Otros .. Base Imponible : ", 				                NULL, NULL,

	"Tipo de Operacion :\n"
	"'B' .... Bonificaci�n/Recargo\n"
	"Otros .. Envases : ", 	                                    NULL, NULL,
	
	NULL, 														NULL, NULL
};


Formatos Perceptions_PD425 [] = 
{
	"Al�cuota de IVA (XX.XX) : ", 	NULL, NULL,
	"Descripci�n : ", 				NULL, NULL,
	"Monto (XXXXXXXXX.XX) : ", 		NULL, NULL,
	NULL, 							NULL, NULL
};


Formatos Charge_Non_Reg_Tax_PD425 [] =
{
	"Monto (XXXXXXXXX.XX) : ", 		NULL, NULL,
	NULL, 							NULL, NULL
};

Formatos Subtotal_PD425 [] = 
{
	"Calificador de Impresi�n :\n"
	"'P' .... Imprime\n"
	"Otros .. No imprime : ", 		NULL, NULL,

	"Descripci�n : ", 				NULL, NULL,
	"Identificador de Display : ", 	NULL, NULL,
	NULL, 							NULL, NULL
};

Formatos Total_Tender_PD425 [] = 
{
	"Descripci�n : ", 				NULL, NULL,
	"Monto (XXXXXXXXX.XX): ", 		NULL, NULL,

	"Calificador de Pago :\n"
	"'T' .... Pago\n"
	"'C' .... Cancelaci�n : ",		NULL, NULL,

	"Identificador de Display : ",	NULL, NULL,

	NULL, 							NULL, NULL
};

Formatos Daily_Close_By_Date_PD425 [] =
{
	"Fecha Inicial (AAMMDD): ", 	NULL, NULL,
	"Fecha Final  (AAMMDD) : ", 	NULL, NULL,
	NULL, 							NULL, NULL
};

Formatos Daily_Close_By_Z_Num_PD425 [] =
{
	"Nro. de Z Inicial : ", 		NULL, NULL,
	"Nro. de Z Final : ",   		NULL, NULL,
	NULL, 							NULL, NULL
};

Formatos Get_Daily_Report_PD425 [] =
{
	"Fecha (AAMMDD) o Nro. de Z : ", 			NULL, NULL,

	"Calificador :\n"
	"'T' .... Fecha\n"
	"'Z' .... Zeta : ",							NULL, NULL,

	NULL, 										NULL,  NULL
};

Formatos Print_Non_Fiscal_Text_PD425 [] =
{
	"Texto No Fiscal : ", 				NULL, ActionText,
	"Identificador de Display : ", 		NULL, NULL,
	NULL, 								NULL, NULL
};

Formatos Set_Customer_Data_PD425 [] =
{
	"Nombre � Raz�n Social : ", NULL, NULL,
	
	"C.U.I.T. � Documento : ", NULL, NULL,

	"Responsabilidad frente al IVA ... \n"
	"'I' .... Inscripto\n"
	"'N' .... No Inscripto\n"
	"'E' .... Exento\n"
	"'B' .... Bienes de Uso\n"
	"'C' .... Consumidor Final\n"
	"'M' .... Responsable Monotributo\n"
	"'A' .... No Responsable \n"
	"'T' .... No Categorizado : ", NULL, NULL,

	"Calificador de C.U.I.T. � Documento ... \n"
	"'C' .... CUIT\n"
	"'0' .... LE\n"
	"'1' .... LC\n"
	"'2' .... DNI\n"
	"'3' .... Pasaporte\n"
	"'4' .... CI\n"
	"' ' .... Documento no especificado : ",		NULL, NULL,

	"Domicilio Comercial (50 caracteres) : ",		NULL, NULL,

	NULL, 											NULL, NULL
};

Formatos Set_Fantasy_Name_PD425 [] = 	
{
	"L�nea ( 1~2 ) : ",  	NULL, NULL,
	"Texto de L�nea : ", 	NULL, ActionProgText,
	NULL, 					NULL, NULL
};

Formatos Set_Header_Trailer_PD425 [] =
{
	"L�nea ( 1 a 10: Encabezado; 11 a 20: Cierre ) : ", 	NULL, NULL,
	"Texto de L�nea : ", 							NULL, ActionProgText,
	NULL, 											NULL, NULL
};

Formatos Set_Bar_Code_PD425 [] =
{
	"Tipo de C�digo ... \n"
	"'1' .... EAN13\n"
	"'2' .... EAN8\n"
	"'3' .... UPCA\n"
	"'4' .... I2OF5 : ", 	NULL, NULL,
	"C�digo : ", 			NULL, NULL,

	"Calificador Num�rico ... \n"
	"( 'N'-Imprime N�meros; Otro No Imprime ) : ", 	NULL, NULL,

	"Calificador de Impresi�n ( 'P'-Imprime; 'G'-Programa ) :", NULL, NULL,
	NULL, NULL, NULL
};


Formatos Config_Cf_By_Block_PD425 [] =
{
	"L�mite Tique Factura a Cosumidor Final (XXXXXX.XX) : ", 	NULL, NULL,
	"Limite de Ticket Factura Otros (XXXXXX.XX) : ", 			NULL, NULL,
	"Porcentaje IVA No Inscripto (XX.XX) : ", 					NULL, NULL,
	"Copias de Factura (1~3) : ", 								NULL, NULL,

	"Leyenda CAMBIO $0.00 :\n"
	"'P' .... Imprime\n"
	"Otros .. No Imprime : ", 									NULL, NULL,

	"Leyendas Con.Final, Ing Brut, etc.\n"							 
	"'P' .... Imprime\n"
	"Otros .. No Imprime :", 									NULL, NULL,

	"Corte de papel ... \n"											  
	"'F' .... Total\n"
	"'P' .... Parcial\n"
	"'N' .... No Corta :",										NULL, NULL,

	NULL, 														NULL, NULL
};

Formatos Set_Config_Full_PD425 [] = 
{
	"Calif. de Impresi�n de Reporte:\n"
	"'P' .... Imprime\n"
	"Otros .. No Imprime : ", 									NULL, NULL,
	
	"Calif. de Carga Default en Par�metros Ausentes:\n"
	"'P' .... Carga\n"
	"Otros .. NO Carga : ", 							        NULL, NULL,
	
	"L�mite para Consumidor Final sin Documentaci�n (XXXXXXXXX.XX) : ", NULL, NULL,
	"L�mite para Ticket Factura A (XXXXXXXXX.XX) : ", 			NULL, NULL,
	"Porcentaje de IVA NO inscripto (XX.XX) : ", 				NULL, NULL,
	
	"N�mero de Copias de DF:\n"									  
	"'0' .... No Copias \n"
	"'1' .... Original \n"
	"'2' .... Duplicado \n"
	"'3' .... Triplicado \n"
	"'4' .... Cuadruplicado : ", 								NULL, NULL,
	
	"Calif. de impresi�n de CAMBIO $0.00: \n"						  
	"'P' .... Imprime\n"
	"Otros .. NO Imprime : ", 						            NULL, NULL,
	
	"Calif. de impresi�n de leyendas opcionales: \n"
	"'P' .... Imprime\n"
	"Otros .. NO Imprime : ", 						            NULL, NULL,
	
	"Calif. de impresi�n de tipo de corte de papel:\n"
	"'F' .... Total\n"
	"'P' .... Parcial\n"
	"'N' .... NO Corta : ", 				                    NULL, NULL,
	
	"Calif. de impresi�n de marco:\n"
	"'P' .... Imprime\n"
	"Otros .. NO Imprime : ", 						            NULL, NULL, 
	
	"Calif. de Re-Impresi�n de documentos cancelados\n"
	"por corte de energ�a: \n"
	"'P' .... Re-Imprime\n"
	"Otros .. NO Re-Imprime : ", 				                NULL, NULL,
	
	"Descripci�n del Medio de Pago para Saldo: \n"
	"(80 caracteres) : ",										NULL, NULL,
	
	"Sonido:\n"
	"'P' .... Habilita\n"
	"Otros .. NO Habilita : ",                                  NULL, NULL,

	"Alto de la hoja: \n"
	"'M' .... Reducido\n"
	"'A' .... A4\n"
	"'O' .... Oficio : ",										NULL, NULL,

	"Ancho de la hoja:\n"
	"'M' .... Reducido\n"
	"'N' .... Normal : ",                                       NULL, NULL,
	
	"Estaci�n de impresi�n del reporte X/Z:\n"
	"'T' .... Ticket\n"
	"'S' .... Slip : ",                                         NULL, NULL,
	
	"Modo de impresi�n:\n"
	"'M' .... Ticket + Tractor\n"
	"'A' .... Tractor : ",                                      NULL, NULL,

	NULL, 														NULL, NULL
};																	  

Formatos Config_Cf_By_One_PD425 [] =
{
	"",   NULL, ActionConfigIndiv_PD425,
	NULL, NULL, NULL
};

Formatos Get_Header_Trailer_PD425 [] =
{
	"L�nea ( 1 a 10: Encabezado; 11 a 20: Cierre ) : ", NULL, NULL,
	NULL, 												NULL, NULL
};																	  

Formatos Set_Date_Time_PD425 [] = 
{
	"Fecha (AAMMDD) : ", 								NULL, NULL,
	"Hora  (HHMMSS) : ", 								NULL, NULL,
	NULL, 												NULL, NULL
};

Formatos Change_Iva_Resp_PD425 [] =
{
	"Nueva Responsabilidad \n"
	"'I' ... Responsable Inscripto\n"
	"'N' ... Responsable No Inscripto\n"
	"'E' ... Exento\n"
	"'M' ... Reponsable Monotributo\n"
	"'A' ... No Responsable : ", 						NULL, NULL,
																	  
	NULL, 												NULL, NULL
};

Formatos Set_Logo_Custom_PD425 [] = 
{
	"Calificador de Tipo de Informaci�n ... \n"
	"'I' ... Comienzo de carga del logotipo.\n"
	"'C' ... Carga logotipo en curso.\n"
	"'F' ... Fin de carga del logotipo : ", 			NULL, NULL,

	"Datos del archivo .BMP del logotipo ... \n"
	"(Cada byte del archivo se desglosa en 2 bytes (hexa) en\n" 
	"donde uno tiene el nibble superior y el otro el nibble inferior) : ", NULL, NULL,
	
	NULL, 												NULL, NULL
};

Formatos Open_DNFH_PD425 [] = 
{
	"Calificador de Tipo de DNFH : ... \n"
	"'R' .... Nota de cr�dito A\n"
	"'S' .... Nota de cr�dito B/C\n"
	"'r' .... Remito\n"
	"'s' .... Orden de salida\n"
	"'t' .... Resumen de cuenta\n"
	"'u' .... Cotizaci�n\n"
	"'x' .... Recibo X\n"
	"'U' .... Cargo a la habitaci�n : ",				NULL, NULL,
																	  
	"Estaci�n de Impresi�n :\n"									  
	"'T' ..... Ticket/Factura\n"
	"'S' ..... Slip : ", 	  							NULL, NULL,

	"N�mero de documento NO fiscal homologado : ",	NULL, NULL,
																	  
	NULL, 												NULL, NULL
};

Formatos Close_DNFH_PD425 [] =
{
	"Cantidad de copias : ",            NULL, NULL,
	NULL, 								NULL, NULL
};

Formatos Close_DNF_PD425 [] =
{
	"Cantidad de copias : ",            NULL, NULL,
	NULL, 								NULL, NULL
};

Formatos Item_Remito_PD425 [] = 
{
	"Descripci�n de Item (108 caracteres) : ",			NULL, NULL,
			
	"Cantidad :\n"
	"[+/-][0...8 enteros].[0...10 decimales] : ",   	NULL, NULL,
																	  
	"Calificador de Campo de Display ... \n"
	"'0' .... No Modifica (default)\n"
	"'1' .... Escribe en display \n"
	"'2' .... Incrementa cantidad de repeticiones : ",	NULL, NULL,
																	  
	NULL, 												NULL, NULL
};

Formatos Item_Sumary_PD425 [] = 
{
	"Fecha del comprobante (AAMMDD) : ",				NULL, NULL,
	"N�mero del comprobante (20 caracteres) :",			NULL, NULL,
	"Descripci�n del comprobante : ",					NULL, NULL,
	"Monto Debe  (XXXXXXXXX.XX) : ",					NULL, NULL,
	"Monto Haber (XXXXXXXXX.XX) : ",					NULL, NULL,
																	  
	"Calificador de campo de display ... \n"
	"'0' .... No modifica (default) \n"
	"'1' .... Escribe en el display \n"
	"'2' .... Incrementa cantidad de repeticiones : ", 	NULL, NULL,
																	  
	NULL,												NULL, NULL
};

Formatos Item_Quotation_PD425 [] = 
{
	"Descripci�n de Item (hasta 120 caracteres) : ",	NULL, NULL,

	"Calificador de campo de Display ... \n"						  
	"'0' .... No Modifica\n"										  
	"'1' .... Escribe en display\n"
	"'2' .... Incrementa cantidad de repeticiones : ", 	NULL, NULL,
																	  
	NULL,												NULL, NULL
};

Formatos Get_Fantasy_Name_PD425 [] = 
{
	"N�mero de l�nea ( '1' - '2' ) : ",					NULL, NULL,
	NULL,												NULL, NULL
};																	  

Formatos SetRemitNumLine_PD425 [] = 
{
	"N�mero de l�nea ( '1' - '2' ) : ", 				NULL, NULL,
	"Texto de l�nea (20 caracteres) : ",				NULL, NULL,
	NULL,												NULL, NULL
};

Formatos GetRemitNumLine_PD425 [] = 
{
	"N�mero de l�nea ( '1' - '2' ) : ",					NULL, NULL,
	NULL,												NULL, NULL
};																	  

Formatos Set_Receipt_Info_PD425 [] = 
{
	"Texto de l�nea (hasta 106 caracteres) : ",			NULL, NULL,
	NULL,												NULL, NULL
};																	  

Formatos ChangeIngBrutos_PD425 [] = 
{
	"C�digos de ingresos brutos: (30 caracteres) : ",   NULL, NULL,
	NULL,												NULL, NULL
};

Formatos SetVoucher1_PD425 [] = 
{
	"Nombre de cliente : ", 							NULL, NULL,
	"Nombre de tarjeta : ", 							NULL, NULL,
	
	"Calificador de la operaci�n : \n"
	"'C' .... Compra\n"
	"'V' .... Anulaci�n de la compra\n"
	"'D' .... Devoluci�n\n"
	"'A' .... Anulaci�n de la devoluci�n : ", 			NULL, NULL,

	"N�mero de la tarjeta : ", 							NULL, NULL,
	"Fecha de vencimiento de tarjeta (AAMM): ", 		NULL, NULL,

	"Tipo de tarjeta :\n"
	"'D' .... D�bito\n"
	"'C' .... Cr�dito : ", 			                    NULL, NULL,
	
	"\nCantidad de Cuotas : ", 							NULL, NULL,
	
	NULL,												NULL, NULL
};

Formatos SetVoucher2_PD425 [] = 
{
	"C�digo del comercio : ", 							NULL, NULL,
	"N�mero de terminal : ", 							NULL, NULL,
	"N�mero de lote : ",     							NULL, NULL,
	"N�mero de cup�n : ",    							NULL, NULL,

	"Tipo de ingreso de datos :\n"
	"'*' .... Manual\n"
	"' ' .... Banda : ",								NULL, NULL,

	"Operaci�n :\n"
	"'N' .... OnLine\n"
	"'F' .... OffLine : ", 								NULL, NULL,
	
	"N�mero de autorizaci�n : ", 						NULL, NULL,
	"Importe de la operaci�n : ", 						NULL, NULL,
	"N�mero del comprobante fiscal : ", 				NULL, NULL,

	NULL,												NULL, NULL
};

Formatos PrintVoucher_PD425 [] = 
{
	"Cantidad de Copias (1 a 3) : ", 					NULL, NULL,
	NULL,												NULL, NULL
};

// *********************************************************************
// ********************* Respuestas a los comandos *********************
// *********************************************************************

char *Resp_DailyClose_PD425 [] = 
{
	"N�mero de Reporte",
	"N�mero de DF Cancelados",
	"N�mero de DNFH Emitidos",
	"N�mero de DNF Emitidos",
	"N�mero de DF Emitidos",
	"Reservado",
	"N�mero de �ltimo Documento B/C",
	"N�mero de �ltimo Documento A",
	"Monto Acumulado de Ventas de DF",
	"Monto Acumulado de IVA de DF",
	"Monto Acumulado de II de DF",
	"Monto Acumulado de Percep. de DF",
	"Monto Acumulado de IVA No Insc de DF",
	"N�mero de �ltima nota de cr�dito B/C",
	"N�mero de �ltima nota de cr�dito A",
	"Monto Acumulado de Cr�ditos de NC",
	"Monto Acumulado de IVA de NC",
	"Monto Acumulado de II de NC",
	"Monto Acumulado de Percep. de NC",
	"Monto Acumulado de IVA No Insc de NC",
	"N�mero de �ltimo remito"
};

char *Resp_GetWorkingMemory_PD425 [] = 
{
	"N�mero de DF Cancelados",
	"N�mero de DNF Emitidos",
	"N�mero de DF Emitidos",
	"N�mero de �ltimo Documento B/C",
	"N�mero de �ltimo Documento A",
	"Monto Acumulado de Ventas de DF",
	"Monto Acumulado de IVA de DF",
	"Monto Acumulado de II de DF",
	"Monto Acumulado de Percep. de DF",
	"Monto Acumulado de IVA No Insc de DF",
	"N�mero de �ltima nota de cr�dito B/C",
	"N�mero de �ltima nota de cr�dito A",
	"Monto Acumulado de Cr�ditos de NC",
	"Monto Acumulado de IVA de NC",
	"Monto Acumulado de II de NC",
	"Monto Acumulado de Percep. de NC",
	"Monto Acumulado de IVA No Insc de NC",
	"N�mero de �ltimo remito"
};

char *Resp_OpenDF_PD425 [] = 
{
	"N�mero de documento fiscal reci�n emitido"
};

char *Resp_Subtotal_PD425 [] = 
{
	"Cantidad de items vendidos",
	"Monto acumulado de ventas",
	"Monto acumulado de IVA",
	"Monto pagado parcial",
	"Monto acumulado de IVA No Inscripto",
	"Monto acumulado de impuestos internos"
};

char *Resp_TotalTender_PD425 [] = 
{
	"Vuelto o monto por saldar"
};

char *Resp_CloseDF_PD425 [] =
{
	"N�mero del documento fiscal reci�n emitido"
};

char *Resp_GetDailyReport_PD425 [] = 
{
	"Fecha de cierre Z reportado",
	"N�mero de cierre Z reportado",
	"N�mero de �ltimo Documento B/C",
	"N�mero de �ltimo Documento A",
	"Monto Acumulado de Ventas de DF",
	"Monto Acumulado de IVA de DF",
	"Monto Acumulado de II de DF",
	"Monto Acumulado de Percep. de DF",
	"Monto Acumulado de IVA No Insc de DF",
	"N�mero de �ltima nota de cr�dito B/C",
	"N�mero de �ltima nota de cr�dito A",
	"Monto Acumulado de Cr�ditos de NC",
	"Monto Acumulado de IVA de NC",
	"Monto Acumulado de II de NC",
	"Monto Acumulado de Percep. de NC",
	"Monto Acumulado de IVA No Insc de NC",
	"N�mero de �ltimo remito"	
};

char *Resp_HistoryCapacity_PD425 [] = 
{
	"Cantidad total de registros de cierre Z",
	"Registros de cierre Z utilizados"
};

char *Resp_OpenDNFH_PD425 [] = 
{
	"N�mero del DNFH reci�n emitido"
};

char *Resp_CloseDNFH_PD425 [] = 
{
	"N�mero del DNFH reci�n emitido"
};

char *Resp_GetInitData_PD425 [] = 
{
	"N�mero de CUIT",
	"Nombre o raz�n social",
	"C�digo de registro",
	"Fecha de inicializaci�n",
	"N�mero de POS",
	"Fecha de Inicio de Actividades",
	"Ingresos Brutos",
	"Responsabilidad frente al IVA"
};

char *Resp_GetFantasyName_PD425 [] =
{
	"Texto de L�nea"
};

char *Resp_GetHeaderTrailer_PD425 [] =
{
	"Texto de L�nea"
};

char *Resp_GetRemitNumLine_PD425 [] =
{
	"Texto de L�nea"
};

char *Resp_GetConfigData_PD425 [] = 
{
	"L�mite para consumidor final sin document.",
	"L�mite para ticket factura A",
	"Porcentaje de IVA No Inscripto",
	"N�mero de copias de documentos",
	"Calificador de impresi�n de 'CAMBIO $0.00",
	"Calificador de impresi�n de leyendas opcionales",
	"Calificador de tipo de corte de papel"
};

char *Resp_GetConfigFull_PD425 [] = 
{
	"L�mite para consumidor final sin document.",
	"L�mite para ticket factura A",
	"Porcentaje de IVA No Inscripto",
	"N�mero de copias de documentos",
	"Calificador de impresi�n de 'CAMBIO $0.00",
	"Calificador de impresi�n de leyendas opcionales",
	"Calificador de tipo de corte de papel",
	"Calificador de impresi�n de marco",
	"Calif. de re-impresi�n por corte de energ�a",
	"Descripci�n del Medio de Pago para Saldo",
	"Sonido",
	"Alto de la hoja",
	"Ancho de la hoja",
	"Estacion de impresi�n del reporte X/Z",
	"Modo de impresi�n"
};

char *Resp_GetDateTime_PD425 [] =
{
	"Fecha",
	"Hora"
};

char *Resp_StatusRequest_PD425 [] =
{
	"N�mero de �ltimo documento B/C",
	"Estado auxiliar del controlador fiscal",
	"N�mero de �ltimo documento A",
	"Estado de documento",
	"N�mero de �ltima nota de cr�dito B/C",
	"N�mero de �ltima nota de cr�dito A",
	"N�mero de �ltimo remito"
};

char *Resp_SendIva_PD425 [] =
{
	"N�mero de registro",
	"Alicuota IVA",
	"Monto acumulado de IVA / Percepciones",
	"Monto acumulado de II (para reg 1/3)",
	"Monto acumulado de IVA No Insc. (para reg 1/3)",
	"Monto acumulado de venta neta (BI, para reg 1/3 )"
};

char *Resp_Copy_PD425 [] = 
{
	"N�mero de copia del documento"
};

// *********************************************************************
// ****************** Lista de comandos implementados ******************
// *********************************************************************

COMMANDSET CommandSet_PD425[] =
{
	{ '1', 
	CMD_STATUS_REQUEST, 		
	"Status Fiscal", NULL, NULL, Resp_StatusRequest_PD425 },

	{ '2', 
	CMD_OPEN_DF, 			
	"Apertura de Documento Fiscal", Open_Df_PD425, NULL, Resp_OpenDF_PD425 },

	{ '3', 
	CMD_PRINT_FISCAL_TEXT, 	
	"Impresi�n de Texto Fiscal", Print_Fiscal_Text_PD425, NULL, NULL },

	{ '4', 
	CMD_PRINT_LINE_ITEM, 	
	"Impresi�n de Item", Print_Line_Item_PD425, NULL, NULL },

 	{ '5', 
	CMD_LAST_ITEM_DISCOUNT, 	
	"Operaci�n sobre �ltimo Item", Last_Item_Discount_PD425, 	NULL, NULL },

	{ '6', 
	CMD_RETURN_RECHARGE, 	
	"Bonific/Recargo/Envases", Return_Recharge_PD425, NULL, NULL	},

	{ '7', 
	CMD_GENERAL_DISCOUNT, 	
	"Recargo � Descuento General",  General_Discount_PD425, NULL, NULL },

	{ '8', 
	CMD_PERCEPTIONS,			
	"Percepciones", Perceptions_PD425, NULL, NULL },

	{ '9', 
	CMD_CHARGE_NON_REG_TAX,  
	"Carga IVA No Inscripto", Charge_Non_Reg_Tax_PD425, NULL, NULL },

	{ 'a', 
	CMD_SUBTOTAL, 			
	"Subtotal  ", Subtotal_PD425, NULL, Resp_Subtotal_PD425 },

	{ 'b', 
	CMD_TOTAL_TENDER,		
	"Pago", Total_Tender_PD425, NULL, Resp_TotalTender_PD425 },

	{ 'c', 
	CMD_CLOSE_DF,			
	"Cierre de Documento Fiscal", Close_Df_PD425, NULL, Resp_CloseDF_PD425 },

	{ 'd', 
	CMD_OPEN_DNF_TICKET,			
	"Apertura de Documento NO Fiscal / SLIP", NULL, NULL, NULL },

	{ 'e', 
	CMD_PRINT_NON_FISCAL_TEXT,
	"Impresi�n Texto NO Fiscal", Print_Non_Fiscal_Text_PD425, NULL, NULL },

	{ 'f', 
	CMD_CLOSE_DNF,			
	"Cierre de Documento NO Fiscal", Close_DNF_PD425, NULL, NULL },

	{ 'g', 
	CMD_DAILY_CLOSE,			
	"Cierre Diario Z", NULL, szSEP "Z", Resp_DailyClose_PD425 },

	{ 'h', 
	CMD_DAILY_CLOSE,			
	"Cierre Diario X", NULL, szSEP "X", Resp_DailyClose_PD425 },

	{ 'i', 
	CMD_DAILY_CLOSE_BY_DATE,	
	"Reporte Diario por Fecha",	Daily_Close_By_Date_PD425, szSEP "D", NULL },

	{ 'j', 
	CMD_DAILY_CLOSE_BY_Z_NUM,
	"Reporte Diario por Z",	Daily_Close_By_Z_Num_PD425, szSEP "D", NULL },

	{ 'k', 
	CMD_DAILY_CLOSE_BY_DATE,	
	"Reporte Global por Rango de Fechas", Daily_Close_By_Date_PD425, szSEP "T", NULL },

	{ 'l', 
	CMD_DAILY_CLOSE_BY_Z_NUM,
	"Reporte Global por Z", Daily_Close_By_Z_Num_PD425, szSEP "T", NULL },

	{ 'm', 
	CMD_GET_DAILY_REPORT,	
	"Leer Cierre Z", Get_Daily_Report_PD425, NULL, Resp_GetDailyReport_PD425 },

	{ 'n', 
	CMD_HISTORY_CAPACITY,	
	"Capacidad de Cierres Z", NULL, NULL, Resp_HistoryCapacity_PD425 },

	{ 'o', 
	CMD_OPEN_DNFH,			
	"Apertura de Documento NO Fiscal Homologado", Open_DNFH_PD425, NULL, Resp_OpenDNFH_PD425 },

	{ 'p', 
	CMD_ITEM_REMIT,			
	"Item Remito / Orden Salida", Item_Remito_PD425, NULL, NULL },

	{ 'q', 
	CMD_ITEM_SUMARY,			
	"Item Resumen Cuenta / Cargo Habitaci�n", Item_Sumary_PD425, NULL, NULL },

	{ 'r', 
	CMD_ITEM_QUOTATION,		
	"Item Cotizaci�n", Item_Quotation_PD425, NULL, NULL },

	{ 's', 
	CMD_CLOSE_DNFH,			
	"Cierre Documento NO Fiscal Homologado", Close_DNFH_PD425, NULL, Resp_CloseDNFH_PD425 },

	{ 't', 
	CMD_SET_LOGO_CUSTOM,		
	"Carga Logotipo Cliente", Set_Logo_Custom_PD425, NULL, NULL },

	{ 'u', 
	CMD_RES_LOGO_CUSTOM,		
	"Reset Logotipo Cliente", NULL, NULL, NULL },

	{ 'v', 
	CMD_SET_CUSTOMER_DATA,	
	"Carga de datos del cliente", Set_Customer_Data_PD425, NULL, NULL },

	{ 'w', 
	CMD_SET_FANTASY_NAME,	
	"Programar L�nea Nombre de Fantas�a", Set_Fantasy_Name_PD425, NULL, NULL },

	{ 'x', 
	CMD_SET_HEADER_TRAILER,	
	"Programar L�nea de Encabezado � Cierre ", Set_Header_Trailer_PD425, NULL, NULL },

	{ 'y', 
	CMD_SET_REMIT_NUM_LINE,	
	"Carga Informaci�n L�neas de Remito", SetRemitNumLine_PD425, NULL, NULL },

	{ 'z', 
	CMD_SET_BAR_CODE,		
	"Generar C�digo de Barras", Set_Bar_Code_PD425, NULL, NULL },

	{ 'A', 
	CMD_CONFIG_CF_BY_BLOCK,	
	"Config. de Controlador Fiscal por Bloque", Config_Cf_By_Block_PD425, NULL, NULL },

	{ 'B', 
	CMD_SET_CONFIG_FULL,		
	"Carga Configuraci�n General Completa", Set_Config_Full_PD425, NULL, NULL },

	{ 'C', 
	CMD_CONFIG_CF_BY_ONE,	
	"Configuraci�n Individual", Config_Cf_By_One_PD425, NULL, NULL },

	{ 'D', 
	CMD_GET_FANTASY_NAME,	
	"Reporte Informaci�n L�neas de Fantas�a", Get_Fantasy_Name_PD425, NULL, Resp_GetFantasyName_PD425 },

	{ 'E', 
	CMD_GET_HEADER_TRAILER,	
	"Leer L�nea de Encabezado � Cierre", Get_Header_Trailer_PD425, NULL, Resp_GetHeaderTrailer_PD425 },

	{ 'F', 
	CMD_GET_REMIT_NUM_LINE,	
	"Reporte Informaci�n L�neas N�mero de Remito", GetRemitNumLine_PD425, NULL, Resp_GetRemitNumLine_PD425 },

	{ 'G', 
	CMD_GET_CONFIG_DATA,		
	"Leer Configuraci�n de Controlador Fiscal", NULL, NULL, Resp_GetConfigData_PD425 },

	{ 'H', 
	CMD_GET_CONFIG_FULL,		
	"Reporte Configuraci�n General Completa", NULL, NULL, Resp_GetConfigFull_PD425 },

	{ 'I', 
	CMD_SET_DATE_TIME,		
	"Cambio de Fecha y Hora", Set_Date_Time_PD425, NULL, NULL },

	{ 'J', 
	CMD_GET_DATE_TIME,		
	"Leer Fecha y Hora", NULL, NULL, Resp_GetDateTime_PD425 },

	{ 'K', 
	CMD_CHANGE_IVA_RESP,		
	"Cambio Responsabilidad IVA", Change_Iva_Resp_PD425, NULL, NULL },

	{ 'L', 
	CMD_SET_RECEIPT_INFO,	
	"Carga L�neas de Recibo", Set_Receipt_Info_PD425, NULL, NULL },

	{ 'M', 
	CMD_GET_WORKING_MEMORY,	
	"Leer Memoria de Trabajo", NULL, NULL, Resp_GetWorkingMemory_PD425 },

	{ 'N', 
	CMD_SEND_FIRST_IVA_INFO,	
	"Comenzar Env�o de Informaci�n de IVA", NULL, NULL, Resp_SendIva_PD425 },

	{ 'O', 
	CMD_SEND_NEXT_IVA_INFO,	
	"Env�o de Siguiente Informaci�n de IVA", NULL, NULL, Resp_SendIva_PD425 },

	{ 'P', 
	CMD_CANCEL,				
	"Cancelaci�n General", NULL, NULL, NULL },

	{ 'Q', 
	CMD_COPIES,				
	"Copia de Documento", NULL, NULL, Resp_Copy_PD425 },

	{ 'V', 
	CMD_STATPRN,				
	"Envia Encuesta (STATPRN)", NULL, NULL, NULL },

	{ 'X', 
	CMD_GET_INIT_DATA,		
	"Leer Datos de Inicializaci�n", NULL, NULL, Resp_GetInitData_PD425 },

	{'+',
	CMD_GET_CF_VERSION,
	"Leer Versi�n del Controlador", NULL, NULL, NULL },

	{'@',
	CMD_CHANGE_INGBR,
	"Cambio c�digo de Ingresos Brutos", ChangeIngBrutos_PD425, NULL, NULL },

	{'(',
	CMD_SET_VOUCH_DATA_1,
	"Datos (1) del Voucher de Tarjeta de Cr�dito", SetVoucher1_PD425, NULL, NULL },
	
	{')',
	CMD_SET_VOUCH_DATA_2,
	"Datos (2) del Voucher de Tarjeta de Cr�dito", SetVoucher2_PD425, NULL, NULL },

	{'%',
	CMD_PRINT_VOUCH,
	"Imprimir Voucher", PrintVoucher_PD425, NULL, NULL },
	
	{ ANY, 0, "", NULL, NULL, NULL }
};	

// *********************************************************************
// ***** Significado del campo auxiliar del comando status fiscal  *****
// *********************************************************************

// El status auxiliar indica el estado del parser del controlador fiscal. 
// Seg�n el valor del nibble menos significativo, considerado en formato 
// decimal, el controlador se encuentra en uno de los siguientes estados:

STATAUX_LOW StAuxLow_PD425 [] = 
{
	0,	"Memoria fiscal no formateada",
	1,	"Memoria fiscal no inicializada",
	2,	"No hay ning�n comprobante abierto",
	3,	"Un comprobante fiscal se encuentra abierto.\nLa venta se encuentra habilitada",
	4,	"Comprobante fiscal abierto.\nSe acaba de imprimir un texto fiscal",
	5,	"Un comprobante no fiscal se encuentra abierto",
	6,	"Comprobante fiscal abierto.\nSe realiz� al menos un pago",
	7,	"Comprobante fiscal abierto.\nSe sald� el monto",
	8,	"Comprobante fiscal abierto.\nSe ha emitido el comando de percepciones",
	9,	"Memoria dada de baja o en espera de dar de baja",
	10,	"Comprobante fiscal abierto.\nSe realiz� un descuento / recargo general",
	11,	"Comprobante fiscal abierto.\nSe realiz� una bonificaci�n / recargo / devoluci�n de envases",
	12,	"Recibo fiscal abierto.\nSe acaba de imprimir una l�nea con el concepto del recibo",
	13,	"Nota de Cr�dito o Recibo X abierto.\nSe puede hacer un cr�dito o una venta",
	14,	"Nota de cr�dito o Recibo X abierto.\nSe realiz� un descuento / recargo general",
	15,	"Nota de cr�dito o Recibo X abierto.\nSe realiz� una bonificaci�n / recargo / devoluci�n de envases",
	16,	"Nota de cr�dito o Recibo X abierto.\nSe ha emitido el comando de percepciones",
	17,	"Nota de cr�dito o Recibo X abierto.\nSe acaba de escribir una l�nea de texto",
	18,	"Recibo X abierto.\nSe acaba de imprimir una l�nea con el concepto del recibo",
	19,	"Una cotizaci�n se encuentra abierta",
	20,	"Un remito / orden de salida se encuentra abierto",
	21,	"Un resumen de cuenta / cargo a la habitaci�n se encuentra abierto",
	22, "Controlador Fiscal Bloqueado",
	-1, NULL,
};

// Adem�s, seg�n el valor del nibble m�s significativo, 
// considerado en formato decimal, 
// el controlador se encuentra en uno de los siguientes estados:
// 
// Valor Decimal	Estado
// 	
// 2				Datos del comprador almacenados.
// 4				C�digo de barras almacenado en memoria de trabajo.
// 8				Operando en modo entrenamiento.
// 
// La combinaci�n de los estados se indica mediante la suma de los respectivos valores decimales. 
// Por ejemplo, el valor c (es decir, 4 + 8) indica que el controldor se encuentra en modo 
// entrenamiento y que hay un c�digo de barras almacenado.

STATAUX_HIGH StAuxHigh_PD425 [] = 
{
	0x8000,	"Operando en modo entrenamiento", 
	0x4000,	"C�digo de barras almacenado en memoria de trabajo",
	0x2000,	"Datos del comprador almacenados",
	0x0000, NULL
};

// Tipo de documento abierto (estado del documento):

STDOC StDoc_PD425 [] =
{
	0x01,		"Factura A",
	0x02,		"Factura B",
	0x03,		"Factura C",
	0x04,		"Nota de d�bito A",
	0x05,		"Nota de d�bito B",
	0x06,		"Nota de d�bito C",
	0x07,		"Recibo A",
	0x08,		"Recibo B",
	0x09,		"Recibo C",
	0x20,		"Documento no fiscal",
	0x40,		"Nota de cr�dito A",
	0x41,		"Nota de cr�dito B",
	0x42,		"Nota de cr�dito C",
	0x43,		"Remito",
	0x44,		"Recibo de uso interno (X)",
	0x45,		"Orden de salida",
	0x46,		"Resumen de cuenta",
	0x47,		"Cargo a la habitaci�n",
	0x48,		"Cotizaci�n",
	0x00,		NULL		
};		
