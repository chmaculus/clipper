/*
actions.c
*/

#if defined (UNIX) || defined (LINUX)
#include <unistd.h>
#include <curses.h>
#endif 

#ifdef UNIX 
#include <prototypes.h>
#endif

#ifdef DOS
#include <conio.h>
#endif 

#include <ctype.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <setjmp.h>

#include "ascii.h"
#include "testf.h"

extern int Version;

int ActionProgText 	(char *Buffer);
int ActionText 		(char *Buffer);

// CONFIGURACION INDIVIDUAL

// Ingreso de datos para la configuracion individual. 
// En este caso se resuelve todo en esta rutina de accion, dado
// que para una determinada configuracion, solo se muestra el 
// parametro de esa configuracion. Si se hace como los demas 
// comandos, se muestra una cantidad de parametros que nada 
// tienen que ver con la configuracion seleccionada.

int
ActionConfigIndiv_320 (char *Buffer)
{
	#define MAX_PARAMS_320 8

	int len;
	int i, c;
	char szPar[500];
	char *Ans;

	char *Par1[MAX_PARAMS_320] = 
	{
		"1 - Impresi�n de CAMBIO $0.00\n",
		"2 - Impresi�n de leyendas opcionales\n",
		"3 - Corte de Papel\n",
		"4 - Impresi�n de marco\n",
		"5 - Re-Impresi�n de documentos cancelados\n",
		"6 - N�mero de copias de documento\n",
		"7 - Descripci�n de pago para saldo\n",
		"8 - Sonido : " 
	};

	char ValPar1[MAX_PARAMS_320] = {'4', '5', '6', '7', '8', '9', ':', ';'};
		
	char *Par2[MAX_PARAMS_320] = 
	{
		"'P' ... Imprime; Otros NO Imprime",
		"'P' ... Imprime; Otros NO Imprime",
		
		"'F' ... Corte Total\n"
		"'P' ... Parcial\n"
		"'N' ... No corta",
		
		"'P' ... Imprime; Otros NO Imprime",
		"'P' ... Re-Imprime Doc Cancelados; Otros NO Re-Impr.",
		
		"'0' ... No permite\n"
		"'1' ... Original  \n"
		"'2' ... Duplicado \n"
		"'3' ... Triplic   \n"
		"'4' ... Cuadruplicado",
		
		"Descripci�n de hasta 80 caracteres",
		
		"'P' ... Habilita Sonido; Otros No habilita",
	};

	ShowLine ("\nSeleccione la configuraci�n a modificar :\n");

	for ( i = 0; i < MAX_PARAMS_320; i ++ )
		ShowLine ("%s", Par1[i]);
	
	while ( 1 ) 
	{
		c = atoi (Ask ("", &len, FALSE));
		
		if ( c >= 1 && c <= MAX_PARAMS_320 )
			break;
	}
	
	*Buffer ++ = ValPar1[c - 1];
	*Buffer ++ = SEP;
	
	sprintf (szPar, "Par�metro de la configuraci�n : \n%s : ", Par2[c - 1]);
	
	Ans = Ask (szPar, &len, TRUE);
	
	ShowLine ("\n");
	
	strncat (Buffer, Ans, len);
	
	return len + 2;	// Cantidad de bytes agregados.	
}

int
ActionConfigIndiv_321 (char *Buffer)
{
	#define MAX_PARAMS_321 9

	int len;
	int i, c;
	char szPar[500];
	char *Ans;

	char *Par1[MAX_PARAMS_321] = 
	{
		"1 - Impresi�n de CAMBIO $0.00\n",
		"2 - Impresi�n de leyendas opcionales\n",
		"3 - Corte de Papel\n",
		"4 - Impresi�n de marco\n",
		"5 - Re-Impresi�n de documentos cancelados\n",
		"6 - N�mero de copias de documento\n",
		"7 - Descripci�n de pago para saldo\n",
		"8 - Sonido\n",
		"9 - Alto de la hoja : "
	};

	char ValPar1[MAX_PARAMS_321] = {'4', '5', '6', '7', '8', '9', ':', ';', '<'};
		
	char *Par2[MAX_PARAMS_321] = 
	{
		"'P' ... Imprime; Otros NO Imprime",
		"'P' ... Imprime; Otros NO Imprime",
		
		"'F' ... Corte Total\n"
		"'P' ... Parcial\n"
		"'N' ... No corta",
		
		"'P' ... Imprime; Otros NO Imprime",
		"'P' ... Re-Imprime Doc Cancelados; Otros NO Re-Impr.",
		
		"'0' ... No permite\n"
		"'1' ... Original  \n"
		"'2' ... Duplicado \n"
		"'3' ... Triplic   \n"
		"'4' ... Cuadruplicado",
		
		"Descripci�n de hasta 80 caracteres",
		
		"'P' ... Habilita Sonido; Otros No habilita",
		
		"'M' ... Reducido\n"
		"'A' ... A4"
	};

	ShowLine ("\nSeleccione la configuraci�n a modificar :\n");

	for ( i = 0; i < MAX_PARAMS_321; i ++ )
		ShowLine ("%s", Par1[i]);

	while ( 1 ) 
	{
		c = atoi (Ask ("", &len, FALSE));
		
		if ( c >= 1 && c <= MAX_PARAMS_321 )
			break;
	}
	
	*Buffer ++ = ValPar1[c - 1];
	*Buffer ++ = SEP;
	
	sprintf (szPar, "Par�metro de la configuraci�n : \n%s : ", Par2[c - 1]);
	
	Ans = Ask (szPar, &len, TRUE);
	
	ShowLine ("\n");
	
	strncat (Buffer, Ans, len);
	
	return len + 2;	// Cantidad de bytes agregados.	
}

int
ActionConfigIndiv (char *Buffer)
{
	if ( Version == VER_PRN321 )
		return ActionConfigIndiv_321 (Buffer);

	return ActionConfigIndiv_320 (Buffer);
}

int
ActionConfigIndiv_PD425 (char *Buffer)
{
	#define MAX_PARAMS_PD425 12

	int len;
	int i, c;
	char szPar[500];
	char *Ans;

	char *Par1[MAX_PARAMS_PD425] = 
	{
		"1 -  Impresi�n de CAMBIO $0.00\n",
		"2 -  Impresi�n de leyendas opcionales\n",
		"3 -  Corte de Papel\n",
		"4 -  Impresi�n de marco\n",
		"5 -  Re-Impresi�n de documentos cancelados\n",
		"6 -  N�mero de copias de documento\n",
		"7 -  Descripci�n de pago para saldo\n",
		"8 -  Sonido\n",
		"9 -  Alto de la hoja\n",
		"10 - Ancho de la hoja\n",
		"11 - Estaci�n de impresi�n del reporte X/Z\n",
		"12 - Modo de impresi�n : "
	};

	char ValPar1[MAX_PARAMS_PD425] = 
	{
		'4', '5', '6', '7', '8', '9', ':', ';', '<', '=', '>', '?'
	};
		
	char *Par2[MAX_PARAMS_PD425] = 
	{
		"'P' ... Imprime; Otros NO Imprime",
		"'P' ... Imprime; Otros NO Imprime",
		
		"'F' ... Corte Total\n"
		"'P' ... Parcial\n"
		"'N' ... No corta",
		
		"'P' ... Imprime; Otros NO Imprime",
		"'P' ... Re-Imprime Doc Cancelados; Otros NO Re-Impr.",
		
		"'0' ... No permite\n"
		"'1' ... Original  \n"
		"'2' ... Duplicado \n"
		"'3' ... Triplic   \n"
		"'4' ... Cuadruplicado",
		
		"Descripci�n de hasta 80 caracteres",
		
		"'P' ... Habilita Sonido; Otros No habilita",
		
		"'M' .... Reducido\n"
		"'A' .... A4\n"
		"'O' .... Oficio",

		"'M' .... Reducido\n"
		"'N' .... Normal",
	
		"'T' .... Ticket\n"
		"'S' .... Slip",
	
		"'M' .... Ticket + Tractor\n"
		"'A' .... Tractor",
	};

	ShowLine ("\nSeleccione la configuraci�n a modificar :\n");

	for ( i = 0; i < MAX_PARAMS_PD425; i ++ )
		ShowLine ("%s", Par1[i]);
	
	while ( 1 ) 
	{
		c = atoi (Ask ("", &len, FALSE));
		
		if ( c >= 1 && c <= MAX_PARAMS_PD425 )
			break;
	}
	
	*Buffer ++ = ValPar1[c - 1];
	*Buffer ++ = SEP;
	
	sprintf (szPar, "Par�metro de la configuraci�n : \n%s : ", Par2[c - 1]);
	
	Ans = Ask (szPar, &len, TRUE);
	
	ShowLine ("\n");
	
	strncat (Buffer, Ans, len);
	
	return len + 2;	// Cantidad de bytes agregados.	
}

// Rutina de accion para el ingreso de texto en lineas de 
// header/trailer y lineas de fantasia. Permiten imprimir 
// en doble ancho y borrar lineas programadas.

int 
ActionProgText (char *Buffer)
{
	int len;
	char *Ans;
#if 0
	char *Msg = "\nPresione ...\n"
	            "'d' para realizar la impresi�n en doble ancho o 'b',\n"
				"para borrar una l�nea ya programada.\n"
				"Otra tecla para continuar ... : ";
#endif
	char *Msg = "\nPresione ...\n"
	            "   'd' para realizar la impresi�n en doble ancho\n"
				"   'b' para borrar una l�nea ya programada.\n"
				"Otra tecla, para continuar con el siguiente campo ... : ";
	
	Ans = Ask (Msg, &len, TRUE);

	ShowLine ("\n");
	
	if ( len == 0 )
		return 0;
		
	switch (tolower (*Ans))
	{
		case 'd':
			*Buffer = COD_DOBLE_ANCHO;
			return 1;
			
		case 'b':
			*Buffer = COD_BORRAR_LINEA;
			return 1;
	}

	return 0;
}

// Rutina de accion para el ingreso de texto en comandos 
// de texto fiscal y no fiscal. Permiten imprimir en doble ancho.

int 
ActionText (char *Buffer)
{
	int len;
	char *Ans;
	
	Ans = Ask ("Desea Imprimir el Texto en doble ancho ? (s/n) ", &len, TRUE);

	//ShowLine ("\n");
		
	if ( *Ans == 's' )
	{
		// Caracter de control para que se imprima en D. Ancho
		*Buffer = COD_DOBLE_ANCHO;	
		return 1;
	}
	
	return 0;
}


