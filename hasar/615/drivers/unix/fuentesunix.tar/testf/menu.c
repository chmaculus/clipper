/*
menu.c
*/

#ifdef TARGET_TESTF
#define VER_FULL
#endif

#ifdef UNIX 
#include <prototypes.h>
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>

#if defined (UNIX) || defined (LINUX)
#include <unistd.h>
#include <curses.h>
extern WINDOW *W;
#endif 

#ifdef DOS
#include <conio.h>
#endif

#include "menu.h"
#include "testf.h"
#include "ascii.h"

extern int  Version;
extern long BaudRate;

void
PrintMenu (int Page, int NPages)
{
	char **str;
	char *prn;

	ClearScreen ();

    switch (Version)
    {
		case VER_PRN_614_950_262:
            str = Comandos_PR4 [Page - 1];
			prn = PRN_614;
            break;

		case VER_PRN_615_951_PR4:
            str = Comandos_PR4 [Page - 1];
			prn = PRN_615;
            break;

        case VER_ARTJET:
            str = Comandos_Artjet [Page - 1];
			prn = PRN_PJ20;
            break;
			
        case VER_PRN320:
            str = Comandos_Artjet [Page - 1];
			prn = PRN_320;
            break;			

        case VER_PRN321:
            str = Comandos_Artjet [Page - 1];
			prn = PRN_321;
            break;			

		case VER_NCR:
			str = Comandos_Artjet [Page - 1];
			prn = PRN_NCR;
			break;

		case VER_CHILE:
			
			// Pongo la pagina 1, si me paso de pagina
			
			if ( Page > MAX_PAGES_CHILE )
				Page = 1;
				
			str = Comandos_Chile [Page - 1];
			prn = PRN_CHILE;
			
			break;

		case VER_PRN425:
			str = Comandos_PD425 [Page - 1];
			prn = PRN_425;
			break;

		case VER_OKIPAGE:
			str = Comandos_Artjet [Page - 1];
			prn = PRN_PL8F;
			break;
    }

	ShowLine (*str++, BaudRate, Page, NPages, prn);
	
	while (*str)
		ShowLine (*str++);

	#if defined (UNIX) || defined (LINUX)
		wmove (W, 24, 1);
	#else
		gotoxy (1,24);
	#endif

	ShowLine ("Comando: ");
}

int 
GetNPages (void)
{
	int NPages;
	
	switch (Version)
	{	
		case VER_PRN425:
			NPages = MAX_PAGES_PD425;
			break;
			
		case VER_ARTJET:
		case VER_PRN320:
		case VER_PRN321:
		case VER_NCR:
		case VER_OKIPAGE:
			NPages = MAX_PAGES_ARTJET;
			break;

		case VER_PRN_614_950_262:
		case VER_PRN_615_951_PR4:
			NPages = MAX_PAGES_PR4;			
			break;

		case VER_CHILE:
			NPages = MAX_PAGES_CHILE;
			break;
	}

	return NPages;
}
