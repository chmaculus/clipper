/*
menu.h
*/

// Version 3.01 	Fecha : 04/01/2001
// Agrega la deteccion de los impresores PD425, Okipage 8p,
// y Artjet. Asimismo se agregaron comandos especificos al PD425. 
// Por otro lado, se modifico en todos los impresores basados en 
// el cf386, el formateo del campo de razon social e ingresos brutos 
// del comando de inicializacion. Este formateo era necesario en el
// PR4, pero no en la linea basada en el cf386.

// Version 3.10     Fecha : 07/03/2001
// Agrega la deteccion del impresor 321F, y la modificacion a los 
// comandos de 320 que fueron modificados en la implementacion 
// (GetConfigFull, SetConfigFull, PrintLineItem, ItemRemito, ConfigIndiv.)
// El comando de modificacion de ingresos brutos no se permite 
// en el impresor 320.

#define VERSION "V3.10"

#include "pages.h"

#ifdef VER_FULL
#define MenuHEADER \
	"TESTF " VERSION " - %6ld Baudios            P�gina %d/%d    Imp: %s\n"
#else
#define MenuHEADER \
	"PRUF " VERSION " - %6ld Baudios            P�gina %d/%d    Imp: %s\n"
#endif

// ************************************************************************
// Impresor Artjet PJ20 / Okidata - 320 
// ************************************************************************

char *ArtJet_Pag1 [] =
{
MenuHEADER,
"Probador de Controladores Fiscales      PGDWN - Sig\n",
"\n",
"* Documentos Fiscales                   * Documentos de Auditoria\n",
" 1 - Status Fiscal                       g - Cierre Diario 'Z'\n",
" 2 - Abrir Documento Fiscal              h - Cierre Diario 'X'\n",
" 3 - Texto Fiscal                        i - Reporte Diario por Rango de Fechas\n",
" 4 - Venta de Item                       j - Reporte Diario por Rango de Z\n",
" 5 - Descuento/Recargo Ultimo Item       k - Reporte Global por Rango de Fechas\n",
" 6 - Bonif/Recargo/Envases               l - Reporte Global por Rango de Z\n",
" 7 - Descuento/Recargo General           m - Reporte Cierre Z individual\n",
" 8 - Percepciones                        n - Reporte Estado Cierres Diarios Z\n",
" 9 - Carga IVA No Inscripto\n",
" a - Subtotal\n",
" b - Pago\n",
" c - Cierre Documento Fiscal            * Documentos NO Fiscales Homologados\n",
"                                         o - Apertura DNFH\n",
"* Documentos NO Fiscales                 p - Item Remito / Orden Salida\n",
" d - Abrir DNF / SLIP                    q - Item Resumen Cuenta / Cargo Hab.\n",
" e - Impresi�n Texto NO Fiscal           r - Item Cotizaci�n\n",
" f - Cierre DNF                          s - Cierre DNFH\n",
NULL
};

char *ArtJet_Pag2 [] =
{
MenuHEADER,
"Probador de Controladores Fiscales      PGUP - Prev / PGDWN - Sig\n",
"\n",
"* Comandos de Configuraci�n             * Comandos Adicionales\n",
" t - Carga Logotipo                      L - Carga L�neas Texto Recibo\n",
" u - Reset Logotipo                      M - Leer  Estado Memoria de Trabajo\n",
" v - Carga Datos de Cliente              N - Inicio Reporte Informaci�n IVA\n",
" w - Carga Inform. L�neas de Fantas�a    O - Resto  Reporte Informaci�n IVA\n",
" x - Carga l�nea Header/Trailer          P - Cancelaci�n General\n",
" y - Carga Inform. L�neas N�mero Remito  Q - Copia de Documentos\n",
" z - Carga C�digo de Barras\n",
" A - Carga Configur. General Original\n",
" B - Carga Configur. General Completa\n",
" C - Carga Configur. Individual\n",
" D - Leer  Inform. L�neas de Fantas�a\n",
" E - Leer  l�nea Header/Trailer\n",
" F - Leer  Inform. L�neas N�mero Remito\n",
" G - Leer  Configur. General Original\n",
" H - Leer  Configur. General Completa\n",
" I - Cambio Fecha y Hora\n",
" J - Leer Fecha y Hora\n",
" K - Cambio Responsab. frente al IVA     @ - Cambio c�digo de Ing. Brutos\n",
NULL
};

char *ArtJet_Pag3 [] =
{
MenuHEADER,
"Probador de Controladores Fiscales      PGUP - Prev\n",
"\n",
"* Comandos Internos\n",
" / - Cambio de Velocidad\n",
" + - Versi�n del Controlador\n",
" $ - Repite �ltimo comando\n",
" # - Set de comandos del impresor\n",
" R - Programar Secuencia\n",
" S - Fin/Ejecuci�n Secuencia\n",
"\n",
"* Mantenimiento\n",
" T - Enviar ACK\n",
" U - Protocolo Nuevo\n",
" V - STATPRN\n",
"\n",
"* Comandos de F�brica\n",
#ifdef VER_FULL
" ! - Baja Controlador Fiscal\n",
#endif 
" X - Leer Datos Inicializaci�n\n",
NULL
};			 

char **Comandos_Artjet[] = 
{
    ArtJet_Pag1,
    ArtJet_Pag2,
    ArtJet_Pag3,
};

#define MAX_PAGES_ARTJET \
	(sizeof (Comandos_Artjet) / sizeof (Comandos_Artjet[0]))
			 
// ************************************************************************
// Impresor 614/615/950/951/262/PR4
// ************************************************************************

char *PR4_Pag1 [] =
{
MenuHEADER,
"Probador de Controladores Fiscales      PGDWN - Sig\n",
"\n",
"* Documentos Fiscales                   * Documentos de Auditoria\n",
" 1 - Status Fiscal                       g - Cierre Diario 'Z'\n",
" 2 - Abrir Documento Fiscal              h - Cierre Diario 'X'\n",
" 3 - Texto Fiscal                        i - Reporte Diario por Rango de Fechas\n",
" 4 - Venta de Item                       j - Reporte Diario por Rango de Z\n",
" 5 - Descuento/Recargo Ultimo Item       k - Reporte Global por Rango de Fechas\n",
" 6 - Bonif/Recargo/Envases               l - Reporte Global por Rango de Z\n",
" 7 - Descuento/Recargo General           m - Reporte Cierre Z individual\n",
" 8 - Percepciones                        n - Reporte Estado Cierres Diarios Z\n",
" 9 - Carga IVA No Inscripto\n",
" a - Subtotal                          * Documentos NO Fiscales Homologados\n",
" b - Pago                                o - DNFH Farmacias\n",
" c - Cierre Documento Fiscal             p - DNFH Reparto\n",
"\n",
"* Documentos NO Fiscales               * Documentos NO Fiscales en SLIP\n",
" d - Abrir DNF                           q - Abrir DNF en Slip\n",
" e - Impresi�n Texto NO Fiscal\n",
" f - Cierre DNF\n",
NULL
};

char *PR4_Pag2 [] =
{
MenuHEADER,
"Probador de Controladores Fiscales      PGUP - Prev / PGDWN - Sig\n",
"\n",
"* Comandos de Configuraci�n             * Impresi�n de Voucher\n",
" r - Carga Datos de Cliente              F - Datos de Voucher 1\n",
" s - Carga Inform. L�neas de Fantas�a    G - Datos de Voucher 2\n",
" t - Carga l�nea Header/Trailer          H - Imprimir Voucher\n",
" u - Leer  l�nea Header/Trailer\n",
" v - Cambio Fecha y Hora                * Comandos Varios\n",
" w - Leer Fecha y Hora                   I - Apertura Caj�n\n",
#ifdef VER_FULL
" x - Cambio Responsab. frente al IVA     J - Mensaje a Display\n",
#else
"                                         J - Mensaje a Display\n",
#endif
" y - Carga Configuraci�n CF              K - Avance Receipt\n",
" z - Carga Configuraci�n CF Individual   L - Avance Journal\n",
" A - Carga C�digo de Barras              M - Avance Rec/Journ\n",
" B - Leer  Configuraci�n CF              N - Corte Papel DNF\n",
"\n",
"* Comandos Adicionales\n",
" C - Leer  Estado Memoria de Trabajo\n",
" D - Inicio Reporte Informaci�n IVA\n",
" E - Resto  Reporte Informaci�n IVA\n",
NULL
};  

char *PR4_Pag3 [] =
{
MenuHEADER,
"Probador de Controladores Fiscales      PGUP - Prev\n",
"\n",
"* Comandos Internos\n",
" $ - Repite �ltimo comando\n",
" # - Set de comandos del impresor\n",
" R - Programar Secuencia\n",
" S - Fin/Ejecuci�n Secuencia\n",
"\n",
"* Mantenimiento\n",
" T - Enviar ACK\n",
"\n",
"* Comandos de F�brica\n",
#ifdef VER_FULL
" W - Formateo de Memoria Fiscal\n",
#endif
" Y - Leer Datos Inicializaci�n\n",
#ifdef VER_FULL
" ! - Baja Controlador Fiscal\n",
#endif
NULL
};			 

char **Comandos_PR4 [] = 
{
    PR4_Pag1,
    PR4_Pag2,
    PR4_Pag3,
};

#define MAX_PAGES_PR4 \
	(sizeof (Comandos_PR4) / sizeof (Comandos_PR4[0]))

			 
// ************************************************************************
// Impresor fiscal para chile     
// ************************************************************************


char *Chile_Pag1 [] =
{
MenuHEADER,
"Probador de Controladores Fiscales\n",
"\n",
"* Documentos fiscales                   * Comandos adicionales\n",
" 1 - Status Fiscal                       b - Cortar Papel\n", 
" 2 - Abrir Documento Fiscal              c - Avanzar Papel\n", 
" 3 - Imprimir                            d - Abrir Caj�n\n", 
" 4 - Cerrar Documento Fiscal             e - Interlineado de Slip\n",
"\n",
"* Documentos no fiscales                * Comandos internos\n",
" 5 - Abrir Documento No Fiscal           $ - Repite �ltimo comando\n",
" 6 - Cerrar Documento No Fiscal          # - Set de comandos del impresor\n", 
"                                         R - Programar Secuencia\n", 
"* Documentos de auditor�a                S - Fin/Ejecuci�n Secuencia\n",
" 7 - Cierre Diario X\n",
" 8 - Cierre Diario Z\n",
"\n",
"* Comandos de f�brica\n"
" a - Baja de controlador fiscal\n",
NULL
};

char **Comandos_Chile [] = 
{
    Chile_Pag1
};

#define MAX_PAGES_CHILE \
	(sizeof (Comandos_Chile) / sizeof (Comandos_Chile[0]))

 
// ************************************************************************
// Impresor PD425
// ************************************************************************

char *PD425_Pag1 [] =
{
MenuHEADER,
"Probador de Controladores Fiscales      PGDWN - Sig\n",
"\n",
"* Documentos Fiscales                   * Documentos de Auditoria\n",
" 1 - Status Fiscal                       g - Cierre Diario 'Z'\n",
" 2 - Abrir Documento Fiscal              h - Cierre Diario 'X'\n",
" 3 - Texto Fiscal                        i - Reporte Diario por Rango de Fechas\n",
" 4 - Venta de Item                       j - Reporte Diario por Rango de Z\n",
" 5 - Descuento/Recargo Ultimo Item       k - Reporte Global por Rango de Fechas\n",
" 6 - Bonif/Recargo/Envases               l - Reporte Global por Rango de Z\n",
" 7 - Descuento/Recargo General           m - Reporte Cierre Z individual\n",
" 8 - Percepciones                        n - Reporte Estado Cierres Diarios Z\n",
" 9 - Carga IVA No Inscripto\n",
" a - Subtotal\n",
" b - Pago\n",
" c - Cierre Documento Fiscal            * Documentos NO Fiscales Homologados\n",
"                                         o - Apertura DNFH\n",
"* Documentos NO Fiscales                 p - Item Remito / Orden Salida\n",
" d - Abrir DNF / SLIP                    q - Item Resumen Cuenta / Cargo Hab.\n",
" e - Impresi�n Texto NO Fiscal           r - Item Cotizaci�n\n",
" f - Cierre DNF                          s - Cierre DNFH\n",
NULL
};

char *PD425_Pag2 [] =
{
MenuHEADER,
"Probador de Controladores Fiscales      PGUP - Prev / PGDWN - Sig\n",
"\n",
"* Comandos de Configuraci�n             * Comandos Adicionales\n",
" t - Carga Logotipo                      L - Carga L�neas Texto Recibo\n",
" u - Reset Logotipo                      M - Leer  Estado Memoria de Trabajo\n",
" v - Carga Datos de Cliente              N - Inicio Reporte Informaci�n IVA\n",
" w - Carga Inform. L�neas de Fantas�a    O - Resto  Reporte Informaci�n IVA\n",
" x - Carga l�nea Header/Trailer          P - Cancelaci�n General\n",
" y - Carga Inform. L�neas N�mero Remito  Q - Copia de Documentos\n",
" z - Carga C�digo de Barras\n",
" A - Carga Configur. General Original   * Impresi�n de Voucher\n",
" B - Carga Configur. General Completa    ( - Datos de Voucher 1\n",
" C - Carga Configur. Individual          ) - Datos de Voucher 2\n",
" D - Leer  Inform. L�neas de Fantas�a    % - Imprimir Voucher\n",
" E - Leer  l�nea Header/Trailer\n",
" F - Leer  Inform. L�neas N�mero Remito\n",
" G - Leer  Configur. General Original\n",
" H - Leer  Configur. General Completa\n",
" I - Cambio Fecha y Hora\n",
" J - Leer Fecha y Hora\n",
" K - Cambio Responsab. frente al IVA     @ - Cambio c�digo de Ing. Brutos\n",
NULL
};

char *PD425_Pag3 [] =
{
MenuHEADER,
"Probador de Controladores Fiscales      PGUP - Prev\n",
"\n",
"* Comandos Internos\n",
" / - Cambio de Velocidad\n",
" + - Versi�n del Controlador\n",
" $ - Repite �ltimo comando\n",
" # - Set de comandos del impresor\n",
" R - Programar Secuencia\n",
" S - Fin/Ejecuci�n Secuencia\n",
"\n",
"* Mantenimiento\n",
" T - Enviar ACK\n",
" U - Protocolo Nuevo\n",
" V - STATPRN\n",
"\n",
"* Comandos de F�brica\n",
#ifdef VER_FULL
" ! - Baja Controlador Fiscal\n",
#endif 
" X - Leer Datos Inicializaci�n\n",
NULL
};			 

char **Comandos_PD425[] = 
{
    PD425_Pag1,
    PD425_Pag2,
    PD425_Pag3,
};

#define MAX_PAGES_PD425 \
	(sizeof (Comandos_PD425) / sizeof (Comandos_PD425[0]))












