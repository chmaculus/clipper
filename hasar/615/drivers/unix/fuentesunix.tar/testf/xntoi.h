int xntoi (char *num, int len);

