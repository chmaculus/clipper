/*
chkerr.c
*/

#include <stdio.h>

#include "testf.h"

char *ErrFiscal_PR4[] =
{								              	/* Bit */
	"Memoria Fiscal da�ada",	              	/* 0   */
	"Memoria de trabajo no consistente",      	/* 1   */
	NULL,						              	/* 2   */
	"Comando no reconocido",		          	/* 3   */
	"Campo de datos invalido",		          	/* 4   */
	"Comando invalido para el estado fiscal", 	/* 5   */
	"Desborde de acumulador",			      	/* 6   */
	"Memoria fiscal llena",		              	/* 7   */
	"Memoria fiscal casi llena",	          	/* 8   */
	"Memoria Fiscal inicializada",            	/* 9   */
	NULL,            							/* 10  */
	"Error en reloj",			              	/* 11  */
	"Recibo abierto",		                  	/* 12  */
	"Recibo abierto en Ticket",				  	/* 13  */
	"Recibo abierto en Slip",				  	/* 14  */
};

char *ErrPrinter_PR4[] =
{								       			/*  Bit  */
	"Impresor Ocupado",				   			/*	0   */
	 NULL,						       			/*	1   */
	"Error Mec�nico de Impresor",	   			/*	2   */
	"Impresor Off-Line",			   			/*	3   */
	"Falta Papel Journal",		       			/*	4   */
	"Falta Papel Receipt",		       			/*	5   */
	"Buffer de impresi�n lleno",	   			/*	6   */
	"Buffer de impresi�n vac�o",	   			/*	7   */
	"Cobertura de Slip abierta",	   			/*	8   */
	"Papel presente en Slip",		   			/*	9   */
	"Cobertura de validaci�n abierta", 			/*	10  */
	"Papel presente en validaci�n",	   			/*	11  */
	NULL,						       			/*	12  */
	NULL,						       			/*	13  */
	NULL,						       			/*	14  */
};

char *ErrFiscal_PJ20[] =
{								              	/* Bit */
	"Memoria Fiscal da�ada",	              	/* 0   */
	"Memoria de trabajo no consistente",      	/* 1   */
	NULL,						              	/* 2   */
	"Comando no reconocido",		          	/* 3   */
	"Campo de datos invalido",		          	/* 4   */
	"Comando invalido para el estado fiscal", 	/* 5   */
	"Desborde de acumulador",			      	/* 6   */
	"Memoria fiscal llena",		              	/* 7   */
	"Memoria fiscal casi llena",	          	/* 8   */
	"Memoria Fiscal inicializada",            	/* 9   */
	NULL,            							/* 10  */
	"Error en reloj",			              	/* 11  */
	"Documento fiscal abierto",		            /* 12  */
	"Documento abierto",				  		/* 13  */
	"Comando extra sobre STATPRN",			  	/* 14  */
};

char *ErrPrinter_PJ20[] =
{								       			/*  Bit  */
	"Impresor Ocupado",				   			/*	0   */
	 NULL,						       			/*	1   */
	"Error Mec�nico de Impresor",	   			/*	2   */
	"Impresor Off-Line",			   			/*	3   */
	"Falta Papel Journal",		       			/*	4   */
	"Falta Papel Receipt",		       			/*	5   */
	"Buffer de impresi�n lleno",	   			/*	6   */
	"Buffer de impresi�n vac�o",	   			/*	7   */
	"Cobertura de Slip abierta",	   			/*	8   */
	"Papel presente en Slip",		   			/*	9   */
	"Cobertura de validaci�n abierta", 			/*	10  */
	"Papel presente en validaci�n",	   			/*	11  */
	NULL,						       			/*	12  */
	NULL,						       			/*	13  */
	NULL,						       			/*	14  */
};

char *ErrFiscal_Chile[] =
{								              	/* Bit */
	"Memoria Fiscal da�ada",	              	/* 0   */
	"Memoria de trabajo no consistente",      	/* 1   */
	NULL,						              	/* 2   */
	"Comando no reconocido",		          	/* 3   */
	"Campo de datos invalido",		          	/* 4   */
	"Comando invalido para el estado fiscal", 	/* 5   */
	NULL,			      						/* 6   */
	NULL,		              					/* 7   */
	NULL,	          							/* 8   */
	NULL,                                     	/* 9   */
	NULL,            							/* 10  */
	NULL,            			              	/* 11  */
	NULL,            		                  	/* 12  */
	NULL,                      				  	/* 13  */
	NULL                    				  	/* 14  */
};

char *ErrPrinter_Chile[] =
{								       			/*  Bit  */
	NULL,                   		   			/*	0   */
	NULL,						       			/*	1   */
	"Error de Impresora / Impresora Ocupada",	/*	2   */
	"Impresora Off-Line",			   			/*	3   */
	NULL,                 		       			/*	4   */
	"Falta Papel",		       			        /*	5   */
	NULL,                       	   			/*	6   */
	NULL,                        	   			/*	7   */
	"Tapa de impresora abierta",    	   		/*	8   */
	NULL,                    		   			/*	9   */
	NULL,                              			/*	10  */
	NULL,                          	   			/*	11  */
	NULL,						       			/*	12  */
	NULL,						       			/*	13  */
	"Gaveta de dinero abierta"      			/*	14  */
};

void
CheckFiscalStatus (int status, int Version)
{
	int i;
	int mask=1;
	char **Msg;

	ShowLine ("Fiscal Status: [%04x]\n",status);

	/* Si status = 0 no hay errores */
	if( !status )
		return;		

	switch (Version)
	{
		case VER_PRN_614_950_262:
		case VER_PRN_615_951_PR4:
			Msg = ErrFiscal_PR4;
			break;
			
		case VER_ARTJET:
		case VER_PRN320:
		case VER_PRN321:
		case VER_NCR:
		case VER_PRN425:
		case VER_OKIPAGE:
			Msg = ErrFiscal_PJ20;
			break;
					
		case VER_CHILE:
			Msg = ErrFiscal_Chile;
			break;
	}

	for (i = 0; i < 15; i++, mask <<= 1, Msg++)
		if ( status & mask )
			if ( *Msg )
				ShowLine ("%s\n", *Msg);
}

void
CheckPrinterStatus (int  status, int Version)
{
	int i;
	int mask=1;
	char **Msg;

	ShowLine ("\nPrinter Status: [%04x]\n", status);

	if( !status )
		return;		

	switch (Version)
	{
		case VER_PRN_614_950_262:
		case VER_PRN_615_951_PR4:
			Msg = ErrPrinter_PR4;
			break;

		case VER_ARTJET:
		case VER_PRN320:
		case VER_PRN321:
		case VER_NCR:
		case VER_PRN425:
		case VER_OKIPAGE:
			Msg = ErrPrinter_PJ20;
			break;
					
		case VER_CHILE:
			Msg = ErrPrinter_Chile;
			break;
	}
			

	for (i = 0; i < 15; i++, mask <<= 1, Msg++ )
		if( status & mask )
			if ( *Msg )
				ShowLine ("%s\n", *Msg);
}



