/*
pr4.h
*/

// ************************************************************************
// **** Comandos validos solo en los impresores 614/615/PR4/951/262  ******
// ************************************************************************

#define OPENNONFISCAL_SLIP		0x47
#define CUTNONFISCALOP          0x4b
#define FEEDRECEIPTOP           0x50
#define FEEDJOURNALOP           0x51
#define FEEDRECJOUOP            0x52
#define FEEDSLIPOP              0x53
#define DNFH_FARMACIAS			0x68
#define DNFH_REPARTO            0x69
#define SET_VOUCHER1			0x6A
#define SET_VOUCHER2			0x6B
#define PRINT_VOUCHER			0x6C
#define CMD_FORMAT_EPROM		0x7a	/* Formatear la memoria fiscal	*/
#define OPENDRAWER1OP           0x7b
#define DISPLAYOP               0xb2

Formatos Form_DNFHFarmacias [] =
{
	"Ingrese Cantidad de Copias (1~2): ", 					NULL, NULL,
	NULL,													NULL, NULL
};

Formatos Form_DNFHReparto [] =
{
	"Ingrese Cantidad de Copias (1~3): ", 					NULL, NULL,
	NULL,													NULL, NULL
};

Formatos Form_SetVoucher1 [] = 
{
	"Nombre de Cliente : ", 								NULL, NULL,
	"Nombre de Tarjeta : ", 								NULL, NULL,

	"\nTipo de Operaci�n :\n"
	"'C' .... Compra\n"
	"'V' .... Anulaci�n de la compra\n"
	"'D' .... Devoluci�n\n"
	"'A' .... Anulaci�n de la devoluci�n : ", 				NULL, NULL,

	"\nN�mero de Tarjeta : ", 								NULL, NULL,
	"Fecha de Vencimiento de Tarjeta (AAMM): ", 			NULL, NULL,

	"\nTipo de Tarjeta :\n"
	"'D' .... D�bito\n"
	"'C' .... Cr�dito : ", 									NULL, NULL,

	"\nCantidad de Cuotas: ", 								NULL, NULL,

	NULL,													NULL, NULL
};

Formatos Form_SetVoucher2 [] = 
{
	"C�digo del comercio : ", 								NULL, NULL,
	"N�mero de terminal : ", 								NULL, NULL,
	"N�mero de lote : ",     								NULL, NULL,
	"N�mero de cup�n : ",    								NULL, NULL,

	"\nTipo de ingreso de datos :\n"
	"'*' .... Manual\n"
	"' ' .... Banda : ",									NULL, NULL,

	"\nOperaci�n :\n"
	"'N' .... OnLine\n"
	"'F' .... OffLine : ", 									NULL, NULL,
	
	"\nN�mero de autorizaci�n : ", 							NULL, NULL,
	"Importe de la operaci�n : ", 							NULL, NULL,
	"N�mero del comprobante fiscal : ", 					NULL, NULL,

	NULL,													NULL, NULL
};

Formatos Form_PrintVoucher [] = 
{
	"Cantidad de Copias (1~3) : ", 							NULL, NULL,
	NULL,													NULL, NULL
};

Formatos Form_FeedReceiptJournal [] = 
{
	"Cantidad de Lineas (nn) : ", 							NULL, NULL,
	NULL,													NULL, NULL
};

Formatos Open_Df [] =
{
	"Documento "
	"( 'T'-Tique; 'A'-TiqFact.\"A\"; 'B'-TiqFact.\"B\" ) : ", 	NULL, NULL,
	"Estaci�n de Impresion ( 'T'-Tique; 'S'-Slip ) : ", 	  	NULL, NULL,
	NULL, 														NULL, NULL
};

Formatos Print_Fiscal_Text [] = 
{
	"Texto Fiscal : ", 										NULL, NULL,
	"Identificador de Display : ", 							NULL, NULL,
	NULL, 													NULL, NULL
};																  

Formatos Print_Line_Item [] = 
{
   	"Descripci�n : ", 										NULL, NULL,
	"Cantidad (XXX.XXXXXXXXXX) : ", 						NULL, NULL,
	"Monto (XXXXXX.XX) : ", 								NULL, NULL,
	"Tasa de IVA (XX.XX) : ",								NULL, NULL,
	"Operaci�n ('m'-Negativa; 'M'-Positiva): ", 			NULL, NULL,
	"Coeficiente Impuestos Internos (0.XXXXXXXX) : ",		NULL, NULL,
	"Identificador de Display : ",							NULL, NULL,
	"Monto ('T'-Total; Otro-Base Imponible ): ", 			NULL, NULL,
	NULL, 													NULL, NULL
};																  

Formatos General_Discount [] =
{
	"Descripci�n : ", 										NULL, NULL,
	"Monto (XXXXXX.XX) : ", 								NULL, NULL,
	"Calificador ( 'M'-Recargo; 'm'-Descuento ) : ", 		NULL, NULL,
	"Identificador de Display : ", 							NULL, NULL,
	"Monto ('T'-Total; Otro-Base Imponible ): ", 			NULL, NULL,
	NULL, 													NULL, NULL
};

Formatos Last_Item_Discount [] = 
{
	"Descripci�n : ", 										NULL, NULL,
	"Monto (XXXXXX.XX) : ", 								NULL, NULL,
	"Calificador ( 'M'-Recargo; 'm'-Descuento ) : ", 		NULL, NULL,
	"Identificador de Display : ", 							NULL, NULL,
	"Monto ('T'-Total; Otro-Base Imponible ): ", 			NULL, NULL,
	NULL, 													NULL, NULL
};

Formatos Return_Recharge [] = 
{
	"Descripci�n : ", 											NULL, NULL,
	"Monto (XXXXXX.XX) : ", 									NULL, NULL,
	"Tasa de IVA (XX.XX) : ", 									NULL, NULL,
	"Calificador ( 'M'-Recargo; 'm'-Descuento ) : ", 			NULL, NULL,
	"Coeficiente Impuestos Internos (0.XXXXXXXX) : ", 			NULL, NULL,
	"Identificador de Display : ", 								NULL, NULL,
	"Monto ('T'-Total; Otro-Base Imponible ): ", 				NULL, NULL,
	"Tipo de Operacion ('B'-Bonif/Recargo; Otro-Envases ): ", 	NULL, NULL,
	NULL, 														NULL, NULL
};																	  


Formatos Perceptions [] = 
{
	"Al�cuota de IVA (XX.XX) : ", 							NULL, NULL,
	"Descripci�n : ", 										NULL, NULL,
	"Monto (XXXXXX.XX) : ", 								NULL, NULL,
	NULL, 													NULL, NULL
};


Formatos Charge_Non_Reg_Tax [] =
{
	"Monto (XXXXXX.XX) : ", 								NULL, NULL,
	NULL, 													NULL, NULL
};

Formatos Subtotal [] = 
{
	"Calificador de Impresi�n ('P'-Imprime; Otro no imprime ) : ", 	NULL, NULL,
	"Descripci�n : ", 										NULL, NULL,
	"Identificador de Display : ", 							NULL, NULL,
	NULL, 													NULL, NULL
};																  

Formatos Total_Tender [] = 
{
	"Descripci�n : ", 										NULL, NULL,
	"Monto (XXXXXXXXX.XX): ", 								NULL, NULL,
	"Calificador de Pago ('T'-Pago; 'C'-Cancelaci�n): ", 	NULL, NULL,
	"Identificador de Display : ", 							NULL, NULL,
	NULL, 													NULL, NULL
};																  

Formatos Daily_Close_By_Date [] =
{
	"Fecha Inicial (AAMMDD): ", 							NULL, NULL,
	"Fecha Final  (AAMMDD) : ", 							NULL, NULL,
	NULL, 													NULL, NULL
};																  

Formatos Daily_Close_By_Z_Num [] =
{
	"Nro. de Z Inicial : ", 								NULL, NULL, 
	"Nro. de Z Final : ",   								NULL, NULL,
	NULL, 													NULL, NULL
};

Formatos Get_Daily_Report [] =
{
	"Fecha (AAMMDD) o Nro. de Z : ", 						NULL, NULL,
	"Calificador ('T': Fecha, 'Z': Zeta) : ",				NULL, NULL,
	NULL, 													NULL, NULL
};

Formatos Print_Non_Fiscal_Text [] =
{
	"Texto No Fiscal : ", 									NULL, NULL,
	"Identificador de Display : ", 							NULL, NULL,
	NULL, 													NULL, NULL
};

Formatos Set_Customer_Data [] =
{
	"Nombre � Raz�n Social : ", 							NULL, NULL,
	"C.U.I.T. � Documento : ", 								NULL, NULL,
																  
	"Responsabilidad frente al IVA ... \n"
	"'I' .... Inscripto\n"
	"'N' .... No Inscripto\n"
	"'E' .... Exento\n"
	"'B' .... Bienes de Uso\n"
	"'C' .... Consumidor Final\n"
	"'A' .... No Responsable : ", 							NULL, NULL,

	"\nCalificador de C.U.I.T. � Documento ... \n"
	"'C' .... CUIT\n"
	"'0' .... LE\n"
	"'1' .... LC\n"
	"'2' .... DNI\n"
	"'3' .... Pasaporte\n"
	"'4' .... CI : ", 										NULL, NULL,
	NULL, 													NULL, NULL,
};

Formatos Set_Fantasy_Name [] = 	
{
	"L�nea ( 1~2 ) : ",  									NULL, NULL,
	"Texto de L�nea : ", 									NULL, NULL,
	NULL, 													NULL, NULL
};

Formatos Set_Header_Trailer [] =
{
	"L�nea ( 1 a 10: Encabezado; 11 a 20: Cierre ) : ", 	NULL, NULL,
	"Texto de L�nea : ", 									NULL, NULL,
	NULL, 													NULL, NULL
};

Formatos Set_Bar_Code [] =
{
	"Tipo de C�digo ... \n"
	"'1' .... EAN13\n"
	"'2' .... EAN8\n"
	"'3' .... UPCA\n"
	"'4' .... I2OF5 : ", 									NULL, NULL,
	"C�digo : ", 											NULL, NULL,
																  
	"Calificador Num�rico ... \n"
	"( 'N'-Imprime N�meros; Otro No Imprime ) : ", 			NULL, NULL,

	"Calificador de Impresi�n ( 'P'-Imprime; 'G'-Programa ) :", NULL, NULL,
	NULL, 														NULL, NULL
};																	  


Formatos Config_Cf_By_Block [] =
{
	"L�mite Tique Factura a Cosumidor Final (XXXXXX.XX) : ", 	NULL, NULL,
	"Limite de Ticket Factura Otros (XXXXXX.XX) : ", 			NULL, NULL,
	"Porcentaje IVA No Inscripto (XX.XX) : ", 					NULL, NULL,
	"Copias de Factura (1~3) : ", 								NULL, NULL,
	"Leyenda CAMBIO $0.00 ( 'P'-Imprime;Otros No Imprime ) : ", NULL, NULL,
	"Leyendas Con.Final, Ing Brut, etc.\n"							  
	"'P'-Imprime; Otros No Imprime :", 							NULL, NULL,
	"Corte de papel ... \n"											  
	"'F'-Total; 'P'-Parcial; 'N'-No Corta :",					NULL, NULL,
	NULL, 														NULL, NULL
};

Formatos Config_Cf_By_One [] =
{
	"Configuraci�n a modificar ... \n"
	"'4' .... Impresi�n de CAMBIO $0.00\n"
	"'5' .... Impresi�n de leyendas opcionales\n"
	"'6' .... Corte de Papel\n"
	"'7' .... Impresi�n de marco\n"
	"'8' .... Re-Impresi�n de documentos cancelados : ", 		NULL, NULL,

	"Par�metro de la configuraci�n a modificar ... \n"
	"CAMBIO $0.00 ..... 'P' - Imprime; Otros NO Imprime\n"
	"Leyend Opc.  ..... 'P' - Imprime; Otros NO Imprime\n"
	"Corte Papel  ..... 'F' - Corte Total; 'P' - Parcial; 'N' No corta\n"
	"Imp de marco ..... 'P' - Imprime; Otros NO Imprime\n"
	"Re-Impresi�n ..... 'P' - Re-Imprime Doc Cancelados; Otros NO Re-Impr. : ", NULL, NULL,

	NULL, 														NULL, NULL
};

Formatos Get_Header_Trailer [] =
{
	"L�nea ( 1~10-Encabezado; 11~20-Cierre ) : ", 				NULL, NULL,
	NULL, 														NULL, NULL
};

Formatos Set_Date_Time [] = 
{
	"Fecha (AAMMDD) : ", 										NULL, NULL,
	"Hora  (HHMMSS) : ", 										NULL, NULL,
	NULL, 														NULL, NULL
};

Formatos Change_Iva_Resp [] =
{
	"Nueva Responsabilidad :\n"
	"'I' .... Inscripto\n"
	"'N' .... No Inscripto\n"
	"'E' .... Exento\n"
	"'A' .... No Responsable\n"
	"'M' .... Monotributo : ", 		                            NULL, NULL,
	NULL, 														NULL, NULL,
};																	  

// **** Respuestas a los comandos *****

char *Resp_StatusRequest [] = 
{
	"N�mero de �ltimo ticket emitido",
	"Status auxiliar",
	"N�mero de �ltimo ticket-factura A emitido"
};

char *Resp_GetConfigData [] = 
{
	"L�mite obligaci�n datos consumidor final",
	"L�mite ticket-factura",
	"Porcentaje IVA Responsable no inscripto",
	"Reservado",
	"Impresi�n CAMBIO $0.00",
	"Impresi�n leyendas",
	"Tipo de corte del papel del ticket"
};

char *Resp_GetInitData [] =
{
	"CUIT",
	"Raz�n Social",
	"N�mero de  Registro",
	"Fecha de inicializaci�n",
	"N�mero de PV",
	"Fecha inicio actividades",
	"N�mero. Ingresos Brutos",
	"Responsabilidad frente al IVA"
};

char *Resp_HistoryCapacity [] = 
{
	"Cantidad total de registros",
	"Registros utilizados"
};

char *Resp_DailyClose [] = 
{
	"Nro. de Z � X",
	"Cant. de documentos fiscales cancelados",
	"Cant. de documentos no-fiscales homologados",
	"Cant. de documentos no-fiscales",
	"Cant. de tickets emitidos",
	"Reservado",
	"Nro. �lt. ticket / ticket-factura B/C emitidos",
	"Nro. �lt. ticket-factura A emitido",
	"Monto vendido",
	"Monto IVA",
	"Monto Impuestos Internos"
};

char *Resp_GetDailyReport [] = 
{
	"Fecha del cierre reportado",
	"Nro. de Z del cierre reportado",
	"Nro. �lt. ticket / tick-fact. B/C del cierre",
	"Nro. �ltimo ticket-factura A reportado",
	"Monto vendido durante el cierre reportado",
	"IVA acumulado durante el cierre reportado",
	"Impuestos internos acumulados de la jornada fiscal"
};

char *Resp_GetWorkingMemory [] = 
{
	"Cantidad de tickets cancelados",
	"Cantidad de documentos no fiscales emitidos",
	"Cantidad de documentos fiscales emitidos",
	"Ultimo ticket / ticket-factura B/C emitido",
	"Ultimo ticket-factura A emitido",
	"Ventas acumuladas",
	"IVA acumulado",
	"Impuestos internos acumulados (porc. y fijos)"
};

char *Resp_SendIva [] = 
{
	"N�mero de registro",
	"Al�cuota de IVA",
	"Monto de IVA / Percep",
	"Monto impuestos internos porc. del ticket",
	"Monto de IVA no inscr. acumulado en el ticket",
	"Venta neta (sin IVA)"
};

char *Resp_Subtotal [] = 
{
	"Cantidad de items vendidos",
	"Monto ventas",
	"Monto IVA",
	"Monto pagado (solo tras un pago parcial)",
	"IVA corresp. a responsable no inscripto"
};

char *Resp_TotalTender [] =
{
	"Vuelto o Monto faltante"
};

char *Resp_CloseDF [] = 
{
	"Nro. del comprobante fiscal reci�n emitido"
};

char *Resp_GetDateTime [] = 
{
	"Fecha",
	"Hora"
};

char *Resp_GetHeaderTrailer [] = 
{
	"Texto de header o trailer"
};

// **** Lista de comandos implementados ****

COMMANDSET CommandSet_PR4[] =
{
	{ '1', 
	CMD_STATUS_REQUEST, 		
	"Status Fiscal", NULL, NULL, Resp_StatusRequest },

	{ '2', 
	CMD_OPEN_DF, 			
	"Apertura de Documento Fiscal", Open_Df, NULL, NULL },

	{ '3', 
	CMD_PRINT_FISCAL_TEXT, 	
	"Impresi�n de Texto Fiscal", Print_Fiscal_Text, NULL, NULL },

	{ '4', 
	CMD_PRINT_LINE_ITEM, 	
	"Impresi�n de Item", Print_Line_Item, NULL, NULL },

    { '5', 
	CMD_LAST_ITEM_DISCOUNT, 	
	"Operaci�n sobre �ltimo Item", Last_Item_Discount, NULL, NULL  },

	{ '6', 
	CMD_RETURN_RECHARGE, 	
	"Bonific/Recargo/Envases", Return_Recharge, NULL, NULL },

	{ '7', 
	CMD_GENERAL_DISCOUNT, 	
	"Recargo o Descuento General", General_Discount, NULL, NULL	 },

	{ '8', 
	CMD_PERCEPTIONS,			
	"Percepciones", Perceptions, NULL, NULL },

	{ '9', 
	CMD_CHARGE_NON_REG_TAX,  
	"Carga IVA No Inscripto", Charge_Non_Reg_Tax, NULL, NULL },

	{ 'a', 
	CMD_SUBTOTAL, 			
	"Subtotal  ", Subtotal, NULL, Resp_Subtotal },

	{ 'b', 
	CMD_TOTAL_TENDER,		
	"Pago", Total_Tender, NULL, Resp_TotalTender },

	{ 'c', 
	CMD_CLOSE_DF,			
	"Cierre de Documento Fiscal", NULL, NULL, Resp_CloseDF },

	{ 'd', 
	CMD_OPEN_DNF_TICKET,			
	"Apertura de Documento NO Fiscal", NULL, NULL, NULL },

	{ 'e', 
	CMD_PRINT_NON_FISCAL_TEXT,
	"Impresi�n Texto NO Fiscal", Print_Non_Fiscal_Text, NULL, NULL },

	{ 'f', 
	CMD_CLOSE_DNF,			
	"Cierre de Documento NO Fiscal", NULL, NULL, NULL},

	{ 'g', 
	CMD_DAILY_CLOSE,			
	"Cierre Diario Z",	NULL, szSEP "Z", Resp_DailyClose },

	{ 'h', 
	CMD_DAILY_CLOSE,			
	"Cierre Diario X", NULL, szSEP "X", Resp_DailyClose },

	{ 'i', 
	CMD_DAILY_CLOSE_BY_DATE,	
	"Reporte Diario por Fecha",	Daily_Close_By_Date, szSEP "D", NULL },

	{ 'j', 
	CMD_DAILY_CLOSE_BY_Z_NUM,
	"Reporte Diario por Z",	Daily_Close_By_Z_Num, szSEP "D", NULL },

	{ 'k', 
	CMD_DAILY_CLOSE_BY_DATE,	
	"Reporte Global por Rango de Fechas", Daily_Close_By_Date, szSEP "T", NULL },

	{ 'l', 
	CMD_DAILY_CLOSE_BY_Z_NUM,
	"Reporte Global por Z", Daily_Close_By_Z_Num, szSEP "T", NULL },

	{ 'm', 
	CMD_GET_DAILY_REPORT,	
	"Leer Cierre Z", Get_Daily_Report, NULL, Resp_GetDailyReport },

	{ 'n', 
	CMD_HISTORY_CAPACITY,	
	"Capacidad de Cierres Z", NULL, NULL, Resp_HistoryCapacity },

	{ 'o', 
	DNFH_FARMACIAS,			
	"DNFH Farmacias", Form_DNFHFarmacias, NULL, NULL },

	{ 'p', 
	DNFH_REPARTO,			
	"DNFH Reparto", Form_DNFHReparto, NULL, NULL },

	{ 'q', 
	OPENNONFISCAL_SLIP,		
	"Abrir DNF en slip", NULL, NULL, NULL },

	{ 'r', 
	CMD_SET_CUSTOMER_DATA, 	
	"Carga de datos de cliente", Set_Customer_Data, NULL, NULL },

	{ 's', 
	CMD_SET_FANTASY_NAME, 		
	"Carga de l�neas de Fantas�a", Set_Fantasy_Name, NULL, NULL},

	{ 't', 
	CMD_SET_HEADER_TRAILER, 	
	"Carga de lineas de Header / Trailer", Set_Header_Trailer, NULL, NULL },

	{ 'u', 
	CMD_GET_HEADER_TRAILER, 	
	"Leer lineas de Header / Trailer", Get_Header_Trailer, NULL, Resp_GetHeaderTrailer },

	{ 'v', 
	CMD_SET_DATE_TIME, 		
	"Cambio de Fecha y Hora", Set_Date_Time, NULL, NULL },

	{ 'w', 
	CMD_GET_DATE_TIME, 		
	"Leer Fecha y Hora", NULL, NULL, Resp_GetDateTime },

#ifdef VER_FULL
	{ 'x', 
	CMD_CHANGE_IVA_RESP, 	
	"Cambio de Responsabilidad frente al IVA", Change_Iva_Resp, NULL, NULL },
#endif

	{ 'y', 
	CMD_CONFIG_CF_BY_BLOCK, 	
	"Carga Configuracion CF", Config_Cf_By_Block, NULL, NULL },

	{ 'z', 
	CMD_CONFIG_CF_BY_ONE, 	
	"Carga Configuracion CF Individual", Config_Cf_By_One, NULL, NULL },

	{ 'A', 
	CMD_SET_BAR_CODE, 		
	"Carga Codigo de Barras", Set_Bar_Code, NULL, NULL },

	{ 'B', 
	CMD_GET_CONFIG_DATA, 	
	"Leer Configuracion CF", NULL, NULL, Resp_GetConfigData },

	{ 'C', 
	CMD_GET_WORKING_MEMORY, 	
	"Leer Estado de la Memoria de Trabajo", NULL, NULL, Resp_GetWorkingMemory },

	{ 'D', 
	CMD_SEND_FIRST_IVA_INFO, 
	"Inicio Reporte Informacion IVA", NULL, NULL, Resp_SendIva },

	{ 'E', 
	CMD_SEND_NEXT_IVA_INFO, 	
	"Resto Reporte Informacion IVA", NULL, NULL, Resp_SendIva },

	{ 'F', 
	SET_VOUCHER1,			
	"Datos de Voucher 1", Form_SetVoucher1, NULL, NULL },

	{ 'G', 
	SET_VOUCHER2,		 
	"Datos de Voucher 2", Form_SetVoucher2, NULL, NULL },

	{ 'H', 
	PRINT_VOUCHER,		 
	"Imprimir Voucher",	Form_PrintVoucher, NULL, NULL },

	{ 'I', 
	OPENDRAWER1OP,		 
	"Apertura de Cajon", NULL, NULL, NULL },

	{ 'J', 
	0,					 
	"Mensaje a Display", NULL, NULL, NULL },

	{ 'K', 
	FEEDRECEIPTOP,			
	"Avance de Papel RECEIPT", Form_FeedReceiptJournal, NULL, NULL },

	{ 'L', 
	FEEDJOURNALOP,			
	"Avance de Papel JOURNAL", Form_FeedReceiptJournal, NULL, NULL },

	{ 'M', 
	FEEDRECJOUOP,			
	"Avance de Papel REC/JOUR", Form_FeedReceiptJournal, NULL, NULL },

	{ 'N', 
	CUTNONFISCALOP,			
	"Corte de Papel DNF", NULL, NULL, NULL },

	{ 'Y', 
	CMD_GET_INIT_DATA, 		
	"Leer datos Inicializacion", NULL, NULL, Resp_GetInitData },

	{ ANY, 0,	"", NULL, NULL, NULL }
};	

// *********************************************************************
// ***** Significado del campo auxiliar del comando status fiscal  *****
// *********************************************************************

// El status auxiliar indica el estado del parser del controlador fiscal. 
// Seg�n el valor del nibble menos significativo, considerado en formato 
// decimal, el controlador se encuentra en uno de los siguientes estados:

STATAUX_LOW StAuxLow [] = 
{
	0,	"Memoria fiscal no formateada",
	1,	"Memoria fiscal no inicializada",
	2,	"No hay ning�n comprobante abierto",
	3,	"Un comprobante fiscal se encuentra abierto.\nLa venta se encuentra habilitada",
	4,	"Comprobante fiscal abierto.\nSe acaba de imprimir un texto fiscal",
	5,	"Un comprobante no fiscal se encuentra abierto",
	6,	"Comprobrobante fiscal abierto.\nSe realiz� al menos un pago",
	7,	"Comprobrobante fiscal abierto.\nSe sald� el monto",
	8,	"Comprobrobante fiscal abierto.\nSe ha emitido el comando de percepciones",
	9,	"El controlador ha sido dado de baja",
	-1, NULL,
};

// Adem�s, seg�n el valor del nibble m�s significativo, 
// considerado en formato decimal, 
// el controlador se encuentra en uno de los siguientes estados:
// 
// Valor Decimal	Estado
// 	
// 2				Datos del comprador almacenados.
// 4				C�digo de barras almacenado en memoria de trabajo.
// 8				Operando en modo entrenamiento.
// 
// La combinaci�n de los estados se indica mediante la suma de los respectivos valores decimales. 
// Por ejemplo, el valor c (es decir, 4 + 8) indica que el controldor se encuentra en modo 
// entrenamiento y que hay un c�digo de barras almacenado.

STATAUX_HIGH StAuxHigh [] = 
{
	0x8000,	"Operando en modo entrenamiento", 
	0x4000,	"C�digo de barras almacenado en memoria de trabajo",
	0x2000,	"Datos del comprador almacenados",
	0x0000, NULL
};

#if 0

COMMANDSET CommandSet[]={
   { '1', StatusFiscal },
   { '2', HistoryCapacity },
   { '3', DailyCloseZ },
   { '4', DailyCloseX },
   { '5', GlobalbyDate },
   { '6', GlobalbyNumber },
   { '7', DailybyDate },
   { '8', DailybyNumber },
   { '9', OpenFiscalRec },
   { '0', PrintFiscalText },
   { '!', ProgramSequence },
   { 'a', PrintLineItem },
   { 'b', Subtotal },
   { 'c', TotalTender },
   { 'd', CloseFiscalRec },
   { 'e', OpenNonFiscal },
   { 'f', PrintNonFiscal },
   { 'g', CloseNonFiscal },
   { 'h', SetDate },          /* Escribe HORA y FECHA */
   { 'i', GetDate },          /* Lee Hora y Fecha */
   { 'j', SetHeadTrail },
   { 'k', PlaySequence },
   { 'A', GetHeadTrail },
   { 'B', OpenNFSlip},
   { 'C', Perception },
   { 'D', SetIVAResp },
   { 'E', CustomerData },
   { 'F', CargaIVANoInscripto },
#ifdef VER_FULL
   { 'H', KillEprom },
#endif
   { 'J', PrintBarCode },
   { 'K', ExitTestf},
   { 'L', DiscountLastItem},
   { 'M', GeneralDiscount},
   { 'N', DNFHFarmacias},
   { 'O', DNFHReparto},
   { 'P', SetVoucher1},
   { 'Q', SetVoucher2},
   { 'R', PrintVoucher},
   { 'S', ConfigOne},
#ifdef VER_FULL
   { 'T', ChgIVA},
#endif
   { 'U', ReadWM},
   { 'l', DisplayMessage},
   { 'm', OpenDrawer},
   { 'n', SendACK},
   { 'o', StartIVA},
   { 'p', NextIVA},
   { 'q', GetFiscalData},
   { 'r', GetZReport},
   { 's', GetConfiguration},
   { 't', SetFantasy},
   { '?', CutNonFiscal },
   { '@', BonifRecEnvases},
   { '#', FeedReceipt},
   { '$', FeedJournal},
#ifdef VER_FULL
   { '*', NewProtocol},
   { '(', SendStatPrn},
#endif   
   { '%', FeedReceiptJournal},
   { '', ExitTestf},
   { ANY, DefaultCommand},
};

char StatusFiscalCommand[] = 		{FISCALSTATUSREQUEST, 	NULL};
char HistoryCapacityCommand[] = 	{HISTORYCAPACITYOP, 	NULL};
char CloseFiscalCommand[] = 		{CLOSEFISCALOP, 		NULL};
char OpenNonFiscalCommand[] = 		{OPENNONFISCALOP, 		NULL};
char OpenNonFiscalSlipCommand[] = 	{OPENNONFISCALOP-1, 	NULL};
char CloseNonFiscalCommand[] = 		{CLOSENONFISCALOP, 		NULL};
char CutNonFiscalCommand[] = 		{CUTNONFISCALOP, 		NULL};
char KillEpromCommand[] = 			{KILLEPROMFISCAL,		NULL};
char FormatEpromCommand[] = 		{FORMATEPROMFISCAL, 	NULL};
char GetDateCommand[] = 			{GETDATEOP, 			NULL};
char DailyCloseZCommand[] = 		{DAILYCLOSEZOP, SEP, 'Z', NULL};
char DailyCloseXCommand[] = 		{DAILYCLOSEXOP, SEP, 'X', NULL};
char SendIVAInfoCommand[] = 		{SENDIVAINFOP, 			NULL};
char NextIVAInfoCommand[] = 		{NEXTIVAINFOP, 			NULL};
char GetFiscalDataCommand[] = 		{GETFISCALDATAOP, 		NULL};
char GetConfigurationCommand[] = 	{GETCONFOP, 			NULL};
char OpenDrawerCommand[] = 			{OPENDRAWER1OP, 		NULL};
char DNFHFarmaciasCommand[] = 		{0x68, 					NULL};
char DNFHRepartoCommand[] = 		{0x69, 					NULL};
char ReadWorkingMemoryCommand[] = 	{0x67, 					NULL};
char StatPRN [] = 					{'s', 					NULL};

#endif 
