/*
ipclient.c
*/

#include <errno.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <signal.h>
#include <fcntl.h>
#include <stdarg.h>

#ifdef UNIX
#include <prototypes.h>
#endif

#if defined (UNIX) || defined (LINUX) 
#include <unistd.h>
#include <sys/types.h>
#include <time.h>
#include <netdb.h>
#include <sys/select.h>
#include <sys/socket.h>
#endif

#ifdef UNIX
#include <sys/netinet/in.h>
#include <arpa/inet.h>
#endif 

#ifdef LINUX
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/time.h>
#endif

#ifdef WIN32
#include <winsock.h>
#endif 

#include "sock.h"
#include "ipclient.h"
#include "werror.h"
#include "fisdebug.h"

#define NEW_SOCK 0

static int fdsock;
static long NetTimeout = 15000;

int 
OpenConnection (int Port, char *Host)
{
	struct hostent *phostent;
	INADDR RemoteAddr;
	PORT   RemotePort;
	int    n;

	if ( (fdsock = SockStream (NEW_SOCK)) < 0 )
	{
		printf ("Error abriendo el port %d en TCP\n", NEW_SOCK);
		return ERR_SOCKET;
	}

	if ( !(phostent = gethostbyname (Host)) ) 
	{
		#if defined (UNIX) || defined (LINUX)
		printf ("No se encontro el Host %s en el archivo /etc/hosts\n", Host);
		#else
		printf ("No se encontro el Host %s en el archivo hosts\n", Host);
		#endif
		return ERR_NOHOST;
	}

	memcpy ( &RemoteAddr, phostent->h_addr, sizeof (INADDR));

	RemoteAddr = htonl (RemoteAddr);
	RemotePort = Port;

	FISdebug ("Conectando a %s, port %d",  GetIPAsc (RemoteAddr), RemotePort);

	if ( SockConnect (fdsock, RemoteAddr, RemotePort, NetTimeout) < 0 )
	{
		printf ("Error conectando al servidor\n");
		return ERR_CONNECT;
	}

	return 0;
}

void
SetNetTimeout (long Timeout)
{
	NetTimeout = Timeout;
}

int 
SendPrinterCommand (char *Command, char *Answer, int SizeAnswer)
{
	int n;

	if ( SockSend (fdsock, Command, strlen (Command), NetTimeout) < 0 )
	{
		printf ("Error enviando el comando\n");
		return ERR_SEND;
	}

	while (1)
	{
		n = SockReceive (fdsock, Answer, SizeAnswer, NetTimeout); 

		if (n < 0)
		{
			if ( n == SOCK_ETIMEOUT )
			{
				printf ("Error esperando la respuesta (Rc = %d), errno %d\n", 
					n, errno);

				return ERR_TOUTRCV;
			}

			else return ERR_RCV;
		}
		
		Answer[n] = 0;

		if ( strstr (Answer, "DC2") || strstr (Answer, "DC4") )
			continue;

		break;
	}

	return 0;
}

int 
CloseConnection (void)
{
	return SockClose (fdsock);
}
