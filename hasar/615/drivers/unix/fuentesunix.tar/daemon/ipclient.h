/*
tcpip.h
*/

#define ERR_SOCKET  -10
#define ERR_NOHOST  -11
#define ERR_CONNECT -12
#define ERR_SEND    -13
#define ERR_RCV     -14
#define ERR_TOUTRCV -15

void SetNetTimeout (long Timeout);
int OpenConnection  (int Port, char *Host);
int SendPrinterCommand (char *Command, char *Answer, int SizeAnswer);
int CloseConnection ();
