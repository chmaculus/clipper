/*
	unxfis.c: 

	Driver para Impresor Fiscal.

	28/08/97
	Primera Version del programa 1.0

	23/09/97
	Version 1.1
	En la funcion MandaPaqueteFiscal no se verificaba si ReceiveAnswer 
	retornaba ERROR. Se puso incluso 3 reintentos mas en el caso que 
	ReceiveAnswer. Se vuelve a mandar el paquete y se lee la respuesta.

	07/03/00
	El loop que leia los comandos del pipe dejaba pasar una linea 
	con NL o CR. Verifico si la longitud del string es cero, no hago
	nada. Esto producia lentitud al esperar la respuesta de un comando 
	que no tiene cuerpo, o sea STX ETX y checksum.

	16/03/00
	Version 1.2
	Version actualizada que maneja protocolo nuevo y autodetect.

	01/11/00
	Se agrego la posibilidad de cambiar el FS en la respuesta (opcion -x)

	17/05/01
	Version 1.3
	Se agrego un nuevo modo de funcionamiento en el que el unxfis puede 
	funcionar como cliente de red. Lee como siempre los comandos por 
	el pipe de lectura, pero en lugar de mandarlos a traves del puerto 
	serie, los manda a la red a una direccion de IP y socket en particular.
	Una vez que tiene las respuestas las manda a traves del pipe de 
	escritura. 
	El programa spooler puede servir como servidor de red.

	21/05/2001
	Version 1.31
	Permite cambiar el archivo en donde se guardan los debuggers (con 
	la opcion -l)

	20/09/2001
	Version 1.32
	Permite setear un timeout en las comunicaciones a traves de la red.
*/

#ifdef UNIX
#include <prototypes.h>
#include <sys/termio.h>
#endif 

#ifdef LINUX
#include <termios.h>
#include <sys/time.h>
#endif 

#include <unistd.h>

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <fcntl.h>
#include <stdarg.h>
#include <ctype.h>
#include <signal.h>
#include <errno.h>

#include "fisdebug.h" 
#include "varios.h"
#include "unxlib.h"
#include "def_cmd.h"
#include "ipclient.h"

#ifdef UNIX
#define VERSION "Driver Fiscal para UNIX. Version 1.32 - 16/05/2001"
#else
#define VERSION "Driver Fiscal para LINUX. Version 1.32 - 16/05/2001"
#endif 

#include "getopt.h"

int f_debug, f_save;
long Speed = -1L;
int Autodetect;
int FlagNewProtocol;
int ChangeSeparator;

#ifdef X386
#define O_NONBLOCK O_NDELAY
#endif

static char  Uso [] = 
"\n"
"  Funcionando con conexion directa al controlador:\n"
"\n"
"     Uso: unxfis -p tty [-v] [-t] [-w] [opciones....]\n"
"\n"
"          -p  tty    tty en la que esta conectado el impresor\n"
"                     El programa abre el dispositivo /dev/[tty]\n"
"          -v  bauds  Cambia la velocidad del puerto serie.\n"
"          -t         Busca al controlador a las distintas velocidades \n"
"                     posibles (auto-excluyente con la opcion [-v]).\n"
"          -w         Establece el uso del nuevo protocolo de comunicaciones\n"
"                     con el impresor.\n"
"\n"
"  Funcionando como cliente de red:\n"
"\n"
"     Uso: unxfis -k -c ipaddr [-r port] [-m timeout] [opciones....]\n"
"\n"
"         -k         Envia los comandos a un servidor de red.\n"
"         -r port    Port del servidor de red (default: 1600).\n"
"         -c ipaddr  Nombre o direccion de ip del servidor.\n"
"         -m timeout Timeout en las comunicaciones por la red (en milisegundos).\n"
"\n"
"  Opciones generales:\n"
"\n"
"         -i  ipipe  Nombre del Pipe de escritura. Default: /dev/p_write.\n"
"         -o  opipe  Nombre del Pipe de lectura. Default: /dev/p_read.\n"
"         -d         Habilita los debuggers en pantalla.\n"
"         -s         Guarda los debuggers en un archivo (/etc/fiscal.log).\n"
"         -l  file   Cambia el nombre del archivo de debug.\n"
"         -n         Imprime la version.\n"
"         -x         Cambia el separador de campos del string de respuesta\n"
"                     (hexadecimal 1C) por el caracter '|'.\n";


static char  BufPipe [500];
static char  BufStatus [500];
static char  *Program;
static char  Pipe_Command [100];
static char  Pipe_Status  [100];
static int   PortDesc;
static char  DebugFile[400];

int  ClientMode;
int  PortHost = 1600;
char IPHost[500];

extern int 	errno;

#define TRUE 1
#define szSEP "\x1c" 

static void ChangeFs (void);

void
Fatal (char *Msg, ... )
{
    va_list argptr;
    char buffer[1000];

    va_start (argptr, Msg);
    vsprintf (buffer, Msg, argptr);
    printf ("%s\r\n", buffer);
    va_end (argptr);

	exit (1);
}

void
done (void)
{
	FISdebug ("STOP: %s", Program);
	CloseCommFiscal (PortDesc);
}

void
SigPipe (int sig)
{
	printf ("SIGPIPE\n");
}

void
delay (long msec)
{
	#ifdef LINUX

	struct timeval tv;

	tv.tv_sec = 0;
	tv.tv_usec = msec * 1000;

	select (0, NULL, NULL, NULL, &tv);

	#endif 

	#ifdef UNIX
	nap (msec);
	#endif
}

int 
main (int argc, char *argv[])
{
	int fdPipeSend;
	int fdPipeRecv;
	int n, Rc;
	char PortName [60];
	char caracter;
	int  Count = 0;
	char Buf[200];
	int  ComandoEnviado;
	long Timeout = 0L;
	
	PortName[0] = 0;

	Program = argv[0];

	strcpy (Pipe_Command, "/dev/p_write");
	strcpy (Pipe_Status,  "/dev/p_read");

	while ( (n = getopt(argc, argv, "xwtnv:i:o:dsup:kr:c:l:m:")) != EOF )
	
		switch ( n ) 
		{
			case 'x': 
				ChangeSeparator = TRUE;
				break;
			case 'w':
				FlagNewProtocol = TRUE;
				break;
			case 'v':
				Speed = atol (optarg);
				break;
			case 't':
				Autodetect = TRUE;
				break;
			case 'n':
				printf ("%s\r\n", VERSION);
				break;
			case 'p':	// TTY
				strcpy (PortName, optarg);
				break;
			case 'd':
				f_debug = TRUE;
				break;
			case 's':
				f_save  = TRUE;
				break;
			case 'i':
				strcpy (Pipe_Command, optarg);
				break;
			case 'o':
				strcpy (Pipe_Status, optarg);
				break;	
			case 'k':
				ClientMode = 1;
				break;
			case 'r':
				PortHost = atoi (optarg);
				break;
			case 'c':
				strcpy (IPHost, optarg);
				break;
			case 'l':
				strcpy (DebugFile, optarg);
				break;
			case 'm':
				Timeout = atoi (optarg);
				break;
			case 'u':
			default:
				Fatal (Uso);
				break;	
		}

	set_debug_options (f_debug, f_save, DebugFile);


	signal(SIGQUIT, SIG_IGN);	// Atrapa Abort ('Ctrl + \')
	signal(SIGINT,  exit);		// Atrapa Interrupt (Del)
	signal(SIGTERM, exit);		// Atrapa Kill (Signal 15)
	signal(SIGHUP,  exit);		// Atrapa Hangup (Signal 01). La manda el shell
	signal(SIGPIPE, SIG_IGN);	// Atrapa error de escritura en el pipe

	atexit (done);

	setbuf (stdout, NULL);

	if ( ClientMode ) 
	{
		if ( !IPHost[0] || Speed != -1 || Autodetect || FlagNewProtocol )
			Fatal (Uso);

		FISdebug ("START %s: IP Server = \"%s\", Port = %d", Program, 
			IPHost, PortHost);

		if ( Timeout )
			SetNetTimeout (Timeout);

		if ( OpenConnection (PortHost, IPHost) < 0 )
			Fatal ("No se pudo realizar la conexion");
	}

	else
	{
		if ( IPHost[0] || Timeout ) 
			Fatal (Uso);

		if ( Autodetect && Speed != -1 )
			Fatal (Uso);

		if ( !PortName[0] )
			Fatal (Uso);

		FISdebug ("START %s: Port = %s", Program, PortName);
		
		PortDesc = OpenCommFiscal (PortName);

		if ( PortDesc < 0 )
			Fatal ("Error abriendo %s", PortName);

		if ( Autodetect )
		{
			if ( SearchPrn (PortDesc, &Speed) < 0 )
				Fatal ("No se ha detectado al controlador!\n");

			FISdebug ("Controlador detectado a %ld baudios\n", Speed);
		}

		if (Speed != -1) 
			if ( SetBaudRate(PortDesc, Speed) < 0 )
				Fatal ("Velocidad %ld no soportada\n", Speed);

		if ( FlagNewProtocol )
			SetNewProtocol (1);

		if ( InitFiscal (PortDesc) < 0 )
			Fatal ("Error de comunicacion con el impresor\n");
	}

	/****************************************************/	
	/* Abre el pipe de lectura   						*/
	/****************************************************/
	
	FISdebug ("Abro Pipe de Lectura: %s", Pipe_Command);

	if ( (fdPipeRecv = open (Pipe_Command, O_RDONLY | O_NONBLOCK)) < 0 )
		Fatal ("Error abriendo pipe de lectura, errno %d", errno);

	/****************************************************/	
	/* Abre el pipe de escritura						*/
	/****************************************************/	
	
	FISdebug ("Abro Pipe de escritura: %s", Pipe_Status);

	if ( (fdPipeSend = open (Pipe_Status, O_WRONLY)) < 0 )
		Fatal ("Error abriendo pipe de escritura, errno %d", errno);

	fcntl (fdPipeSend, F_SETFL, O_NONBLOCK | fcntl (fdPipeSend, F_GETFL, 0));

	/****************************************************/
	/* Si no hay proceso que tenga el pipe abierto para */
	/* escritura read retorna 0 indicando EOF. 			*/
	/* Si algun proceso tiene el pipe abierto para es - */
	/* critura y esta seteado O_NONBLOCK read retorna   */
	/* -1 y setea errno a EGAIN. Si O_NONBLOCK no esta  */
	/* seteado read se bloquea hasta que se escriban    */
	/* datos en el pipe o el pipe es cerrado por los    */
	/* procesos que lo habian abierto para escritura.	*/
	/****************************************************/

	while ( 1 ) 
	{
		if ( (n = read (fdPipeRecv, &caracter, sizeof (caracter))) <= 0 )
		{
			delay (100L);
			continue;
		}

		if ( caracter == '\n' || caracter == '\r' )
		{
			BufPipe [Count] = 0;
			Count = 0;
			
			if ( !strlen (BufPipe) )
				continue;

			FISdebug ("Lei del pipe: %s", BufPipe);
			
			ComandoEnviado = BufPipe[0]; 

			if ( ClientMode )
			{
				memset (BufStatus, 0, sizeof (BufStatus));

				Rc = SendPrinterCommand(BufPipe, BufStatus, sizeof (BufStatus));

				if ( Rc < 0 )
					sprintf (BufStatus, "%d", Rc);
			}

			else 
			{
				Rc = MandaPaqueteFiscal (PortDesc, BufPipe, NULL, NULL, 
					BufStatus); 

				if ( Rc < 0 )
				{
					if ( Rc == ERR_STATPRN )
					{
						if ( ComandoEnviado != CMD_STATPRN )
							strcat (BufStatus, szSEP "~STATPRN~");
					}
					else strcpy (BufStatus, "-1");
				}

			}

			strcat (BufStatus, "\n");

			if ( ChangeSeparator )
				ChangeFs ();

			FISdebug ("Mando respuesta: %s", BufStatus); 

			/* Envio el status del printer */
			write (fdPipeSend, BufStatus, strlen (BufStatus) + 1);

			continue;
		}

		BufPipe [Count] = caracter;

		if ( Count ++ > sizeof (BufPipe) )
			Count = 0;
	}
}

static void
ChangeFs (void)
{
	char *p = BufStatus;

	for (p = BufStatus; *p; p ++ )
		if ( *p == 0x1c )
			*p = '|';
}
