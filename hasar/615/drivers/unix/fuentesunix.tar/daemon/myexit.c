
#define MYEXIT
#include <stdio.h>
#include <stdlib.h>

#include <varios.h>

#if defined (X386)

#define NFUNCS 32

static EXITFUNC func[NFUNCS];
static int top;

int
atexit(EXITFUNC f)
{
	if ( top >= NFUNCS )
		return -1;
	func[top++] = f;
	return 0;
}

void
myexit(int status)
{
	while ( top )
		func[--top]();
	exit(status);	
}

#endif
