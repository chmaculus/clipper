/*
    unxcomm.c:

	Modulo de comunicaciones para UNIX.

	Fecha: 08/97
*/

#ifndef LINUX
#include <prototypes.h>
#endif
#include <unistd.h>

#ifdef LINUX
#include <sys/types.h>
#endif 

#include <sys/time.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include <time.h>
#include <signal.h>
#include <termios.h>
#include <errno.h>

#include "ascii.h"
#include "fisdebug.h"
#include "fiscal.h"
#include "unxcomm.h"
#include "unxlib.h"

// Comandos del controlador

#define	CMD_SETBAUD		   0xa0	
#define	CMD_STATUS_REQUEST 0x2a	

extern int errno;

extern PORTS PortControl [MAX_PORTS];

typedef struct 
{
	int IdBaud;
	long BaudRate;
}
BaudTable;

BaudTable BaudTbl [] = 
{
	B1200,   1200L,
	B2400,   2400L,
	B4800,   4800L,
	B9600,   9600L,
	B19200,  19200L,
	B38400,  38400L

	/* 
	No soportado en las primeras versiones de OpenServer
	Tampoco soportado en Red Hat Linux.
	B57600,  57600L,
	B115200, 115200L	
	*/
};

#define MAX_BAUDS (sizeof (BaudTbl) / sizeof (BaudTable))

int 
DoTimeout (int fd, long sec)
{
	fd_set rfds;
	struct timeval tv;
	int retval;

	FD_ZERO (&rfds);
	FD_SET (fd, &rfds);

	tv.tv_sec = sec;
	tv.tv_usec = 0;

	return select (fd + 1, &rfds, NULL, NULL, &tv) > 0 ? 1 : 0; 
}

#ifdef LINUX

int 
rdchk (int fd)
{
	return DoTimeout (fd, 0);
}

#endif 

struct termios TermioCons;

void
RestoreTTY (void)
{
	tcsetattr (fileno(stdin), TCSANOW, &TermioCons);
}

int
start_comm (char *PortName)
{
	int i;
	char buf[100];
	char c;
	PORTS *Port = NULL;
	static int FirstTime = 1;
	int fdin = fileno(stdin);

	struct termios Termios;

#if 0
	if ( FirstTime ) 
	{
		tcgetattr (fdin, &Termios);

		memcpy (&TermioCons, &Termios, sizeof (TermioCons));

		#ifdef UNIX
		Termios.c_cc[VQUIT] = 0;
		Termios.c_cc[VMIN]  = 1;
		#endif

		#ifdef LINUX
		cfmakeraw (&Termios);
		#endif

		tcsetattr (fdin, TCSANOW, &Termios) ;

		atexit (RestoreTTY);

		FirstTime = 0;
	}
#endif

	// Busca una ranura libre 
	for ( Port = &PortControl[0], i = 0; i < MAX_PORTS; i++, Port++)
	{
		if ( Port->Used )
			continue;
		Port = &PortControl[i];
		Port->Used = 1;
		Port->PacketNumber = START_PACKET;
		break;
	}

	// Si no hay una ranura libre retorna
	if ( !Port )
		return ERR_NOPORT;

	// Abro el port y seteo el modo de la terminal serie
	sprintf (Port->PortName, "/dev/%s", PortName);

	if ( (Port->fdtty = open (Port->PortName, O_RDWR | O_NONBLOCK)) < 0 )
	{
		Port->Used = 0;
		printf ("Error Abriendo %s, errno %d\r\n", Port->PortName, errno);
		exit (1);
	}

	tcgetattr (Port->fdtty, &Termios);

	// Escribo la velocidad en la estructura.
	if ( cfsetospeed (&Termios, B9600) < 0 || cfsetispeed (&Termios, B9600) < 0)
	{
		printf ("Error cfsetospeed\r\n");
		exit (1);
	}

#ifdef LINUX
	cfmakeraw (&Termios);
	Termios.c_cc[VMIN] = 1;
#endif 

#ifdef UNIX
	Termios.c_oflag   = 0;
	Termios.c_iflag   = 0;
	Termios.c_lflag	  = 0;
	Termios.c_cc[VMIN] = 1;
#endif 

	// Ejecuta el ioctl
	if ( tcsetattr (Port->fdtty, TCSANOW, &Termios) < 0 )
	{
		printf ("Error tcsetattr\r\n");
		exit (1);
	}

	return i;
}

void
end_comm (PORTS *Port)
{
	Port->Used = 0;
	close (Port->fdtty);

}

void
Nop (int sig)
{
	return;
}

int
SendByte (PORTS *Port, char Byte)
{
	int n;
	
	n = write (Port->fdtty, &Byte, sizeof (Byte));

	// FISdebug ("SendByte : n = %d, [0x%X] [%c]", n, Byte, Byte);

	return n == sizeof (Byte) ? 0 : ERROR;
}

int
GetByte (PORTS *Port, unsigned char *Byte)
{
	if ( read (Port->fdtty, Byte, sizeof (char)) <= 0 )
	{
		FISdebug ("GetByte ERROR");	
		return ERROR;
	}

	// FISdebug ("GetByte : [0x%X] [%c]", *Byte, *Byte);

	return 0;
}

#define TIMEOUT_FISCAL_UNIX		2

int
GetByteTimed (PORTS *Port, unsigned char *Byte)
{
	int n;

	if ( DoTimeout (Port->fdtty, TIMEOUT_FISCAL_UNIX) == 0 )
		return ERROR;

	n = read (Port->fdtty, Byte, sizeof (char));

	// FISdebug ("GetByteTimed : n = %d, [0x%X] [%c]", n, *Byte, *Byte);

	if ( n <= 0 )
		return ERROR;

	return 0;
}


/* Sends a command */

int
SendCommand (PORTS *Port, char *data)
{
	int len;
	int n;
	char *p = data;

	len = strlen (data);

	/*
	FISdebug ("SendCommand: len = %d", len);

	while (*p)
		FISdebug ("SendCommand: [%0x]", *p++);
	*/

	if ( (n = write (Port->fdtty, data, len)) != len )
	{
		FISdebug ("Error mandando paquete, write ret. %d, errno %d", n, errno);
		return ERROR;
	}

    return OK;
}

int
BufferEmpty (PORTS *Port)
{
	return rdchk (Port->fdtty) > 0 ? 0 : -1;
}

int 
SetBaudRate (int PortDesc, long Baud)
{
	int i;
	BaudTable *B;
	struct termios Termios;
	PORTS *Port;

	if ( PortDesc >= MAX_PORTS )
		return ERR_DEFPORT;

	Port = &PortControl[PortDesc];

	if ( !Port->Used )
		return ERR_DEFPORT;

	for ( B = BaudTbl, i = 0; i < MAX_BAUDS; i ++, B++ )
		if ( B->BaudRate == Baud )
			break;

	if ( i == MAX_BAUDS ) 
		return -1;

	tcgetattr (Port->fdtty, &Termios);

	// Escribo la velocidad en la estructura.

	if ( cfsetospeed (&Termios, B->IdBaud) < 0 || 
		 cfsetispeed (&Termios, B->IdBaud) < 0)
	{
		FISdebug  ("Error cfsetospeed");
		exit (1);
	}

	// Ejecuta el ioctl
	if ( tcsetattr (Port->fdtty, TCSANOW, &Termios) < 0 )
	{
		FISdebug ("Error tcsetattr");
		exit (1);
	}

	return 0;
}

int 
SearchPrn (int PortDesc, long *Baud)
{
	int i;
	int OldRet;
	char Buffer[10];
	unsigned short PrnStatus;
	unsigned short FisStatus;
	static char FisAnswer[500];

	FISdebug ("Buscando Controlador Fiscal ");

	OldRet = SetCommandRetries (1);
		
	// Manda un comando de status a las distintas velocidades 
	// hasta que el printer responde.
		
	for (i = 0; i < MAX_BAUDS; i ++ )
	{
		SetBaudRate (PortDesc, BaudTbl[i].BaudRate);
			
		FISdebug ("Probando a %ld bauds", BaudTbl[i].BaudRate);

		sprintf (Buffer, "%c", CMD_STATUS_REQUEST);

		if ( !MandaPaqueteFiscal (
			PortDesc, Buffer, &FisStatus, &PrnStatus, FisAnswer) )
			break;
	}
	
	SetCommandRetries (OldRet);

	if ( i == MAX_BAUDS )
	{
		FISdebug ("El controlador fiscal NO fue encontrado !");
		return -1;
	}

	*Baud = BaudTbl[i].BaudRate;
	
	FISdebug ("Controlador fiscal detectado a %ld baudios", *Baud);

	return 0;
}

