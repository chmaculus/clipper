#ifndef LINUX
#include <prototypes.h>
#endif
#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <fcntl.h>
#include <time.h>
#include <stdarg.h>

#include "fisdebug.h"

int fdebug;
int fsave;

int debopen (char *file);

static char buffer[250];
static char buf_file[250];
static char debfile[400];

void
set_debug_options (int debug, int save, char *debugfile)
{
	fdebug = debug;
	fsave  = save;
	strcpy (debfile, debugfile);
}

int 
debopen (char *file)
{
	int fd;	
	extern int errno;
	long pos;

    if ((fd = open (file, O_WRONLY | O_CREAT | O_APPEND, 0666)) < 0) 
        return -1;

    /* --- Obtiene informacion acerca del archivo --- */
	if ( lseek(fd, 0L, 2) < 500000L )
		return fd;

	close (fd);

	unlink (file);

	/* --- Lo abre nuevamente --- */
	if( (fd=open(file, O_CREAT | O_TRUNC | O_APPEND | O_WRONLY, 0666)) < 0) 
		return -1;
	
	return fd;	
}

void
FISCAL_debug (char *msg, char *args)
{
    time_t ct;
    struct tm *ptm;
    int fd;
	char *file;

	if ( !fdebug && !fsave )
		return;

	vsprintf (buffer, msg, args);

    if ( fdebug )
		#ifdef UNIX
		printf ("%s\n", buffer);
		#endif

		#ifdef LINUX
		printf ("%s\r\n", buffer);
		#endif

	if ( fsave )
	{
		file = debfile[0] ? debfile :  "/etc/fiscal.log";

		if ((fd = debopen (file)) < 0 ) 
			return;

		time(&ct);

		ptm = localtime(&ct);

		sprintf (buf_file,"%02d%02d-%02d%02d: %s\r\n",
			ptm->tm_mday,
			ptm->tm_mon+1,
			ptm->tm_hour,
			ptm->tm_min,
			buffer);

		write (fd, buf_file, strlen (buf_file));
		
		close (fd);
	}
}

static void (*DebugFunction) () = FISCAL_debug;
static void (*OldDebugFunction) ();

void
FISdebug(char *msg, ...)
{
	DebugFunction (msg, (char *)(&msg + 1));
}

void (*
SetFISdebug (void (*NewDebugFunction)()) )
()
{
	OldDebugFunction = DebugFunction;
	DebugFunction    = NewDebugFunction;
	return OldDebugFunction;
}

