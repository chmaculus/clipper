/*
    Fiscal.c:

	Modulo de manejo de paquetes fiscales.

	Fecha: 1/97
		   25/02/2000
*/

#ifndef LINUX
#include <prototypes.h>
#endif

#include <unistd.h>
#ifdef LINUX
#include <termio.h>
#else 
#include <sys/termio.h>
#endif 
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <fcntl.h>
#include <stdarg.h>
#include <ctype.h>
#include <signal.h>
#include <errno.h>

#include "fisdebug.h" 
#include "ascii.h"
#include "fiscal.h"
#include "unxcomm.h"
#include "unxlib.h"
#include "xtoi.h"
#include "def_cmd.h"

static int CommandRetries = ANS_RETRY;
static int NroPaqueteRecibido;
static int NroPaqueteEnviado;
static int ComandoRecibido;

// Separador de campos
#define SEP                0x1c

#define delay(ms) 		   nap((long) ms)

// Esta variable indica si se esta usando el protocolo nuevo.

int New_Protocol;

#define IS_TOKEN_FISCAL(c) \
	(c == STX || c == ACK || c == NAK || c == DC2 || c == DC4)

extern void	ShowBuffer 	(char *Msg, char *p);

extern int 	errno;

void Error (char *Msg, ... );

static void ArmaPaqueteFiscal 	(PORTS *Port, char *command);
static int  SendPacket 			(PORTS *Port, char *Buffer);
static int  ReceiveAnswer 		(PORTS *Port);
static int  GetAck 				(PORTS *Port);
static int  GetAnswer 			(PORTS *Port);
static int  WaitAnswer 			(PORTS *Port);
static int  Verif_CheckSum 		(PORTS *Port, int CheckSum);

PORTS PortControl [MAX_PORTS];

void
Error (char *Msg, ... )
{
    va_list argptr;
    char buffer[200];

    va_start (argptr, Msg);
    vsprintf (buffer, Msg, argptr);
    printf ("%s\n", buffer);
    va_end (argptr);

	exit (1);
}

char *
ChangeFS (char *p, char oldfs, char newfs)
{
	char *Orig = p;

	for ( ; *p; p++)
		if ( *p == oldfs )
			*p = newfs;	

	return Orig;
}

void
ShowBuffer (char *Msg, char *p)
{
	char *q, *Orig;

	if ( !(Orig = q = strdup (p)) )
		Error ("No hay memoria suficiente\n");
	
	FISdebug ("%s <%s>", Msg, ChangeFS (q, 0x1c, '|'));

	free (Orig);
}

// ***************** Funciones Publicas ********************

// Abre el puerto serie determinado por PortName.
// (tty1a, tty2a ....)

int 
OpenCommFiscal (char *PortName)
{
	return start_comm (PortName);
}

// Cierra el puerto serie, verificando previamente si 
// el descriptor del Port es el correcto

int 
CloseCommFiscal (int PortDesc)
{
	PORTS *Port;

	if ( PortDesc >= MAX_PORTS )
		return ERR_DEFPORT;

	Port = &PortControl[PortDesc];

	if ( !Port->Used )
		return ERR_DEFPORT;

	end_comm (Port);

	return 0;
}

// Esta funcion setea una funcion de usuario que va a ser 
// ejecutada por la libreria cuando falte papel o el printer este 
// ocupado (DC4, DC2)

PFV KeepAliveHandler = NULL;

int 
SetKeepAliveHandler (PFV Handler)
{
	KeepAliveHandler = Handler;
}

// Manda un par de comandos de status para sincronizar el 
// el contador de numero de paquete.

int
InitFiscal (int PortDesc)
{
	unsigned short StatusFiscal, StatusPrinter;
	char *StatusString = "*";
	PORTS *Port;

	if ( PortDesc >= MAX_PORTS )
		return ERR_DEFPORT;

	Port = &PortControl[PortDesc];

	if ( !Port->Used )
		return ERR_DEFPORT;

	/****************************************************/
	/*	Por las dudas, ACKeo respuestas perdidas. 		*/
	/****************************************************/

	FISdebug ("Test Buffer Empty...");

	if (!BufferEmpty (Port))
	{
		FISdebug ("ACKeando respuestas perdidas...");
		while ( !BufferEmpty (Port) && GetAnswer(Port) == OK )
			SendByte (Port, ACK);
	}

	//	Mando dos request de status para sincronizar	
	//	un posible packet mismatch.					
	
	FISdebug ("Init Status Request #1:");
	MandaPaqueteFiscal (PortDesc, StatusString, NULL, NULL, NULL); 

	FISdebug ("Init Status Request #2:");
	return MandaPaqueteFiscal (PortDesc, StatusString, NULL, NULL, NULL);
}

// Manda un comando fiscal a traves del port abierto.
// Formatea el comando, lo manda y espera la respuesta, escribiendo los 
// status leidos y la respuesta entera en los punteros pasados como 
// parametro.

int 
MandaPaqueteFiscal (int PortDesc, char *Command, 
	unsigned short *FiscalStatus, unsigned short *PrinterStatus, 
	char *AnswerBuffer)
{
	PORTS *Port;
	static int i, j, c;
	static struct resp_fiscal 		*Respuesta;
	static struct resp_fiscal_new 	*RespuestaN;
	int Rc;
	int NroPaquete;
	char *FisStat;
	char *PrnStat;
	char *AnswerPtr;
	unsigned char Comando;

	if ( PortDesc >= MAX_PORTS )
		return ERR_DEFPORT;

	Port = &PortControl[PortDesc];

	if ( !Port->Used )
		return ERR_DEFPORT;

	FISdebug ("MandaPaqueteFiscal : CommandRetries %d, New_Protocol %d",
		CommandRetries, New_Protocol);

	for ( i = 0; i < CommandRetries; i++ )
	{
		if ( SendPacket (Port, Command) == ERROR) 
			break;

		if ( ReceiveAnswer (Port) == OK )
		{	
			if ( New_Protocol )
			{
				RespuestaN = (struct resp_fiscal_new *) Port->Buffer_Respuesta;

				NroPaquete = RespuestaN->Paquete;
				Comando    = RespuestaN->Comando;
				FisStat    = RespuestaN->fiscal_status;
				PrnStat    = RespuestaN->printer_status;
				AnswerPtr  = (char *)(&RespuestaN->printer_status);
			}
			
			else 
			{
				Respuesta = (struct resp_fiscal *) Port->Buffer_Respuesta;

				NroPaquete = Respuesta->Paquete;
				Comando    = Respuesta->Comando;
				FisStat    = Respuesta->fiscal_status;
				PrnStat    = Respuesta->printer_status;
				AnswerPtr  = (char *)(&Respuesta->printer_status);
			}
			
			NroPaqueteRecibido = NroPaquete;
			NroPaqueteEnviado  = Port->PacketNumber;

			// Almacena el status fiscal, status de printer y el resto 
			// de la respuesta.

			if ( FiscalStatus )
				*FiscalStatus 	= xtoi (FisStat);

			if ( PrinterStatus )
				*PrinterStatus	= xtoi (PrnStat);

			if ( AnswerBuffer )
			{
				strcpy (AnswerBuffer, AnswerPtr);
				AnswerBuffer [strlen (AnswerBuffer) - 1] = 0;
			}

			if ( (Port->PacketNumber += 2) > END_PACKET )
				Port->PacketNumber = START_PACKET;

            // FISdebug ("Comando = %X", Comando);

			ComandoRecibido = Comando;

			return Comando == CMD_STATPRN ? ERR_STATPRN : OK;
		}
	}

	if ( (Port->PacketNumber += 2) > END_PACKET )
		Port->PacketNumber = START_PACKET;

	return ERROR;
}

// ***************** Funciones Privadas ********************

/* 
 *	 Funcion: SendPacket ()
 * 
 *	 Manda un paquete al printer. Se espera un string que tenga el 
 *	 siguiente formato:
 *
 *	 "n[par1par2...]" 
 *
 *	 donde 
 *		 n		: numero de funcion (un byte ASCII)
 *		 		: separador de parametros
 *		 parn	: parametro numero n
 *
 *	 (Los parametros son opcionales al comando que se elija).
 *
 *	 Se empaqueta el string recibido con STX, ETX y un checksum y se hace
 *	 el handshaking con el puerto serie donde esta el printer fiscal.	
 *
 *	 Retorna: OK si todo bien, ERROR si hubo algun error en la transmision.
 *
 */

static int 
SendPacket (PORTS *Port, char *Buffer)
{
	int i, c;
	char *p;
	int AckRetries = CommandRetries == 1 ? 1 : ACK_RETRY;

	if ( !BufferEmpty (Port) )
	{
		FISdebug ("ACKeando respuestas perdidas...");

		while ( !BufferEmpty (Port) && GetAnswer (Port) == OK )
			SendByte (Port, ACK);
	}

	#if 0	// Hecho en ArmaPaqueteFiscal	
	if ( (p = strchr (Buffer, '\n')) != NULL )
		*p = 0;

	if ( (p = strchr (Buffer, '\r')) != NULL )
		*p = 0;
	#endif

    ArmaPaqueteFiscal (Port, Buffer);

 	for ( i = 0; i < AckRetries; i ++ ) 
	{
		ShowBuffer ("Envio el comando:", Port->Buffer_Transmision);

		if (SendCommand (Port, Port->Buffer_Transmision) == ERROR)
			continue;

		FISdebug ("Espero el ACK");

		if ((c = GetAck (Port)) == ACK )
			return OK;

		FISdebug ("%s esperando ACK", c == NAK ? "NAK" : "TIMEOUT");
	}

	FISdebug ("Demasiados reintentos esperando el ACK");

	return ERROR;
}		

// Recibe la respuesta del impresor.

static int 
ReceiveAnswer (PORTS *Port)
{
	struct resp_fiscal *Respuesta;
	int i;
	int AckRetries = CommandRetries == 1 ? 1 : ACK_RETRY;

	memset (Port->Buffer_Respuesta, 0, sizeof (Port->Buffer_Respuesta));

	for ( i = 0; i < AckRetries; i ++ ) 
	{
		FISdebug ("A esperar la respuesta");

		switch (GetAnswer (Port))
		{
			case OK:

				ShowBuffer ("Vino la respuesta", Port->Buffer_Respuesta);

				Respuesta = (struct resp_fiscal *) Port->Buffer_Respuesta;

				FISdebug ("Mando ACK"); 

				// Mando ACK independientemente del numero de paquete
				// que vino. Si este es equivocado me quedo esperando 
				// que el impresor mande la respuesta correcta.

				if (SendByte (Port, ACK) == ERROR)
				{
					FISdebug ("Error enviando ACK al impresor");
					break;
				}

				if (Respuesta->Paquete != Port->PacketNumber)
				{
					FISdebug ("Error en Numero de Paquete. Lo desecho");
					break;
				}

				return OK;

			case TIMEOUT:

				// Retorna Error de TIMEOUT
				return TIMEOUT;

			case ERROR:

				// El paquete vino con error de checksum. Mando NAK
				// para que el impresor lo envie nuevamente.

				FISdebug ("Mando NAK"); 

				if ( SendByte (Port, NAK) == ERROR )
				{	
					FISdebug ("Error enviando NAK al impresor");
					return ERROR;
				}

				break;
		}
	}

	FISdebug ("Demasiados intentos esperando la respuesta");
	return ERROR;
}

/*
 * Funcion: GetAnswer ()
 *
 * Espera la respuesta del printer al comando anterior.
 *
 */

static int 
GetAnswer (PORTS *Port)
{
    unsigned char c;
	int Count = 0;
	int Result = 0;

    // Espero el STX. Continuo con cualquier otro caracter.

    while ( (Result = GetByteTimed (Port, &c)) != ERROR && c != STX )

		if (c == DC2 || c == DC4)
		{
			if ( KeepAliveHandler )
				KeepAliveHandler (c, 0);
			FISdebug ("DC2/DC4");
		}

		else if (Count++ > MAX_THRASH)
		{
			FISdebug ("Demasiada basura esperando STX");
			return ERROR;
		}

    // Retorna ERROR por TIMEOUT.
    if ( Result == ERROR )
	{
		FISdebug ("TIMEOUT esperando STX");
        return TIMEOUT;
	}

	return WaitAnswer (Port);
}

// Espera el resto de un paquete, cuando ya se recibio el STX.

static int
WaitAnswer (PORTS *Port)
{
    unsigned short CheckSum = 0;
    unsigned char c = STX;
	char *Buffer = Port->Buffer_Respuesta;
	int Max = sizeof (Port->Buffer_Respuesta) - 1;

    // Espero el bloque completo hasta el ETX
    while ( (*Buffer++ = c ) != ETX ) 
	{
		if (--Max <= 1)
		{
			FISdebug ("Out of buffer esperando ETX");
			return ERROR;
		}

        CheckSum += c;

        // Si es TIMEOUT retorno ERROR.
        if ( GetByteTimed (Port, &c) < 0 )
		{
			FISdebug ("WaitAnswer : TIMEOUT esperando el paquete de respuesta");
            return TIMEOUT;
		}
    }

	*Buffer = 0;

    CheckSum += c;

    return Verif_CheckSum (Port, CheckSum);
}

// Lee los 4 bytes que corresponde al CheckSum y lo compara con 
// el recibido.  
// Retorna OK si el CheckSum esta OK y ERROR en caso contrario. 

static int 
Verif_CheckSum (PORTS *Port, int CheckSum)
{
	char buff[5];
	int i;
	unsigned char c = 0;
	int error = FALSE;
	int chk;
		
	for( i = 0 ; i < 4 ; i++ )
	{
		if ( GetByteTimed (Port, &c) < 0 )
		{
            error = TRUE;
			break;
		}

		c = toupper(c);

		if( !isdigit(c) && c < 'A' && c > 'F' )
		{
			error = TRUE;  
			break;
		}

		buff[i] = c;
	}

	chk = xtoi(buff);

	FISdebug ("Checksum: %s", (chk != CheckSum || error) ? "FAIL" : "OK");
	return ( ( error || chk != CheckSum ) ? ERROR : OK );
} 

// Espera ACK, NACK o KEEP_ALIVE del printer

static int 
GetAck (PORTS *Port)
{
    static unsigned char caracter;
	static int Count = 0;
	
    while ( GetByteTimed (Port, &caracter) != ERROR )
	{
        if ( IS_TOKEN_FISCAL (caracter) )
		{
			if (caracter == STX)
			{
				FISdebug ("Esperando ACK recibo STX. A esperar respuesta:");

				if (WaitAnswer (Port) == OK)
				{
					FISdebug ("ACK a respuesta");
					SendByte (Port, ACK);
				}
				else
				{
					FISdebug ("NAK a respuesta");
					SendByte (Port, NAK);
				}

				continue;
			}

			if (caracter == ACK || caracter == NAK)
			{
				FISdebug ("Recibo %s", caracter == NAK ? "NAK" : "ACK");
				return caracter;
			}
		}

		if (caracter == DC2 || caracter == DC4)
		{
			FISdebug ("DC2/DC4");
			continue;
		}

		if (Count++ > MAX_THRASH)
		{
			FISdebug ("Demasiada basura esperando ACK");
			return ERROR;
		}
	}

	FISdebug ("Getting ACK: TIMEOUT");        
    return ERROR;
}

// Arma un comando fiscal agregando el STX,ETX y CheckSum

static void 
ArmaPaqueteFiscal (PORTS *Port, char *command)
{
	unsigned short CheckSum=STX;
	char sCheckSum[5];
	int i, len;
	char *p = Port->Buffer_Transmision;

	*(p++)=STX;
	*(p++)=Port->PacketNumber;
	CheckSum += Port->PacketNumber;

	if ( New_Protocol )
	{
		*p++ = ESC;
		CheckSum += ESC;
	}

	while( *command )
	{
		if ( *command == '\r' || *command == '\n' )
		{	
			command++;
			continue;
		}
		CheckSum += * ((unsigned char *) command);
		*(p++) = *(command++);
	}
	*(p++) = ETX;
	CheckSum += ETX;

	/* Le coloco el CheckSum */
	sprintf(p,"%04x",CheckSum);
}

int
SetCommandRetries (int Retries)
{
	int OldRetries = CommandRetries;
	CommandRetries = Retries;
	return OldRetries;
}

int 
SetNewProtocol (int Value)
{
	New_Protocol = Value;
}

int 
ObtenerStatusImpresor (int PortNumber, unsigned short *FiscalStatus, 
	unsigned short *PrinterStatus,	char *AnswerBuffer)
{
	char Comando[10], *p;
	int Result;

	sprintf (Comando, "%c", CMD_STATPRN);

	return MandaPaqueteFiscal (PortNumber, Comando, 
		FiscalStatus, PrinterStatus, AnswerBuffer);
}

void
ObtenerNumeroDePaquetes (int *Enviado, int *Recibido, int *CmdRecibido)
{
	*Enviado     = NroPaqueteEnviado;
	*Recibido    = NroPaqueteRecibido;
	*CmdRecibido = ComandoRecibido; 
}

int
EnviarCaracter (int PortDesc, char Byte)
{
	PORTS *Port;

    if ( PortDesc >= MAX_PORTS )
        return ERR_DEFPORT;

    Port = &PortControl[PortDesc];

    if ( !Port->Used )
        return ERR_DEFPORT;

	return SendByte (Port, Byte);
}

