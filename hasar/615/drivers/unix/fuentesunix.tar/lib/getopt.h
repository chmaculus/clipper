int getopt();
extern int optind, opterr;
extern char *optarg;

