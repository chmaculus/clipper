/*
    timer.h
*/

void StartTimer      (void);
int  GetTimer        (void);
void interrupt Timer ();

