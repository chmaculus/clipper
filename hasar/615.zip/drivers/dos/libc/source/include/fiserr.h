#ifdef ERROR
#undef ERROR
#endif

#define OK      			0
#define ERROR 				-1
#define ERR_HANDLER 		-2
#define ERR_ATOMIC 			-3
#define ERR_TIMEOUT 		-4
#define ERR_ALREADYOPEN 	-5
#define ERR_NOMEM 			-6
#define ERR_NOTOPENYET 		-7
#define ERR_INVALIDPTR 		-8
#define ERR_STATPRN 		-9
#define ERR_ABORT			-10

