/* Enumeracion de Errores */
#define WBASE_ERROR 100
#define SOCK_ERRINIT  -100
#define SOCK_ETIMEOUT -101
#define SOCK_GENERALERROR -102
#define SOCK_EXCEDED -103
#define SOCK_EHOSTID -104
#define SOCK_INVALID_HOST -105
#define SOCK_ERRRECV  -106
#define SOCK_ERRSEND  -107
#define SOCK_ERRNOCONECT -108

