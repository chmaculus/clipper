#ifndef __CLIP_GTK_EXTRA_H__
#define __CLIP_GTK_EXTRA_H__

GtkType _gtk_type_sheet();
GtkType _gtk_type_combo_box();
GtkType _gtk_type_font_combo();
GtkType _gtk_type_color_combo();
GtkType _gtk_type_border_combo();
GtkType _gtk_type_toggle_combo();

#endif
