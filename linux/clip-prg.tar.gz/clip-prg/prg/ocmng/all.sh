ocmng install components/configs/Ocmng-init.xmo
ocmng install components/configs/Ocmng-full.xmo
ocmng install components/ALL.xmo
