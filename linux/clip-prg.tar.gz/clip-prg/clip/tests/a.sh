#!/bin/sh
#MALLOC_DEBUG=0xf1fc7f MALLOC_LOGFILE=a.mlog ./a
MALLOC_LOGFILE=a.mlog ./a
