mtype a:clip.tgz >/dev/null
