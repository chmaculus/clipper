/*
    Copyright (C) 2001  ITK
    Authors  : Uri Hnykin <uri@itk.ru>, Paul Lasarev <paul@itk.ru>
    License : (GPL) http://www.itk.ru/clipper/license.html
*/
/*
   $Log: _file1.c,v $
   Revision 1.1  2006/06/22 19:01:29  itk
   uri: initial

   Revision 1.7  2001/04/03 09:17:00  clip
   license errors
   paul

   Revision 1.6  2001/03/30 11:51:02  clip
   add copyright

   Revision 1.5  2000/05/24 18:33:54  clip
   _clip_push_area
   indents all
   Paul Lasarev <paul@itk.ru>

   Revision 1.4  2000/05/16 19:21:45  clip
   uri: bug in FILE

   Revision 1.3  2000/05/03 19:32:23  clip
   add prefix 'clip_' to all clip functions

   Revision 1.2  1999/10/26 19:11:09  paul
   start cvs logging

 */

/*
   struct ClipMachine;
   int __clip_file(struct ClipMachine *mp);

   int
   clip_FILE(struct ClipMachine *mp)
   {
   return __clip_file(mp);
   }
 */
