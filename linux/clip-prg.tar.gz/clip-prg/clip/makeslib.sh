#!/bin/sh

clip_makeslib $*

